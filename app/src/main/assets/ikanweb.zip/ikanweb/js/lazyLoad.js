var pageInto=function(){//进入页面的切页方法
        onceClick=false;
        touchClick=false;
        $("input").blur();
        if($(".refreshBox").length){
        	var bacgImage=$(".cartButton img").length?"img/index/cart1.png":"img/index/download.png";
        	$(".cartButton").css({"background-image":bacgImage});
        }
}
var appHtmlVersion=function  () {
    var appversion=isIphone?"5.0.7.":"5.0.5.3";
    return appversion;
}
var appversion=appHtmlVersion();
var swiper=undefined;
if(!isIphone){
    if($("#search").length) $("#search").attr("type","text");
}
var lazyLoad = {
    parentFixed: function(event) { //获取父元素是否固定定位
        return false;
        // if (isIphone) return false;
        // parentFixed = false;
        // obj = event.target;
        // do {
        //     var style = window.getComputedStyle ? window.getComputedStyle(obj, "") : obj.currentStyle;
        //     if (style.position == "fixed") return parentFixed = true;
        // }
        // while (obj.offsetParent && (obj = obj.offsetParent).nodeName.toUpperCase !== "BODY");
        // return parentFixed;
    },
    pageX: function(obj, rootName) { //获取页面X的滚动值
        var rootName = typeof(rootName) !== "undefined" ? rootName: "BODY";
        var left = 0;
        do {
            left += obj.offsetLeft;
        }
        while (obj.offsetParent && (obj = obj.offsetParent).nodeName !== "BODY" && ((rootName.indexOf("@")==-1&&!$(obj).hasClass(rootName))||(rootName.indexOf("@")==0&&obj.nodeName!==rootName.slice(0).toUpperCase())));
        return left;
    },
    pageY: function(obj, rootName) { //获取页面Y的滚动值
        if (obj) {
            var rootName = typeof(rootName) !== "undefined" ? rootName : "BODY";
            var top = 0;
            do {
                top += obj.offsetTop;
            }
            while (obj.offsetParent && (obj = obj.offsetParent).nodeName !== "BODY" && ((rootName.indexOf("@")==-1&&!$(obj).hasClass(rootName))||(rootName.indexOf("@")==0&&obj.nodeName!==rootName.slice(0).toUpperCase())));
            return top;
        } else {
            return false;
        }
    },
    pageTop: function(rootName) {
        var rootElement = typeof(rootName) !== "undefined" ? $("." + rootName + "")[0] : $("body")[0];
        if ($(rootElement)[0].scrollTop == 0) {
            return true;
        } else {
            return false;
        }
    },
    pageBottom: function(rootName) { //判断滚动条是否走到底部
        if (typeof rootName !== "string") {
            var rootElement = $("body"),
                scrollElement = $(window);
        } else {
            var rootElement = $("." + rootName + ""),
                scrollElement = rootElement;
        }
        var rootHeight = $("#loadBottom").length > 0 ? scrollElement.height() + $("#loadBottom").height() + 10 : $(rootElement).height() + 30;
        if ($(rootElement)[0].scrollTop + rootHeight + $(window).width() / 3 * 2 >= $(rootElement)[0].scrollHeight) {
            return true;
        } else {
            return false;
        }
    },
    getPageSie: function(rootName) {
        var rootElement = typeof(rootName) !== "undefined" ? $("." + rootName + "")[0] : $("body")[0];
        figureHeight = lazyLoad.elementSize($("figure")[0])[1];
        figureNum = Math.floor($(window).width() / $("figure").width()),
            windowHeight = $(rootElement).height(),
            figureNum = Math.floor($(window).width() / $("figure").width());
        return windowHeight * 2 * figureNum / figureHeight;
    },
    elementSize: function(obj) {
        if (typeof obj == "undefined") return [0, 0];
        var objStyle = obj.style;
        var height = objStyle.marginTop + objStyle.marginBottom + objStyle.borderWidth + objStyle.paddingTop + objStyle.paddingBottom + obj.offsetHeight;
        var width = objStyle.marginLeft + objStyle.marginRight + objStyle.borderWidth + objStyle.paddingLeft + objStyle.paddingRight + obj.offsetWidth;
        width = parseFloat(width);
        height = parseFloat(height);
        return [width, height];
    },
    isViewVisible: function(obj, rootElement, rootName, rootElementScroll) { //判断元素是否在视口窗内
        if (obj) {
            var loadPageY = lazyLoad.pageY(obj, rootName);
            var loadPageX = lazyLoad.pageX(obj, rootName);
            if (loadPageY <= ($(window).height() - lazyLoad.pageY(rootElement) + rootElementScroll)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    asyncLoadImg: function() {
        var imageUrl = arguments[0];
        if (arguments.length > 1) var index = arguments[1];
        $("#"+index+"").attr("src",imageUrl);
        !(function(index) {
              if ($("#"+index+"")[0].complete) {
                     $("#"+index).addClass("opacityAnimationLoad").parent(".defaultImage").addClass("defaultImageNone");
              }else{
                    $("#"+index+"")[0].onload = function() {
                        $("#"+index).addClass("opacityAnimationLoad").parent(".defaultImage").addClass("defaultImageNone");
                    }
              }
           
        })(index)
    },
    loadImage: function(rootName, swiper) { //对当前元素进行加载全局变量
        var rootElement = $("body")[0];
        if (typeof(rootName) !== "undefined") rootElement = $("." + rootName + "")[0];
        var obj,
            rootElementScroll = $(rootElement)[0].scrollTop,
            figureHeight = lazyLoad.elementSize($("figure")[0])[1],
            figureNum = Math.floor($(window).width() / $("figure").width()),
            loadImageLine = lazyLoad.pageY($("figure").parent()[0], rootName),
            windowHeight = $(rootElement).height();
        var figureAll = rootElementScroll >= loadImageLine;
        if (figureAll) { //判断数据加载模块是否进入就绪状态
            unloadIndex = Math.floor((rootElementScroll - loadImageLine) / figureHeight) * figureNum;
            obj = $("figure .unload");
        } else {
            unloadIndex = lineBefore;
            obj = $(".unload");
        }
        while (lazyLoad.isViewVisible(obj[unloadIndex], rootElement, rootName, rootElementScroll)) {
            if (!$(obj[unloadIndex]).hasClass("loaded")) {
                var _this = obj[unloadIndex];
                if (_this.nodeName !== "IMG") {
                    $(_this).css({
                        "background-image": "url(" + $(_this).data("image") + ")"
                    }).removeClass("unload").addClass("loaded");
                } else {
                    var imageData = $(_this).data("image"),
                        idData = _this.id;
                    if (typeof(imageData) !== "undefined" && typeof(idData) !== "undefined") {
                        console.log(idData)
                            lazyLoad.asyncLoadImg(imageData, idData);
                        $(_this).addClass("loaded");
                    }
                }
            }
            unloadIndex++;
        }
    }
};
var getAndroidVersion=function(){//获取安卓版本
    if(u.indexOf("Android ")==-1)return window.androidVersion="",window.androidVersionNum=0;
    var androidVersion=u.split("Android ");
    androidVersion=androidVersion[1].slice(0,androidVersion[1].indexOf(";"))+"";
    window.androidVersion=androidVersion;
    var androidVersionArr=androidVersion.split(".");
    for(var i=0,androidVersionNum=0;i<androidVersionArr.length;i++){
        var versionZero=[];
        versionZero.length=3-i;
        versionZero="1"+versionZero.join("0")-0;
        androidVersionNum+=androidVersionArr[i]*versionZero;
    }
    window.androidVersionNum=androidVersionNum;
}()
function initParam() { //初始化参数
    reloadPage = false;
    pageIndex = 0;
    swipeType = true;
    topClick = false;
    touchstart = 0;
    touching = 0;
    scrolling = true;
    iosInterval = null;
    iosScrollend = true;
    loadIndex = 0;
    lineBefore = 0;
    interval = null;
    eventPrevent = false;
    clickUsed = true;
    intervalStop = null;
    pageBottomFinish = true;
    pageLoadFinish = true;
    indexUnload = 0;
    touchClick=false;
}
var swipeType = true,
    topClick = false,
    touchstart = 0,
    touching = 0,
    reloadPage = false,
    touchClick=false,
    pageSize=12,
    initSize=12,
    windowWidth = $(window).width();
$("body").swipeUp(function() {
    swipeType = true;
});
if (isIphone) {//仅当是iphone的时候才调用body的触碰事件
    $(".scrollContent").on("touchstart", ikanTouchStart);
    $(".scrollContent").on("touchmove", ikanTouchMove);
    $(".scrollContent").on("touchend", ikanTouchEnd);
    $(".scrollContent").on("touchcancel",ikanTouchCancel);
}
var dpr = window.devicePixelRatio;
var touchBegin;
if (isIphone) {
    $(".scrollContent").on("touchstart", function(e){
        touchBegin = e.touches[0].clientX;
    });
}
function ikanTouchStart(ex, ey, sx, sy) {//touchstart 方法
    if(!isIphone){
        var ex=ex/dpr,ey=ey/dpr,sx=sx/dpr,sy=sy/dpr;
    }
    touchstartX=0;
    if ($(".refreshBox").length == 0 || reloadPage||$(".scrollContent").hasClass("overflowHidden")) return; //如果有刷新dom结构，并且刷新方法未调用，继续执行
    var swipeObjScrollTop = isIphone ? $(".scrollContent")[0].scrollTop : sy;
    if (swipeObjScrollTop === 0 && !eventPrevent) {//滚到顶部，开始记录位置
        touchstart = isIphone ? event.touches[0].pageY : ey;
        if(!isIphone) touchstartX=ex,touchstartY=ey;//todo
    }
}
function ikanTouchMove(ex, ey, sx, sy) {
    if(!isIphone){//对安卓给定数据进行换算
        var ex=ex/dpr,ey=ey/dpr,sx=sx/dpr,sy=sy/dpr;
    }
    if(!isIphone&&(Math.abs(ex-touchstartX)>10||Math.abs(ey-touchstartY)>10)){//非滑动时触发点击
        touchClick=true;
    }
    if ($(".refreshBox").length == 0) return;
    if(touchstart&&touchstartX&&Math.abs(ey-touchstart)/Math.abs(ex-touchstartX)<1.7) return;//非垂直方向滑动，返回
        var swipeObjScrollTop = isIphone ? $(".scrollContent")[0].scrollTop : sy;
        if (touchstart == 0 && (swipeObjScrollTop <= 0 && !eventPrevent)&&!$(".scrollContent").hasClass("overflowHidden")) {//如果滑动过程滚动至零，开始记录
            touchstart = isIphone ? event.touches[0].pageY : ey;
        }
        if(isIphone&&touchBegin<=10)return;
        if (touchstart) {//有了开始的记录，进入逻辑层
        touching = isIphone ? event.touches[0].pageY - touchstart : ey - touchstart;
        console.log(touching)
        if (touching > 0) {//触摸有移动，开始动画部分
            $(".refreshBox").css({
                opacity: 1
            })//显示刷新模块
            var ratio1 = touching / 300;
            var ratioTime = isIphone ? 700 : 100;
            if (touching >= 150) {
                $(".refreshText").html("松开后刷新");
            } else {
                $(".refreshText").html("下拉刷新");
            }
            $(".scrollContent").addClass("overflowHidden");//标记 进入逻辑层
            eventPrevent = true;
            var scrollLength = windowWidth / 1.5   - windowWidth * 50 / (0.3 * touching + 75);
            
            $(".scrollContent").css({
                "-webkit-transform": "translateY(" + scrollLength + "px)"
            });
            var refreshWidth = touching / 5 >= 30 ? 30 : touching / 5;
            $(".refreshImage").css({
                "-webkit-transform": "rotate(" + ratioTime * ratio1 + "deg)",
                width: refreshWidth
            });
            } else {
                eventPrevent = false;
                if(isIphone) $(".scrollContent").css({
                    "-webkit-transform": "translateY(" + 0 + "px)"
                });
            }
        }
    }
function ikanTouchEnd(ex,ey,sx,sy) {
    // debug("END")
    if(!isIphone){
        var ex=ex/dpr,ey=ey/dpr,sx=sx/dpr,sy=sy/dpr;
    }
    if(!isIphone)ikanHeaderClick(ex,ey,sy);
        // debug($(".refreshBox").length)
        if ($(".refreshBox").length === 0) return;
        if(!isIphone) touchstartX=0;
        var ratioTime = isIphone ? 700 : 100;
        touchstart = 0;
        if(touching<=150)eventPrevent = false;
        if ($(".scrollContent").hasClass("overflowHidden")) {
            var touchLength = touching;
            $(".scrollContent").animate({
                "-webkit-transform": "translateY(0)"
            }, 500);
            touching = 0;
            $(".refreshImage").animate({
                "-webkit-transform": "rotate(" + (ratioTime * touchLength / 300 - 360) + "deg)",
                width: 0
            }, 500);
            var timeout = isIphone ? 300 : 500;
            ! function(reloadPage) {//如果正在刷新中 不可重复刷新
                setTimeout(function() {
                    $(".scrollContent").removeClass("overflowHidden");
                    $(".refreshBox").css({
                        opacity: 0
                    })
                    $(".refreshText").html("下拉刷新");
                    if (touchLength > 150) {
                        eventPrevent = false;
                        if($(".bgShadow").hasClass("shadowSlide")) {reloadPage = true}
                        // alert(reloadPage)
                        if (reloadPage) return;
                        $(".box").show();
                        ikanWebInterface.reloadPage();
                    }
                }, timeout)
            }(reloadPage);
            if (touchLength > 150) reloadPage = true;
        }
    }
function ikanTouchCancel(ex,ey,sx,sy) {
    // debug("Cancel");
    if(!isIphone){
        var ex=ex/dpr,ey=ey/dpr,sx=sx/dpr,sy=sy/dpr;
    }
    if(!isIphone)ikanHeaderClick(ex,ey,sy);
        // debug($(".refreshBox").length);
        if ($(".refreshBox").length === 0) return;
        if(!isIphone) touchstartX=0;
        var ratioTime = isIphone ? 700 : 100;
        touchstart = 0;
        if ($(".scrollContent").hasClass("overflowHidden")) {
            var touchLength = touching;
            $(".scrollContent").animate({
                "-webkit-transform": "translateY(0)"
            }, 500);
            touching = 0;
            $(".refreshImage").animate({
                "-webkit-transform": "rotate(" + (ratioTime * touchLength / 300 - 360) + "deg)",
                width: 0
            }, 500);
            var timeout = isIphone ? 300 : 500;
            if(touchLength<=150)eventPrevent = false;
            ! function(reloadPage) {//如果正在刷新中 不可重复刷新
                setTimeout(function() {
                    $(".scrollContent").removeClass("overflowHidden");
                    $(".refreshBox").css({
                        opacity: 0
                    });
                    $(".refreshText").html("下拉刷新");
                    if (touchLength > 150) {
                        eventPrevent = false;
                        if (reloadPage) return;
                        $(".box").show();
                        ikanWebInterface.reloadPage();
                    }
                }, timeout);
            }(reloadPage);
            if (touchLength > 150) reloadPage = true;
        }
}
    var ikanHeaderClick=function(ex,ey,sy){//头部点击事件方法
        if(touchClick) return touchClick=false;
        if(androidVersionNum>=440||androidVersionNum===0)return;
        var options=headerClickFunc();
        var optionsArr=Object.keys(options);
        for(var z=0;z<optionsArr.length;z++){
            var i=optionsArr[z];
            for(var j=0;j<$(i).length;j++){
                var headX=lazyLoad.pageX($(i)[j],"@header");
                var objWidth=$(i)[j].getBoundingClientRect().width;
                if(ex>=headX&&ex<=(headX+objWidth)){//如果ex在该物体的x方向范围内
                    var headY=lazyLoad.pageY($(i)[j],"@header");
                    var objHeight=$(i)[j].getBoundingClientRect().height;
                    if(ey>=headY&&ey<=headY+objHeight){//证明点击目标已经找到，执行点击方法
                        touchClick=true;
                        if(typeof ikanHeaderTime!=="undefined")clearTimeout(ikanHeaderTime);
                        ikanHeaderTime=setTimeout(function(){//在500毫秒之内不允许连续两次点击
                            touchClick=false;
                        },500)
                        return options[i].apply($(i)[j]);
                    }
                }
            }
        }
    }
$("body").swipeDown(function(event) {
    swipeType = false;
});

function dataTest(data) {//数据合法化测试
    if (typeof data == "undefined" || data == "" || data.indexOf("{") > -1) return false;
    return true;
}
var scrolling = true;
var iosInterval = null;
var iosScrollend = true;
var callTopFunc=function(){
    if (isIphone) {
        $(".scrollContent")[0].scrollTop=0;
    } else {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop=0
    }
    if ($(".callTopIcon").hasClass("topUp")) {
        $(".callTopIcon").removeClass("topUp").addClass("topDown");
    };
}

var callTop = function(rootName) {//返回顶部
    if($(".bgColor").length&&$(".bgColor").css("display")=="block") return;
    var height=$(window).height();
    if ($(".callTopIcon").length && scrolling) {
        var rootNameTest = typeof rootName !== "undefined";
        if (rootNameTest) {
            var currentScrollTop = $("." + rootName + "")[0].scrollTop;
        } else {
            var currentScrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        }
        if (currentScrollTop >= height) {
            // if (swipeType) return;
            $(".callTopButton").show();
            $(".callTopIcon").addClass("topUp").removeClass("topDown");
            $(".callTopIcon").unbind("tap");
            $(".callTopIcon").bind("tap", function() {
                setTimeout(function(){
                    // console.log(iosScrollend)
                    setTimeout(function(){$(".callTopButton").hide();},300)
                    if(!iosScrollend){
                        iosScrollend=true;
                        return topValue = scrollParent.scrollTop;
                    } ;
                    if(androidVersionNum==0||androidVersionNum>=440)callTopFunc.apply(this);
                },50);
            })
        } else if ($(".callTopIcon").hasClass("topUp") && !swipeType || currentScrollTop < height) {
            $(".callTopIcon").addClass("topDown").removeClass("topUp");
        };
    }
}

function ImageUrl(url, size) {
    var dpr = window.devicePixelRatio;
    var ratio = document.documentElement.getBoundingClientRect().width;
    ratio = ratio * dpr > 720 ? 720 : ratio * dpr;
    ratio = ratio < 640 ? 640 : ratio;
    var ratio = ratio / 640;
    size = size.split(".")[1];
    size = size.split("x");
    size[0] = parseInt((size[0] - 0) * ratio);
    size[1] = parseInt((size[1] - 0) * ratio);
    size = "." + size[0] + "x" + size[1];
    url = url + size;
    return url;
}

function topDownComm() {
        $(".callTopIcon").addClass("topDown").removeClass("topUp");
    }

function imageLoadCallback(idIndex, imgurl) {//图片回掉方法
    var _this = $("#" + idIndex + "");
    // console.log(typeof imgurl)
    if (imgurl&&imgurl!==1) { //如果是ios，会有第二个参数
        if(typeof imgurl=="number") {
            if (imgurl==2||imgurl==0){
                var imgurl = _this.data("image");
                if (imgurl.indexOf("/") == 0) imgurl = imgurl.slice(1);
                if (imgurl == "") return;
            }
        }
        _this.attr("src", imgurl).addClass("opacityAnimationLoad").parent(".defaultImage").addClass("defaultImageNone");
        return;
    }
    var uri = _this.data("image");
    if (uri.indexOf("/") == 0) uri = uri.slice(1);
    if (uri == "") return;
    _this.attr("src", "content://cn.ikan.html.image/" + uri + "").addClass("opacityAnimationLoad").parent(".defaultImage").addClass("defaultImageNone");
}
FastClick.attach(document.body);
var pageIndex = 0,
    loadIndex = 0,
    unloadIndex, lineBefore = 0,
    interval = null,
    vertical, eventPrevent = false,
    clickUsed = true,
    intervalStop = null;
    var onceClick = false;
 var bool = "false";
function addAndoridComm() {//添加安卓公共css
    var cssAndoridComm = document.createElement("link");
    cssAndoridComm.rel = "stylesheet";
    cssAndoridComm.href = "css/commAndorid.css";
    $("head").append(cssAndoridComm);
}
window.pageBottomFinish = true, window.pageLoadFinish = true;

function loadImage(rootName, callBack) { //加载图片和区分ios与andorid方法
    var pagerTest = typeof rootName == "function" || typeof callBack !== "function";
    var scrollStopTest = function(scrollCallback, time) {
        time = time || 150;
        var containTest = typeof rootName == "string" && isIphone;
        var scrollParent=isIphone?$(".scrollContent")[0]:document.body;
        var scrollObj = containTest ? $("." + rootName + "") : $(window);
        scrollObj.unbind("scroll").bind("scroll", function() {
            clearTimeout(intervalStop)
            clickUsed = false;
            iosScrollend = false;
            // console.log("scroll iosScrollend is "+iosScrollend);
            if (containTest) {
                callTop(rootName)
            } else {
                callTop();
            }
            if (pagerTest) scrollCallback();
            if (interval == null){
                topValue = scrollParent.scrollTop;
                interval = setInterval(stopCheck, 250); //这里就是判定时间
            }
        })

        function stopCheck() {
            // 判断此刻到顶部的距离是否和0.15秒前的距离相等
            // console.log(scrollParent.scrollTop+":@@:"+topValue)
            if (scrollParent.scrollTop == topValue) {
                iosScrollend = true;
                // console.log("scroll iosScrollend is "+iosScrollend);
                clearInterval(interval);
                intervalStop = setTimeout(function() {
                    clickUsed = true;
                }, 50)
                if (!pagerTest) scrollCallback();
                interval = null;
            }
            topValue = scrollParent.scrollTop;
        }
    };
    if ((!isIphone && typeof(rootName) == "string" && typeof(callBack) == "undefined") || typeof(rootName) == "undefined") { //当未使用swiper，并且无分页

        addAndoridComm();
        lazyLoad.loadImage();
        scrollStopTest(lazyLoad.loadImage);
        return;
    } else if ((!isIphone && typeof(callBack) == "function") || typeof(rootName) == "function") { //当未使用swiper，并且有分页
        addAndoridComm();
        if (typeof(rootName) == "function") {
            callBack = rootName;
        }

        if (typeof hFiveImageRoad == "undefined") {
            $.each($(".unload"), function(index) {
                var imgUrls = $(".unload").eq(index).data("image"),
                    id = $(".unload")[index].id;
                if (dataTest(imgUrls) && dataTest(id)) {
                    $(".unload").eq(index).addClass("loaded");
                    ikanWebInterface.asyncLoadImg(imgUrls, id);
                }
            });
        }
        scrollStopTest(function() {
            if (pageIndex == 0) pageBottomFinish = true;
            if (lazyLoad.pageBottom() && pageBottomFinish && pageLoadFinish) {
                $(".loader").addClass("bottomImageRotate");
                pageLoadFinish = false;
                pageIndex++;
                callBack(pageIndex); //回掉函数
            }
        }, 30);
    } else if (isIphone) { //当使用swiper，并且无分页
        var iphoneComm = document.createElement("link");
        iphoneComm.rel = "stylesheet";
        iphoneComm.href = "css/commIphone.css";
        $("head").append(iphoneComm);
        if($(".refreshBox").length === 0)$("html").css({position:"fixed",left:0,top:0});
        if (typeof(callBack) == "undefined") {
            lazyLoad.loadImage(rootName);
            scrollStopTest(function() {
                lazyLoad.loadImage(rootName);
            })
        } else { //当使用swiper，并且有分页
            window.pageBottomFinish = true, window.pageLoadFinish = true;
            window.indexUnload = 0;
            if (typeof hFiveImageRoad == "undefined") {
                $.each($(".unload"), function(index) {
                    var imgUrls = $(".unload").eq(index).data("image"),
                        id = $(".unload")[index].id;

                    if (dataTest(imgUrls) && dataTest(id)) {
                        ikanWebInterface.asyncLoadImg(imgUrls, id);
                    }
                });
            }
            scrollStopTest(function() {
                if (pageIndex == 0) pageBottomFinish = true;
                if (lazyLoad.pageBottom(rootName) && pageBottomFinish && pageLoadFinish) {
                    // $(".loader").removeClass("bottomImageRotate");
                    pageLoadFinish = false;
                    pageIndex++;
                    callBack(pageIndex); //回掉函数
                }
            });
        }
    }
}

function debug(str) { //弹出框逻辑
    // try {
    //     str = formatJson(str);
    //     str = JSON.stringify(str);
    //     str = str.replace(/(\\r\\n)/g, "<br/>").replace(/(\\)/g, "").replace(/("")/g, "&nbsp");
    // } catch (e) {
    //     str = str;
    // }
    // var _this = $(".debugCommBox");
    // if (_this.length > 0) {
    //     if (_this.hasClass("alertHide")) {
    //         _this.show().html(str).removeClass("alertHide");
    //         return;
    //     }
    //     _this.append(str + "<br/>");
    //     return;
    // }
    // var alertContent = '<div class="debugCommBox" style="overflow:auto;z-index:1000;width:100%;height:300px;position:fixed;top:100px;background:#fff;border:1px solid #333;border-radius:5px;text-align:left;padding:10px;line-height:30px;font-size:14px;">' + str + '</div>' //dom结构 str相关
    // $("body").append(alertContent);
    // $(document).on("click", ".debugCommBox", function() {
    //     $(this).hide().addClass("alertHide");
    // })
}
var strConfirmComm = function(objName, alertContent, buttonContent, str) {//confirm 弹出公共方法
    var _this = $('.' + objName + '');
    if ($(this).parent().hasClass("confirmHide") && buttonContent.length) {
        for (var i = 0, alertButtonContent = ""; i < buttonContent.length; i++) {
            alertButtonContent += '<div class="confirmButton">' + buttonContent[i] + '</div>';
        }
        $(this).parent().show().removeClass("confirmHide")
        $(".confirmButtonArea").html(alertButtonContent);
        _this.html(str);
        return;
    } else if (_this.hasClass("confirmHide")) {
        _this.removeClass("confirmHide").parent().show().addClass("rgbChange");
        _this.html(str);
        return;
    } else {
        $(".bgAlertShadow").remove();
        $("body").append(alertContent);
    }
}
function confirm(str, buttonContent, func0, func1) {
    // if (isIphone) {
        var jsonString={};
        jsonString.strText=str;//提示内容
        if(buttonContent){//弱提示
            jsonString.preButton=buttonContent[0];
            if(buttonContent.length>1){
                jsonString.nextButton=buttonContent[1];
            }
        }
        window.preConfirmFunc=null;
        window.nextConfirmFunc=null;
        if(buttonContent&&typeof func0 == "function"){//第一个按钮事件
            jsonString.preConfirmFunc="preConfirmFunc";
            window.preConfirmFunc=function () {
                func0();
            }
        }
        if(buttonContent&&buttonContent.length>1&&typeof func1 == "function"){//第二个按钮时间
            jsonString.nextConfirmFunc="nextConfirmFunc";
            window.nextConfirmFunc=function () {
                func1();
            }
        }
        jsonString.type=arguments.length==1?0:buttonContent.length==1?1:2;
        console.log(jsonString)
        ikanWebInterface.iosConfirm(JSON.stringify(jsonString));
    // }else{
    //     console.log("anzhuo")
    //     if (typeof buttonContent !== "undefined" && buttonContent.length > 0) {
    //         for (var i = 0, alertButtonContent = ""; i < buttonContent.length; i++) {
    //             alertButtonContent += '<div class="confirmButton">' + buttonContent[i] + '</div>';
    //         }
    //         var alertContent = '<div class="bgAlertShadow"><div class="confirmBox"><p class="confirmContent">' + str + '</p><div class="confirmButtonArea">' + alertButtonContent + '</div></div></div>';
    //         strConfirmComm("confirmContent", alertContent, str);

    //         function confirmHide() {
    //             $(".bgAlertShadow").hide().addClass("confirmHide");
    //         }
    //         $(".confirmButton").click(function() {
    //             if (typeof func0 == "function" && $(this).index() == 0) func0();
    //             if (typeof func1 == "function" && $(this).index() == 1) func1();
    //             confirmHide();
    //         });
    //     } else {
    //         var alertContent = '<div class="bgAlertShadow"><div class="alertDefaultBox">' + str + '</div></div>';
    //         strConfirmComm("alertDefaultBox", alertContent, str);
    //         $(".bgAlertShadow").addClass("bgAlertHide");
    //         window.time = setTimeout(function() {
    //             $(".bgAlertShadow").removeClass("bgAlertHide").hide();
    //         }, 1500)
    //     }
    // }
    
    
}

function formatJson(json, options) { //格式化字符串
    var reg = null,
        formatted = '',
        pad = 0,
        PADDING = '    '; // one can also use '\t' or a different number of spaces

    // optional settings
    options = options || {};
    // remove newline where '{' or '[' follows ':'
    options.newlineAfterColonIfBeforeBraceOrBracket = (options.newlineAfterColonIfBeforeBraceOrBracket === true) ? true : false;
    // use a space after a colon
    options.spaceAfterColon = (options.spaceAfterColon === false) ? false : true;

    // begin formatting...
    if (typeof json !== 'string') {
        // make sure we start with the JSON as a string
        json = JSON.stringify(json);
    } else {
        // is already a string, so parse and re-stringify in order to remove extra whitespace
        json = JSON.parse(json);
        json = JSON.stringify(json);
    }

    // add newline before and after curly braces
    reg = /([\{\}])/g;
    json = json.replace(reg, '\r\n$1\r\n');

    // add newline before and after square brackets
    reg = /([\[\]])/g;
    json = json.replace(reg, '\r\n$1\r\n');

    // add newline after comma
    reg = /(\,)/g;
    json = json.replace(reg, '$1\r\n');

    // remove multiple newlines
    reg = /(\r\n\r\n)/g;
    json = json.replace(reg, '\r\n');

    // remove newlines before commas
    reg = /\r\n\,/g;
    json = json.replace(reg, ',');

    // optional formatting...
    if (!options.newlineAfterColonIfBeforeBraceOrBracket) {
        reg = /\:\r\n\{/g;
        json = json.replace(reg, ':{');
        reg = /\:\r\n\[/g;
        json = json.replace(reg, ':[');
    }
    if (options.spaceAfterColon) {
        reg = /\:/g;
        json = json.replace(reg, ': ');
    }

    $.each(json.split('\r\n'), function(index, node) {
        var i = 0,
            indent = 0,
            padding = '';

        if (node.match(/\{$/) || node.match(/\[$/)) {
            indent = 1;
        } else if (node.match(/\}/) || node.match(/\]/)) {
            if (pad !== 0) {
                pad -= 1;
            }
        } else {
            indent = 0;
        }

        for (i = 0; i < pad; i++) {
            padding += PADDING;
        }

        formatted += padding + node + '\r\n';
        pad += indent;
    });

    return formatted;
};
$("body").on("touchmove", function(event) {
    eventPrevent = eventPrevent ? "event.preventDefault()" : "";
    eval(eventPrevent);
})

function slices(a, num) {
    a = a.trim()
    if (a.length > num) {
        return a = a.substring(0, num);
    } else {
        return a = a;
    }
}
function inputSlice(string){//input截取字段
    // var widths=$("#search")[0].getBoundingClientRect().width;
    // var txtNum=Math.floor(widths*10/150)*2;
    // var stringLen=0;
    // for (var i = 0; i < string.length; i++) {
    //     if(string.charCodeAt(i)>255){
    //         debug(string.charCodeAt(i))
    //         stringLen+=2;
    //     }else{
    //         stringLen++;
    //     }
    //     if(stringLen>=txtNum)break;
    // };
    // if(string!==undefined&&string.length>0)var sliceString=stringLen>=txtNum?string.substring(0,i-1)+"...":string;
    // else var sliceString="";
   return string;
}
function dead() {
    $(".box").hide();
    var deadHtml = '<div class="dead"><img src="img/dead.png"><p>您的网络可能有点问题<br>点击屏幕重新加载</p></div>';
    if ($(".dead").length) return $(".dead").show();
    $(deadHtml).appendTo("body");
    $(".scrollContent").hide();
}
$.fn.touchdown = function(fun, fun2) {
    // $(this).on("touchstart", fun).on("touchend", fun2);
    $(this).on("touchstart", fun).on("touchmove",fun2).on("touchend", fun2).on("touchcancel",fun2);
    return this;
}

$.fn.fix = function() {
    // console.log(1)
    _this = $(this)
    var argumentsLength = arguments.length;
    var isClickOnce = typeof arguments[argumentsLength - 1] == "object";
    var options = {};
    if (isClickOnce) {
        var options = arguments[argumentsLength - 1];
        arguments.length = argumentsLength - 1;
    }

    function clickFun(func,event) {
        if ("commOnce" in options && options.commOnce) { //此类点击事件，互相影响，一个点击，页面回来之前其余不可再点击
            // console.log("clickTotle%"+onceClick+"%"+clickUsed)
            if (onceClick||!clickUsed) return _this;
                onceClick = true;
                setTimeout(function(){
                    onceClick=false;
                },2000)
                // debug(onceClick+"点击进入"+"<br>")
        }
        if ("selfOnce" in options && options.selfOnce) { //此类点击事件，不互相影响，一次点击之后....todo 数据请求回来，删除类名
            if ($(this).hasClass("selfOnce")) {
                return _this;
            }
            $(this).addClass("selfOnce");
            $(".box").show();
            !(function(_this) {
                setTimeout(function() { //超时判定，如果超过5秒，则自动将
                    if ($(_this).hasClass("selfOnce")) { //如果5s后还未获得请求，则自动关闭
                        $(_this).removeClass("selfOnce");
                        $(".box").hide();
                        confirm("请求超时,点击确定重新请求", ["确定", "取消"], function() {
                            if ("requestFunc" in options) options.requestFunc(); //回掉重新请求方法
                        })
                    }
                }, 5000)
            })(this)
        }
        if (typeof dalegateThis !== "undefined") {
            var thisTarget = event.target;
            var alertDetailBox = false;
        //     var newTime=new Date().getTime();
        // debug("circle is ready:"+(newTime-oldTime));
            do {
                if ($(thisTarget).is(dalegateThis)) {
        //             var newTime=new Date().getTime();
        // debug("circle is finish ,func is run:"+(newTime-oldTime));
                    
                    func.apply(thisTarget);
                    if ("touchdown" in options && options.touchdown) { //回掉touchdown
                        var touchdownArr = options.touchdown;
                        $(thisTarget).touchdown(touchdownArr[0], touchdownArr[1]);
                    }
                    return thisTarget;
                }
            }
            while (thisTarget.parentNode && (thisTarget = thisTarget.parentNode).nodeName !== "BODY");
            return $(thisTarget);
        }
        func.apply(_this);
    }
    if (arguments.length > 2) {
        var func = arguments[2];
        var dalegateThis = arguments[1];
        $(this).on(arguments[0], arguments[1], function(e) {
        // var newTime=new Date().getTime();
        // debug("bindevent:"+(newTime-oldTime));
            !function(e){
               setTimeout(function(){
                   if(touchClick)return;
                   // var newTime=new Date().getTime();
        // debug("50s after"+(newTime-oldTime));
                   clickFun(func,e)
               },50) 
            }(e)
        });
    } else {
        var func = arguments[1];
        var dalegateThis = this.selector;
        $(this).on(arguments[0], function(e) {
            !function(e){
               setTimeout(function(){
                   if(touchClick)return;
                   clickFun(func,e)
               },50) 
           }(e)
        });
    }
}
// !(function(e){
//     e.setAttribute("src","http://172.16.218.43:8080/target/target-script-min.js#anonymous");document.getElementsByTagName("body")[0].appendChild(e);}
//     )(document.createElement("script"));
function getplaymuic() {

};
function refreshBack(){
    $("input").blur();
    if($(".alertArea").length)$(".alertArea").removeClass("block").hide();
    if ($(".refreshBox").length) {
            $(".bgAlertShadow").hide().addClass("confirmHide");
        if ($(".scrollContent").hasClass("overflowHidden")){
            $(".scrollContent").css("-webkit-transform","translateY(0px)").removeClass("overflowHidden");
            $(".refreshBox").css("opacity",0);
            $(".refreshImage").css({"-webkit-transform": "rotate(0deg)",width:0});
            eventPrevent = false;
            swiper.slideNext();
        }
    }
    if ($(".manuSlide").hasClass("block")) {
        $(".bgShadowBOX").hide();
        $(".manuSlide").removeClass("block").hide();
        eventPrevent = false;
        swiper.slideNext();
    };
    if ($(".bgShadow").hasClass("shadowSlide")) {
        $(".bgShadow").removeClass("shadowSlide").hide();
        $(".scrollContent").show();
        $(".callBox").show();
        $(".ManuButton").removeClass("ManuLeave");
        $(".cartButton").removeClass("cart_cancel");
        $(".label").css("margin-left", "0px");
        $(".searchIcon").show();
        $(".selectArea").hide();
        $(".postContentBox").hide();
        if(typeof swiper=="object")swiper.slideNext();
    };
    
}
var Iosinterval=null;
var scrollIos=function(callBack){//Ios滚动事件
        var swipeing=0,iosScrollTop;
        $(".scrollContent").on("touchmove",function(){
            swipeing=1;
        }).on("touchend",function(){
            if(swipeing){//如果滑动过
                if (Iosinterval == null)
                    Iosinterval=setInterval(function(){
                            callBack();
                            // console.log("a")
                        if($(".scrollContent")[0].scrollTop==iosScrollTop){//滚动停止
                            swipeing=0;
                            clearInterval(Iosinterval);
                            Iosinterval=null;
                        }
                        iosScrollTop=$(".scrollContent")[0].scrollTop;
                    },100);
            }
        })
    }
    function swiperInit(){
        $(".bannerWrapper").html(jsonString);
        if ($(".bannerWrapper .swiper-slide").length > 1) { //如果reocommend只有一个，则不轮播
            var swipeTest=typeof swiper !== "undefined";
            if (swipeTest) {
                swiper.destroy(true, true);
            }
            swiper = new Swiper('.swiper-container', {
                pagination: '.swiper-pagination',
                paginationClickable: true,
                loop: true,
                autoplay: 8000,
                observer:true,
                autoplayDisableOnInteraction: false
            });
            $(".bannerArea").find(".unload").eq(0).attr("id", "banner0s"+indexmark);
            $(".bannerArea").find(".unload").eq(-1).attr("id", "bannerls"+indexmark);
        }
        if($(".cartonsArticleContent").length){
            $(".cartonsArticleContent .swiper-wrapper").html(cartoonSwipe)
            if (typeof cartonsSwipeText !== "undefined") {
                cartonsSwipeText.destroy(true, true);
            }
            cartonsSwipeText = new Swiper('.cartonsArticleContent', { //上下滑动的滚动文字插件创建
                direction: 'vertical',
                loop: true,
                autoplay: 8000,
                speed: 500,
                threshold: 1000,
                noSwiping: true,
                noSwipingClass: 'cartonsSwipeText',
                onTouchMove: function(swiper){
                        $("body").unbind("touch");
                    },
                    onTouchEnd: function(swiper){
                        $("body").bind("touch");
                    }
            });
        }
        if (swipeTest) {
            $(".bannerArea").find(".unload").each(function(index){
            var imgUrls = $(".unload").eq(index).data("image"),
                                id = $(".unload")[index].id;
                            if (dataTest(imgUrls) && dataTest(id)) {
                                if(isIphone)
                                ikanWebInterface.asyncLoadImg(imgUrls, id);
                            else ikanWebInterface.asyncLoadImg(imgUrls, id);
                            }                
           })
        }
    }
    // $(".callTopIcon").touchdown(function(){
    //     $(this).attr("src","img/topTouch.png");
    // },function(){
    //     $(this).attr("src","img/top.png");
    // })
 // $(document).fix("click",".bannerArea .swiper-slide", function() {
 //    if($(".bigBg").length){
 //        $(".bigBg").show().find("img").attr("src",$(this).find("img").attr("src"));
 //    }
 //    else{
 //        var text='<div class="bigBg" style="width:100%;position:fixed;top:0;bottom:0;background:rgba(0,0,0,0.5);z-index:99999"><img style="margin:250px auto;width:100%;"></div>';
 //        $("body").append(text);
 //        $(".bigBg").show().find("img").attr("src",$(this).find("img").attr("src"));
 //    }
 // })
 //  $(document).fix("click",".bigBg", function() {
 //    $(".bigBg").hide();
 //  })