function init(json) {
    try {
        setTimeout(function() {
            initTry(json);
        }, 100);
    } catch (e) {
        document.write(e.name);
        document.write(e.number);
        document.write(e.description);
        document.write(e.message);
    }
}
var jsonString = '{"topic":{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/be74032b-cdc1-403a-b79f-a9af98376454.jpg","http://images.kandongman.com.cn/ximages/eb/poster/4a852c90-3e63-42db-9949-e56893e34be7.jpg"],"createtime":"2015-09-11","author":"爱看小编","title":"幼儿乐器 今天轻松哆来咪，明天高端音乐帝","content":"<img src=\"http://images.kandongman.com.cn/ximages/eb/poster/be74032b-cdc1-403a-b79f-a9af98376454.jpg\" alt=\"\" /><br />\n<br />\n<img src=\"http://images.kandongman.com.cn/ximages/eb/poster/4a852c90-3e63-42db-9949-e56893e34be7.jpg\" alt=\"\" />","url":"http://webimg.ikan.cn/test/ximages/eb/poster/6c754d03-4eb3-4d22-a899-86aa58cbfcb9.jpg","topicType":1,"topicId":43,"subTitle":"小泰克\u201c泰克琴\u201d给大家带来更多的惊喜","isOver":true,"startTime":"2015-09-11","endTime":"2015-10-11","shareurl":"http://172.16.218.11/mobile/mobileAppAddress.html?isRemote=0&redirectUrl=ikan://web/ikan_specialSubject.html#@ltcommand:5060,params:@lttopicId:43@gt@gt"}}';
function initTry(json) { //初始化页面方法
    if (json.indexOf("\"content\":")>-1) {
        json = json.split("\"content\":");
        contentIndex = json[1].indexOf("\":");
        if (contentIndex > -1) {
            var json1 = json[1].slice(contentIndex);
            var json0 = json[1].slice(0, contentIndex);
            var lastIndex = json0.lastIndexOf("\"");
            var lastProp = json0.slice(lastIndex + 1); //url
            var contentText = json0.slice(1, lastIndex - 2); //获取到的html内容
            json = json[0] + "\"" + lastProp + json1;
        } else {
            var lastContentIndex = json[1].indexOf("}");
            var contentText = json[1].slie(1, lastContentIndex - 1);
            var lastContent = json[1].slicce(lastContentIndex);
            json = json[0].slice(0, -1) + latContent;
        }
        contentText = contentText.replace(/(\\r\\n)/g, "<br/>").replace(/" "/g, "").replace(/(\\t)/g, "").replace(/\\/g, "");
    }
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    if (json.status && json.status == 9) {
        $(".box").hide();
        return confirm(json.err, ["确定"]);
    }
    if (isIphone) {
        json = json.RESPONSE_BODY;
         var iphoneComm = document.createElement("link");
        iphoneComm.rel = "stylesheet";
        iphoneComm.href = "css/commIphone.css";
        $("head").append(iphoneComm);
        $("html").css({position:"fixed",left:0,top:0});
    } else {
        addAndoridComm();
    }
    $(".specialSubjectArea").show();
    $(".box").hide();
    $(".scrollContent").css({"opacity":1,"padding-top":0});
    json = json.topic;
    $("header").find("span").html(json.title);
    var backBut = true,
        cartBat = true,
        performanceBut = true;
    $(".specialSubjectCons").html(contentText);
    var data1 = '<img src="' + json.url + '.640x400" data-url=' + json.url + ' data-id=' + json.topicId + '><div class="specialSubjectText content-long-to-dotted">' + json.title + '</div>';
    $(".specialSubjectArea").html(data1);
    $(".specialSubjectArea").on("click", function() {
        getplaymuic();
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this).find("img");
        if (!flag) {
            $(".classification").css("display", "none");
            flag = true;
            return;
        }
        ikanWebInterface.startIkanScheme(_this.data("url"),' ',9);
    });
    // if ($(".specialSubjectBox").height() < $("body").height()) {
    //     eventPrevent = true;
    // };
    $(document).on("click", ".subjectListTitle", function() {
        getplaymuic();
        ikanWebInterface.startIkanScheme();
    });
    $(".activity_lists").bind("click", function() {
        getplaymuic();
        if ($(".classification").hasClass("scaleAnimation")) {
            $(".classification").removeClass("scaleAnimation").addClass("scaleOutAnimation");
        }
    });
    // $(window).scroll(function() {
    //     if ($(".classification").css("display") == "block") {
    //         $(".classification").css("display", "none");
    //     }
    // });
    
    $(".specialSubjectBox")[0].addEventListener('touchmove', function(event) {
            $(".classification").css("display", "none");
            setTimeout(function() {
                flag = true;
            }, 100);
    }, false); 
    var BlankSpace=true;
    function javaTrim(str) {
         for (var i=0; (str.charAt(i)==' ') && i<str.length; i++);
         if (i == str.length) return ''; //whole string is space
         var newstr = str.substr(i);
         for (var i=newstr.length-1; newstr.charAt(i)==' ' && i>=0; i--);
         newstr = newstr.substr(0,i+1);
         return newstr;
    }
    function checkBlankSpace(str){
        while(str.lastIndexOf(" ")>=0){
            str = str.replace(" ","");
        }
        if(str.length == 0){
            BlankSpace=false;
        }else{
            BlankSpace=true;
        }
    }
    $("#share").on("click", function() {
        getplaymuic();
        var shareurl = json.url;
        var shareTitle = json.title;
        var num=json.shareurl.length;
        num=135-num/2;
        var content=$(".specialSubjectCons").eq(0).text();
        content=content.replace(/\n/g,'');
        checkBlankSpace(content);
        if (BlankSpace) {
            var shareContent = content.substring(0, num) + '···';
        }else{
            var shareContent = shareTitle;
        }
        ikanWebInterface.share(shareurl, shareTitle, shareContent, json.shareurl,9);
    });
    var videoHeight = $(".albumInformation").height();
    $(".specialSubjectCons").on("click", function(event) {
        getplaymuic();
        if (!flag) {
            return;
        }
        var clickOffset = event.clientY + document.body.scrollTop;
        var asas = $(".scrollContent")[0].scrollTop
        for (var i = 0; i < $(".albumInformation").length; i++) {
            var _thisOffset = lazyLoad.pageY($(".albumInformation")[i], "specialSubjectCons");
            // if (clickOffset <= _thisOffset && clickOffset <= _thisOffset + videoHeight)
            if (clickOffset <= _thisOffset - asas + videoHeight&& clickOffset >= _thisOffset - asas)
                ikanWebInterface.startIkanScheme("ikan://album/" + $(".albumInformation")[i].id,' ',9);
        }
    });
    $(document).unbind("click").on("click", ".productInformation", function() {
        getplaymuic();
        if (!flag) {
            return;
        }
        ikanWebInterface.startIkanScheme("ikan://product/" + this.id,' ',9);
    });
}
var flag = true;
var manuFunc=function() {
    getplaymuic();
    $(".alertDetail").removeClass("detailSelect");
    if (flag) {
        $(".classification").css("display", "block");
        flag = false;
    } else {
        $(".classification").css("display", "none");
        flag = true;
    }
};
//逻辑todo购物车
var back=function(){
    getplaymuic();
    ikanWebInterface.back();
};
function headerClickFunc(){
    var headerOptions={
        ".menuButton":manuFunc,
        ".J_backButton":back,
        ".callTopIcon":callTopFunc
    };
    return headerOptions;
}
$(function() {
    $(".menuButton").on("click", function() {
        if(androidVersionNum==0||androidVersionNum>=440)manuFunc.apply(this);
    });
     // init(jsonString);
    ikanWebInterface.docReady('');
    $(".J_backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".menuButton").touchdown(function() {
        $(this).css({
            "background": "url(img/specialSubjectListsGreen.png) no-repeat center",
            "backgroundSize":"31px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/specialSubjectLists.png) no-repeat center",
            "backgroundSize":"31px"
        });
    });
    $(".J_backButton").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
    });
    $(".alertDetail").click(function() {
        getplaymuic();
        $(this).addClass("detailSelect");
        $(".classification").css("display", "none");
        flag = true;
    });
    $(".alertDetail").touchdown(function(){
        $(this).addClass("detailSelect");
    },function(){
        $(this).removeClass("detailSelect");
    })
    $("#index").on("click", function() {
        getplaymuic();
        ikanWebInterface.ikanIndex();
    });
    $("body").click(function(event) {
        getplaymuic();
        var _this = event.target;
        var alertDetailBox = false;
        do {
            if ($(_this).hasClass("alertDetailBox") || _this.nodeName == "HEADER") {
                alertDetailBox = true;
            }
        }
        while (_this.offsetParent && (_this = _this.offsetParent).nodeName !== "BODY");
        if (!alertDetailBox) {
            $(".classification").css("display", "none");
            setTimeout(function() {
                flag = true;
            }, 100);
        }
    });
});