 var jsonString = '{"ageRange":[{"tagList":[{"tagId":53,"tagValue":"0-1岁","groupId":4,"tagName":"年龄"},{"tagId":54,"tagValue":"1-3岁","groupId":4,"tagName":"年龄"},{"tagId":55,"tagValue":"3-6岁","groupId":4,"tagName":"年龄"},{"tagId":56,"tagValue":"6-12岁","groupId":4,"tagName":"年龄"},{"tagId":57,"tagValue":"12岁+","groupId":4,"tagName":"年龄"}],"groupId":4,"cname":"年龄"}],"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"catagorys":[{"secondCatagoryVO":[{"cname":"摇铃床铃","catagoryId":10},{"cname":"学步健身","catagoryId":12},{"cname":"幼教启蒙","catagoryId":14},{"cname":"情景扮演","catagoryId":16},{"cname":"早教机","catagoryId":18}],"cname":"早教认知","isSelected":0,"catagoryId":1},{"secondCatagoryVO":[{"cname":"水杯水壶","catagoryId":19},{"cname":"餐具餐椅","catagoryId":20},{"cname":"浴室卫生","catagoryId":21}],"cname":"婴幼用品","isSelected":0,"catagoryId":2},{"secondCatagoryVO":[{"cname":"拼图","catagoryId":27},{"cname":"棋牌桌游","catagoryId":22},{"cname":"木制积木","catagoryId":23},{"cname":"立体拼插","catagoryId":24},{"cname":"彩泥粘土","catagoryId":26},{"cname":"拼图2","catagoryId":44},{"cname":"棋盘桌游2","catagoryId":45},{"cname":"木制积木","catagoryId":46}],"cname":"益智玩具","isSelected":0,"catagoryId":3},{"secondCatagoryVO":[{"cname":"靠垫抱枕","catagoryId":31},{"cname":"毛绒公仔","catagoryId":30},{"cname":"芭比卡通  ","catagoryId":28}],"cname":"毛绒人偶","isSelected":0,"catagoryId":4},{"secondCatagoryVO":[{"cname":"车船模型 ","catagoryId":32},{"cname":"动漫模型","catagoryId":33},{"cname":"遥控玩具","catagoryId":34},{"cname":"智能电动","catagoryId":35},{"cname":"轨道助力","catagoryId":36}],"cname":"模型电动","isSelected":0,"catagoryId":5},{"secondCatagoryVO":[{"cname":"绘画画笔","catagoryId":37},{"cname":"手工文具 ","catagoryId":38},{"cname":"书包箱包","catagoryId":39}],"cname":"文具绘画","isSelected":0,"catagoryId":6},{"secondCatagoryVO":[{"cname":"滑板单车","catagoryId":40},{"cname":"枪类玩具","catagoryId":42}],"cname":"户外运动","isSelected":0,"catagoryId":7}],"hotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"searchKey":"乐高","productHotKeys":["蓝猫淘气3000问","朵拉"],"knowledgeHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"products":[{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/d88625c7-04e2-49ce-a53b-69b2944bf9f9.jpg","totalNumber":323,"productCode":3001188,"price":139,"vprice":106,"sortNum":0,"storageStatus":0,"productName":"乐高 得宝系列 创意拼砌底板（2-5岁）","svprice":103,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/cde6366c-0a83-4bb3-9c8a-13c8f75f2955.jpg","totalNumber":323,"productCode":3001110,"price":799,"vprice":607,"sortNum":0,"storageStatus":1,"productName":"乐高 创意百变系列 单车店与咖啡厅 (9-14岁）","svprice":532,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/aa56af50-a9ef-4f6a-a897-28f7910a7430.jpg","totalNumber":323,"productCode":3001068,"price":199,"vprice":151,"sortNum":0,"storageStatus":1,"productName":"乐高 得宝系列 多合一礼品套装 （1.5-5岁）","svprice":142,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/ba794943-76c0-43f7-91f4-802dd155f6e6.jpg","totalNumber":323,"productCode":3001088,"price":699,"vprice":531,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 警用巡查直升机 (5-12岁)","svprice":467,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/fdc79e8b-2ced-4c43-a91b-066b21126e28.jpg","totalNumber":323,"productCode":3001215,"price":299,"vprice":227,"sortNum":0,"storageStatus":1,"productName":"乐高 得宝创意系列  基础大盒装大颗粒","svprice":207,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/f1e1c2d4-9410-4484-a665-638491088cfa.jpg","totalNumber":323,"productCode":3001118,"price":599,"vprice":455,"sortNum":0,"storageStatus":1,"productName":"乐高 女孩系列 丛林救援基地(7-12岁)","svprice":402,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/f7cc4244-131c-4912-b880-990034916cd8.jpg","totalNumber":323,"productCode":3001107,"price":249,"vprice":189,"sortNum":0,"storageStatus":1,"productName":"乐高 创意系列 四轮越野摩托 (7-12岁）","svprice":175,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/8e13a54e-24ad-4a1b-a8b3-49d82c642a67.jpg","totalNumber":323,"productCode":3001035,"price":799,"vprice":607,"sortNum":0,"storageStatus":0,"productName":"乐高 得宝创意拼砌系列 娃娃屋 （2-5岁）","svprice":532,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/dfe7fd57-4d07-4e27-96dc-fe6cbbdac96c.jpg","totalNumber":323,"productCode":3001109,"price":68,"vprice":33,"sortNum":0,"storageStatus":0,"productName":"乐高 创意系列 红色的咆哮 (7-12岁）","svprice":29.9,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/8bca6e93-596b-4c7e-aa69-11938d65a0de.jpg","totalNumber":323,"productCode":3001007,"price":499,"vprice":7777,"sortNum":0,"storageStatus":0,"productName":"乐高 女孩系列 斯蒂芬妮的沙滩小屋 （6-12岁）","svprice":7777,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/3bc067cd-3357-495f-908c-424fd678e4b7.jpg","totalNumber":323,"productCode":3001189,"price":449,"vprice":341,"sortNum":0,"storageStatus":0,"productName":"乐高 女孩系列 心湖城灯塔（6-12岁）","svprice":305,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/e5724bd6-6550-49b7-b166-f57b460f224e.jpg","totalNumber":323,"productCode":3001095,"price":199,"vprice":151,"sortNum":0,"storageStatus":1,"productName":"乐高 得宝婴童系列 创意小船组（1.5-3岁）","svprice":142,"status":1}],"sortVos":[{"sortName":"价格最高","sortId":0},{"sortName":"价格最低","sortId":1},{"sortName":"最新上架","sortId":2},{"sortName":"评价最佳","sortId":3},{"sortName":"销量最多","sortId":4},{"sortName":"折扣最高","sortId":5}],"filterInfo":{"brandInfo":{"selectBrandId":0,"brands":[{"brandName":"LEGO/乐高","brandId":14},{"brandName":"Fisher-Price/费雪","brandId":12},{"brandName":"Barbie/芭比娃娃","brandId":22},{"brandName":"THOMAS&FRIENDS/托马斯","brandId":21},{"brandName":"澳贝","brandId":39},{"brandName":"贝恩施","brandId":47},{"brandName":"Hape","brandId":50},{"brandName":"NERF/热火","brandId":45},{"brandName":"Silverlit/银辉","brandId":19},{"brandName":"Siku","brandId":23},{"brandName":"BRIO","brandId":29},{"brandName":"ubbie/优彼","brandId":43},{"brandName":"木玩世家","brandId":26},{"brandName":"培培乐","brandId":4},{"brandName":"SpongeBob/海绵宝宝","brandId":17},{"brandName":"Disney/迪士尼","brandId":10},{"brandName":"熊出没","brandId":15},{"brandName":"Zoobies/如比","brandId":6},{"brandName":"Masterkidz/贝思德","brandId":36},{"brandName":"爱可丽","brandId":31},{"brandName":"Pororo&Friends/啵乐乐","brandId":9},{"brandName":"HelloKitty/凯蒂猫","brandId":7},{"brandName":"凯佩珑","brandId":33},{"brandName":"英德","brandId":16},{"brandName":"Colorato/卡乐淘","brandId":5},{"brandName":"DreamWorks/梦工厂","brandId":18},{"brandName":"Transformers/变形金刚","brandId":25},{"brandName":"喜羊羊与灰太狼","brandId":41},{"brandName":"RobocarPoli","brandId":20},{"brandName":"Schleich/思乐","brandId":24},{"brandName":"索凡","brandId":32},{"brandName":"小马宝莉","brandId":44},{"brandName":"KOKADO/高佳多","brandId":30},{"brandName":"米米智玩","brandId":27},{"brandName":"富尔达","brandId":8}],"cname":"品牌","sortNum":0},"tags":[{"tagList":[{"tagId":60,"tagValue":"布艺","groupId":16,"tagName":"材质"},{"tagId":61,"tagValue":"塑料","groupId":16,"tagName":"材质"},{"tagId":62,"tagValue":"金属","groupId":16,"tagName":"材质"},{"tagId":63,"tagValue":"毛绒","groupId":16,"tagName":"材质"},{"tagId":64,"tagValue":"胶泥","groupId":16,"tagName":"材质"},{"tagId":65,"tagValue":"纸质","groupId":16,"tagName":"材质"},{"tagId":66,"tagValue":"木质","groupId":16,"tagName":"材质"},{"tagId":67,"tagValue":"玻璃","groupId":16,"tagName":"材质"},{"tagId":68,"tagValue":"其他","groupId":16,"tagName":"材质"}],"groupId":16,"cname":"材质","sortNum":2},{"tagList":[{"tagId":69,"tagValue":"红/粉/紫","groupId":17,"tagName":"颜色"},{"tagId":70,"tagValue":"??黄/橙/棕?","groupId":17,"tagName":"颜色"},{"tagId":71,"tagValue":"?蓝/绿/青?","groupId":17,"tagName":"颜色"},{"tagId":72,"tagValue":"?黑/白/灰","groupId":17,"tagName":"颜色"}],"groupId":17,"cname":"颜色","sortNum":3},{"tagList":[{"tagId":75,"tagValue":"变形金刚/Transformers","groupId":18,"tagName":"动漫周边"},{"tagId":76,"tagValue":"小马宝莉/My Little Pony","groupId":18,"tagName":"动漫周边"},{"tagId":77,"tagValue":"漫威/Marvel","groupId":18,"tagName":"动漫周边"},{"tagId":78,"tagValue":"托马斯&朋友/Thomas＆Friends","groupId":18,"tagName":"动漫周边"},{"tagId":79,"tagValue":"芭比/Barbie","groupId":18,"tagName":"动漫周边"},{"tagId":83,"tagValue":"喜羊羊与灰太狼","groupId":18,"tagName":"动漫周边"},{"tagId":84,"tagValue":"超能陆战队","groupId":18,"tagName":"动漫周边"},{"tagId":85,"tagValue":"冰雪奇缘","groupId":18,"tagName":"动漫周边"},{"tagId":86,"tagValue":"小公主苏菲亚","groupId":18,"tagName":"动漫周边"},{"tagId":87,"tagValue":"米老鼠和唐老鸭","groupId":18,"tagName":"动漫周边"},{"tagId":88,"tagValue":"变形警车珀利","groupId":18,"tagName":"动漫周边"},{"tagId":89,"tagValue":"铠甲勇士","groupId":18,"tagName":"动漫周边"},{"tagId":90,"tagValue":"巴啦啦小魔仙","groupId":18,"tagName":"动漫周边"},{"tagId":91,"tagValue":"火力少年王","groupId":18,"tagName":"动漫周边"},{"tagId":92,"tagValue":"超级飞侠","groupId":18,"tagName":"动漫周边"},{"tagId":93,"tagValue":"快乐酷宝","groupId":18,"tagName":"动漫周边"},{"tagId":94,"tagValue":"小企鹅啵乐乐","groupId":18,"tagName":"动漫周边"},{"tagId":176,"tagValue":"凯蒂猫/HelloKitty","groupId":18,"tagName":"动漫周边"},{"tagId":177,"tagValue":"海绵宝宝/SpongeBob","groupId":18,"tagName":"动漫周边"},{"tagId":178,"tagValue":"马达加斯加的企鹅","groupId":18,"tagName":"动漫周边"},{"tagId":179,"tagValue":"驯龙高手","groupId":18,"tagName":"动漫周边"},{"tagId":180,"tagValue":"熊出没","groupId":18,"tagName":"动漫周边"},{"tagId":181,"tagValue":"愤怒的小鸟/Angry Birds","groupId":18,"tagName":"动漫周边"},{"tagId":189,"tagValue":"白雪公主和七个小矮人","groupId":18,"tagName":"动漫周边"},{"tagId":190,"tagValue":"小美人鱼","groupId":18,"tagName":"动漫周边"},{"tagId":195,"tagValue":"海贼王","groupId":18,"tagName":"动漫周边"},{"tagId":230,"tagValue":"黑猫警长","groupId":18,"tagName":"动漫周边"},{"tagId":236,"tagValue":"小熊维尼","groupId":18,"tagName":"动漫周边"},{"tagId":237,"tagValue":"星际宝贝","groupId":18,"tagName":"动漫周边"},{"tagId":238,"tagValue":"灰姑娘","groupId":18,"tagName":"动漫周边"},{"tagId":239,"tagValue":"赛车总动员","groupId":18,"tagName":"动漫周边"}],"groupId":18,"cname":"动漫周边","sortNum":4},{"tagList":[{"tagId":182,"tagValue":"0-100","groupId":2,"tagName":"价格"},{"tagId":183,"tagValue":"100-300","groupId":2,"tagName":"价格"},{"tagId":184,"tagValue":"300-500","groupId":2,"tagName":"价格"},{"tagId":185,"tagValue":"500-800","groupId":2,"tagName":"价格"},{"tagId":186,"tagValue":"800+","groupId":2,"tagName":"价格"}],"groupId":2,"cname":"价格","sortNum":5},{"tagList":[{"tagId":58,"tagValue":"男孩","groupId":14,"tagName":"性别"},{"tagId":59,"tagValue":"女孩","groupId":14,"tagName":"性别"}],"groupId":14,"cname":"性别","sortNum":1}]}}';
 function init(json) {
 	// try {
 	// initTest(json)
 	// } catch (e) {
 	//     document.write(e.name);
 	//     document.write(e.number);
 	//     document.write(e.description);
 	//     document.write(e.message);
 	//     document.write(json)
 	// }
 	setTimeout(function() {
 			initTest(json);
 		},
 		100);
 }
 var hotKeysBox = [];
var hotKeysJson={};
var  noService=false;
 function initTest(json) { //初始化页面方法
 	var search = '<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
 	search.innerHTML = "";
 	$(".bgShadow").html(search);
 	$(".box").hide();
 	$(".scrollContent").show();
 	json = typeof(json) == "string" ? JSON.parse(json) : json;
 	jsonFilter.page = 0;
 	jsonFilter.pageSize = 12;
 	jsonFilter.searchKey = json.searchKey;
 	console.log(json)
 	if (json.albumHotKeys) hotKeysJson.albumHotKeys = json.albumHotKeys;
 	if (json.productHotKeys) hotKeysJson.productHotKeys = json.productHotKeys;
 	if (json.knowledgeHotKeys) hotKeysJson.knowledgeHotKeys = json.knowledgeHotKeys;
 	if (json.recommendHotKeys) hotKeysJson.recommendHotKeys = json.recommendHotKeys;
 	$("#search").val(inputSlice(json.searchKey));
 	$(".heaerTitle").text(json.title);
 	$(".emptyHistory").click(function() {
        confirm("确认清空搜索历史记录？", ["确认", "取消"],
        function() {
            $(".searchVagaa").hide();
            hotKeysBox = [];
            window.localStorage.clear();
        }),
        function() {};
    });
 	if (json.status && json.status == 10) {
 		dead();
 		var localhotKeys = window.localStorage;
 		$("#search").html(localhotKeys[0])
 		$(".dead").unbind("click").on("click",
 			function() {
 				getplaymuic();
 				ikanWebInterface.reloadPage();
 				$(".bgShadow").hide();
 				// ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
 				$(".box").show();
 				$(".dead").hide();
 			});
 		return;
 	}
 	if (json.status && json.status == 9) {
 		$("#searchImg").show();
 		$(".scrollContent").hide();
 		$(".box").hide();
 		noService=true;
 		// loadImage("scrollContent", function() {});
 		return;
 	}
 	var hasBrandInfo = "filterInfo" in json && "brandInfo" in json.filterInfo && "selectBrandId" in json.filterInfo.brandInfo;
 	if (hasBrandInfo && json.filterInfo.brandInfo.selectBrandId) {
 		var jsonInfo = {
 			"brandId": json.filterInfo.brandInfo.selectBrandId
 		};
 		jsonFilter.filterInfo = jsonInfo;
 		$(".categoryIcon1").attr("src", "img/640_06.png");
 	}
 	data1 = json.products;
 	
 	dataManu = [{
 		"imageUrl": "img/index/baby.png",
 	}, {
 		"imageUrl": "img/index/children.png",
 	}, {
 		"imageUrl": "img/index/bulidingblock.png",
 	}, {
 		"imageUrl": "img/index/plushtoys.png",
 	}, {
 		"imageUrl": "img/index/model.png",
 	}, {
 		"imageUrl": "img/index/handwork.png",
 	}, {
 		"imageUrl": "img/index/fitness.png",
 	}];
 	$(".box").hide();


 	var backBut = true,
 		cartBat = true,
 		performanceBut = true;
 	data9 = json.productHotKeys;
 	if (data9) {
 		for (var htmls = "",
 				i = 0; i < data9.length; i++) {
 			htmls += '<span id="hotKeys' + i + '">' + data9[i] + '</span>';
 		}
 		$(".hotKeys").html(htmls);
 	}
 	if (data9 == null) {
 		$(".hotKeys").hide()
 		$(".hotText").hide()
 	}
 	if (data1.length == 0 && pageIndex == 0) {
 		$("#searchImg").show();
 		$(".scrollContent").hide();
 		$(".box").hide();
 		noService=true;
 		// loadImage("scrollContent", function() {});
 	}else{
		productLoad(json);
 	}
 	$(".scrollContent").animate({
 			opacity: 1
 		},
 		300);

 	function callPageLoad(pageIndex) { //分页回掉函数
 		jsonFilter.pageSize = 12;
 		jsonFilter.page = pageIndex;
 		ikanWebInterface.command(5069, JSON.stringify(jsonFilter), "productLoad",48);
 	}
 	loadImage("scrollContent", callPageLoad);
 	var markPostionArr = ["1.8rem", "5.4rem", "9.75rem", "13.6rem"];
 	var categoryContentObj = $("div[class^='categoryContent']");
 	var categoryInterval = null;
 	var preIndex = 0;
 	$(".categoryDetailButton").unbind("click").bind("click",
 		function(event) {
 			getplaymuic();
 			clearTimeout(categoryInterval);
 			if ($(".alertArea").css("display") == "block") {
 				$(".alertArea").css("display", "none");
 			}
 			$(".callTopButton").hide();
 			$(".bg").removeClass("translateHide").css("opacity", 1);
 			// $(".categoryArea").css("border-bottom", "1px solid #fff");
 			eventPrevent = true;
 			var categoryIndex = $(this).index();
 			if ($(".translateShow").length == 0) {
 				$(".categoryContentArea").show().css({
 					opacity: 1
 				});
 			}
 			// if(categoryIndex==2){
 			//  	         if (isIphone){
 			//  	     	 			$(".scrollContent").addClass("CategoryPg");
 			//  		        }else{
 			//  	     	 			$(".scrollContent").addClass("CategoryAz");
 			//  		     }
 			//  }
 			if (categoryContentObj.eq(categoryIndex).hasClass("translateShow")) {
 				eventPrevent = false;
 				$(".bgColor").hide();
 				$(".scrollContent").css({
 					"overflow": "auto"
 				});
 				$(".categoryMark").hide();
 				categoryInterval=setTimeout(function(){$(".categoryContentArea").hide();},500)
 				categoryContentObj.eq(categoryIndex).removeClass("translateShow").addClass("translateHide");
 				$(".categoryIcon").attr("src", "img/640_16.png");
 				$(".categoryIcon1").attr("src", "img/640_11.png");
 				if (jsonFilter.filterInfo) {
 					$(".categoryIcon1").attr("src", "img/640_06.png");
 				}
 				return;
 			}
 			$(".bgColor").show();
 			$(".categoryMark").css({
 				left: markPostionArr[categoryIndex]
 			}).show();
 			var categoryContentEval = "categoryContent" + categoryIndex + "()";
 			$(".categoryIcon").attr("src", "img/640_16.png");
 			$(".categoryIcon1").attr("src", "img/640_11.png");
 			if (jsonFilter.filterInfo) {
 				$(".categoryIcon1").attr("src", "img/640_06.png");
 			}
 			$(".categoryIcon").eq(categoryIndex).attr("src", "img/640_14.png");
 			eval(categoryContentEval);
 			$(".manuArea").hide();
 			if (categoryIndex == 3) {
 				$(".categoryIcon1").attr("src", "img/640_06.png");
 				setTimeout(function() {
 						$(".manuArea").css({
 							display: "-webkit-box"
 						}).removeClass("translateHide");
 					},
 					0);
 			}
 			if ($(".translateShow").length) {
 				categoryContentObj.eq(preIndex).removeClass("translateShow");
 			} else {
 				$(".categoryContentArea").show().css({
 					opacity: 1
 				});
 			}
 			categoryContentObj.removeClass("translateHide").removeClass("translateShow").addClass("translateHide").eq(categoryIndex).removeClass("translateHide").addClass("translateShow");
 			preIndex = categoryIndex;
 			if ($(".categoryContentArea").css("display") == "block") {
 				$(".bg").unbind("click").click(function() {
 					getplaymuic();
 					$(".scrollContent").css({
 						"overflow": "auto"
 					});
 					$(".categoryMark").hide();
 					eventPrevent = false;
 					$(".bgColor").hide();
 					$(".translateShow").removeClass("translateShow").addClass("translateHide");
 					setTimeout(function(){$(".categoryContentArea").hide()},500);
 					$(".categoryIcon").attr("src", "img/640_16.png");
 					if (jsonFilter.filterInfo) {
 						$(".categoryIcon1").attr("src", "img/640_06.png");
 					} else {
 						$(".categoryIcon1").attr("src", "img/640_11.png");
 					}
 				});
 			}
 		});
 	//综合排序

 	function categoryContent0() {
 		if ($(".rankCategoryArea").length == 0) {
 			data1 = json.sortVos;
 			var categoryHtml = '<div class="rankCategoryArea noLimitedRank"><span class="selectCategory">综合排序</span><img src="img/index/categorySelect.png" alt="" style="display:block"></div>';
 			for (var i = 0; i < data1.length; i++) {
 				categoryHtml += '<div class="rankCategoryArea" data-id=' + data1[i].sortId + ' data-group=' + data1[i].groupId + '><span>' + data1[i].sortName + '</span><img src="img/index/categorySelect.png" alt=""></div>';
 			}
 			$(".categoryContentDetail1").html(categoryHtml);
 			$(".rankCategoryArea").click(function() {
 				getplaymuic();
 				if (isIphone) {
 					$(".scrollContent").removeClass("CategoryPg");
 				} else {
 					$(".scrollContent").removeClass("CategoryAz");
 				};
 				$(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
 				$(this).find("span").addClass("selectCategory").parent().find("img").show();
 				if ($(this).hasClass("noLimitedRank")) {
 					delete jsonFilter.sortId;
 					$(".categoryDetailButton span").eq(0).html("综合排序");
 				} else {
 					$(".categoryDetailButton span").eq(0).html($(this).find("span").html());
 					jsonFilter.sortId = $(this).data("id");
 				}
 				selectCategoryOut();
 				$(".box").css("display", "-webkit-box");
 				if (jsonFilter.filterInfo) {
 					$(".categoryIcon1").attr("src", "img/640_06.png");
 				}
 				jsonFilter.pageSize = 12;
 				jsonFilter.page = 0;
 				pageIndex = 0;
 				ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 			});
 		}
 	}

 	function categoryContent1() {
 		if ($(".babyAgeSelectDetail").length == 0) {
 			$(".babySelectTitle").data("group", json.ageRange[0].groupId);
 			var dataGroup = json.ageRange[0].groupId;
 			var data2 = json.ageRange[0].tagList;
 			var categoryHtml = '<div class="babyAgeSelectDetail noLimitedAge">不限</div>';
 			for (var i = 0; i < data2.length; i++) {
 				categoryHtml += '<div class="babyAgeSelectDetail" data-id=' + data2[i].tagId + '>' + data2[i].tagValue + '</div>';
 			}
 			$(".babyAgeSelect").html(categoryHtml);
 			$(".babyAgeSelectDetail").click(function() {
 				getplaymuic();
 				//          if (isIphone) {
 				// 	    $(".scrollContent").removeClass("CategoryPg");
 				// }else{
 				//  	$(".scrollContent").removeClass("CategoryAz");
 				// };
 				$(".babyAgeSelectDetail").removeClass("selectCategory");
 				$(this).addClass("selectCategory");
 				if ($(this).hasClass("noLimitedAge")) {
 					delete jsonFilter.ageRange;
 					$(".categoryDetailButton span").eq(1).html("年龄");
 				} else {
 					$(".categoryDetailButton span").eq(1).html($(this).text());
 					var ageRange = {};
 					ageRange.groupId = dataGroup;
 					ageRange.tagId = $(this).data("id");
 					jsonFilter.ageRange = ageRange;
 				}
 				selectCategoryOut();
 				$(".box").css("display", "-webkit-box");
 				if (jsonFilter.filterInfo) {
 					$(".categoryIcon1").attr("src", "img/640_06.png");
 				}
 				jsonFilter.pageSize = 12;
 				jsonFilter.page = 0;
 				pageIndex = 0;
 				ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 			});
 		}
 	}
 	var cateMainNum=1;
 	function categoryContent2() {
 		if (isIphone) {
 			eventPrevent = false;
 			$(".categoryListBox").css("height", "15.4rem");
 			$(".scrollContent").css("overflow", "hidden");
 		}
 		if ($(".categoryMainListDetail").length == 0) {
 			data3 = json.catagorys;
 			var categoryHtml = "";
 			var selectStyle = "";
 			for (var i = 0; i < data3.length; i++) {
 				selectStyle = data3[i].isSelected ? " categoryMainListSelect" : "";
 				categoryHtml += '<div class="categoryMainListDetail' + selectStyle + '" data-id=' + data3[i].catagoryId + '><img src="' + dataManu[i].imageUrl + '" alt=""><span>' + data3[i].cname + '</span></div>';
 			}
 			$(".categoryMainList").append(categoryHtml);
 			var selectedIndex = ""
 				function addCategoryDetail(num) {
 					num--;
 					var categoryHtml = "";
 					var detailListObj = data3[num].secondCatagoryVO;
 					for (var i = 0; i < detailListObj.length; i++) {
 						categoryHtml += '<div class="categoryDetailListName" data-id=' + detailListObj[i].catagoryId + '><span>' + detailListObj[i].cname + '</span><img src="img/index/categorySelect.png" alt="" class="categoryDetailListNameImg"></div>';
 					}
				   $(".noLimitedCategory").find("img").hide();
 					if(selectedText!==""&&categoryHtml.indexOf(selectedText)>-1){
 					   $(".categoryDetailListName span").eq(selectedIndex+1).siblings("img").show()
 					}else if(json.title&&json.title==$(".categoryMainListSelect span").text()&&(selectedText==undefined||selectedText=="不限")){
 					   $(".noLimitedCategory").find("img").show();
 					}
 					$(".categoryDetailList").html(categoryHtml);
 					// if (categoryHtml.indexOf(selectedText) > -1) {
 					// 	$(".categoryDetailListName span").eq(selectedIndex + 1).siblings("img").show()
 					// }
 					$(".categoryDetailListName").click(function() {
 						getplaymuic();
 						//       if (isIphone) {
 						//    $(".scrollContent").removeClass("CategoryPg");
 						// }else{
 						//     $(".scrollContent").removeClass("CategoryAz");
 						// }
 						if ($(this).hasClass("noLimitedCategory")) {
 							$(".heaerTitle").html($(".categoryMainListSelect").text());
 							json.title=$(".categoryMainListSelect span").text();
 							delete jsonFilter.categoryId;
 							jsonFilter.rootCategoryId = $(".categoryMainListSelect").data("id");
 							$(".categoryDetailButton span").eq(2).html("分类");
 						} else {
 							$(".categoryDetailButton span").eq(2).html($(this).text());
 							jsonFilter.categoryId = $(this).data("id");
 							delete jsonFilter.rootCategoryId;
 							$(".heaerTitle").html($(".categoryMainListSelect").text());
 						}
 						$(".categoryDetailListNameImg").hide()
 						$(this).find("img").show();
 						selectedText = $(this).find("span").text()
 						selectedIndex = $(this).index()
 						selectCategoryOut();
 						$(".box").css("display", "-webkit-box");
 						if (jsonFilter.filterInfo) {
 							$(".categoryIcon1").attr("src", "img/640_06.png");
 						}
 						if (isIphone) {
 							$(".scrollContent").css("overflow", "auto");
 						}
 						jsonFilter.pageSize = 12;
 						jsonFilter.page = 0;
 						pageIndex = 0;
 						ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 					});
 				}
 			// addCategoryDetail(cateMainNum);
 			$(".categoryListBox").hide();
 			$(".categoryMainLimite").click(function(){
 				cateMainNum = 1;
 				selectedText="";
 				$(".categoryListBox").hide();
                $(".heaerTitle").html("全部分类");
             	$(this).addClass("categoryMainListSelect");
             	$(".categoryDetailButton").eq(2).find("span").text("分类");
             	$(".categoryDetailButton").eq(2).find("span").removeClass("greenFont")
             	$(".categoryMainListDetail").removeClass("categoryMainListSelect");
             	selectCategoryOut();
                if(jsonFilter.rootCategoryId) delete jsonFilter.rootCategoryId;
                if(jsonFilter.categoryId) delete jsonFilter.categoryId;
             	jsonFilter.pageSize = 12;
 				jsonFilter.page = 0;
 				pageIndex = 0;
 				ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
             }).addClass("categoryMainListSelect");
 			$(".categoryMainListDetail").click(function() {
 				getplaymuic();
 				cateMainNum = $(this).index();
 				$(".categoryListBox").show();
 				$(".categoryMainLimite").removeClass("categoryMainListSelect");
 				$(".categoryMainListDetail").removeClass("categoryMainListSelect");
 				$(this).addClass("categoryMainListSelect");
 				addCategoryDetail(cateMainNum);
 			});
 		}
 	}

 	function categoryContent3() {
 		eventPrevent = false;
 		if ($(".filterSelectContentDetail").length == 0) {
 			var categoryHtml = "";
 			var sortNumFiter = {};
 			data4 = json.filterInfo;
 			var data4Keys = Object.keys(data4); //获得品牌等的key；
 			for (var i = 0; i < data4Keys.length; i++) { //对keys进行遍历
 				categoryButtonHtml = "",
 				dataDetail = data4[data4Keys[i]]; //便利得到的品牌等的对象或数组
 				if (dataDetail instanceof Array) { //如果是数组就继续遍历获得对象
 					for (var k = 0; k < dataDetail.length; k++) { //继续遍历该数组
 						dataDetailCont = dataDetail[k]; //获取到颜色等对象，输入创建筛选内容函数
 						categoryHtmlAdd(dataDetailCont);
 					}
 				} else {
 					categoryHtmlAdd(dataDetail);
 				}

 				function categoryHtmlAdd(dataDetails) { //创建筛选内容函数，dataDetails为相应的颜色或者品牌对象
 					categoryHtml = "";
 					var selectId = false;
 					var groupIdHtml = "";
 					for (var detailkeys in dataDetails) { //统一变量
 						if (detailkeys.indexOf("select") > -1) {
 							selectId = dataDetails[detailkeys];
 						}
 						if (detailkeys == "groupId") { //如果长度大于2，则是标签有groupId
 							groupIdHtml = 'data-group=' + dataDetails.groupId;
 						}
 						if (dataDetails[detailkeys] instanceof Array) { //如果是数组，那么该keys就是列表
 							taglist = detailkeys;
 						}
 					}
 					//在下面对获取到的特定变量进行同等操作
 					var dataDetailArr = dataDetails[taglist];
 					for (var keys in dataDetailArr[0]) { //统一变量
 						if ("groupId" in dataDetailArr[0]) {
 							tagId = "tagId";
 							tagValue = "tagValue";
 						} else {
 							if (keys.indexOf("Id") > -1) {
 								tagId = keys;
 							} else {
 								tagValue = keys;
 							}
 						}
 					}
 					for (var categoryButtonHtml = "",
 							j = 0; j < dataDetailArr.length; j++) {
 						var selectStyle = (selectId && dataDetailArr[j][tagId] == selectId) ? " filterSelectedButton" : "";
 						categoryButtonHtml += '<div class="filterSelectContentDetail' + selectStyle + '" data-id=' + dataDetailArr[j][tagId] + ' data-keys=' + tagId + '><span>' + dataDetailArr[j][tagValue] + '</span></div>';
 					}
 					categoryHtml += '<section class="filterArea"' + groupIdHtml + '><div class="filterSelectTitle"><span class="filterTitleName">' + dataDetails.cname + ':</span><p class="content-long-to-dotted">不限</p><img src="img/textButton1.png" alt=""></div><div class="filterSelectContent">' + categoryButtonHtml + '</div></section>';
 					sortNumFiter[dataDetails.sortNum] = categoryHtml;

 				}
 				//立即调用
 			}
 			for (var i = 0,
 					categoryHtml = ""; i in sortNumFiter; i++) {
 				categoryHtml += sortNumFiter[i];
 			}
 			$(".categoryContentDetail4").html(categoryHtml);
 			if ($(".filterSelectedButton").length) {
 				var _this = $(".filterSelectedButton");
 				_this.parent().parent().find(".content-long-to-dotted").html(_this.html()).data("define", "不限");
 				$(".categoryIcon1").attr("src", "img/640_11.png");
 			}
 			var buttonHeight = $(window).width() / 10;
 			$.each($(".filterSelectContent"),
 				function(index, item) {
 					!
 						function(_this) {
 							setTimeout(function() {
 									var thisHeight = $(_this).height();
 									$(_this).data("height", thisHeight);
 									$(_this).css({
 										height: buttonHeight
 									});
 									if (thisHeight < buttonHeight * 1.5) $(_this).parent().find("img").addClass("triggleHide").hide();
 								},
 								10);
 					}(this);
 				});
 			$(".filterSelectTitle").click(function() {
 				$(".categoryContentDetail4").css({
 					"overflow": "hidden"
 				});
 				setTimeout(function() {
 						$(".categoryContentDetail4").css({
 							"overflow": "auto"
 						});
 					},
 					600);
 				getplaymuic();
 				if ($(this).find("img").hasClass("triggleHide")) return;
 				$(this).find("img").toggleClass("zhuan");
 				var dataHeight, _this = $(this).parent().find(".filterSelectContent");
 				dataHeight = $(this).parent().find(".filterSelectContent").data("height");
 				dataHeight = dataHeight - 0;
 				_this.data("height", _this.height()).height(dataHeight);
 			});
 			$(".filterSelectContentDetail").click(function() {
 				getplaymuic();
 				var contentLong = $(this).parent().parent().find(".content-long-to-dotted");
 				var contentLongHtml = contentLong.data("content"),
 					buttonContent = $(this).find("span").html(),
 					contentLongText;
 				if ($(this).hasClass("filterSelectedButton")) {
 					$(this).removeClass("filterSelectedButton");
 					contentLong.html(contentLong.data("define"));
 					return;
 				}
 				$(this).parent().find(".filterSelectContentDetail").removeClass("filterSelectedButton");
 				$(this).addClass("filterSelectedButton");
 				if (contentLong.html().indexOf("不限") > -1) {
 					contentLong.data("define", contentLong.html());
 				}
 				contentLong.html(buttonContent);
 			});
 			// $(".filterSelectContentDetail").click(function() {
 			//     var contentLong = $(this).parent().parent().find(".content-long-to-dotted");
 			//     var contentLongHtml = contentLong.data("content"),
 			//         buttonContent = $(this).find("span").html(),
 			//         contentLongText;
 			//     if ($(this).hasClass("filterSelectedButton")) {
 			//         $(this).removeClass("filterSelectedButton");
 			//         var buttonContentPlace = contentLongHtml.indexOf(buttonContent);
 			//         if (buttonContentPlace > -1) {
 			//             if (buttonContentPlace > 0) {
 			//                 buttonContent = "&nbsp;" + buttonContent;
 			//             }
 			//             if (contentLongHtml == buttonContent) {
 			//                 contentLongHtml = contentLong.data("define");
 			//                 contentLong.html(contentLongHtml).data("content", contentLongHtml);
 			//                 return;
 			//             }
 			//             contentLongHtml = contentLongHtml.split(buttonContent);
 			//             contentLongHtml = contentLongHtml.join("");
 			//             contentLong.html(contentLongHtml).data("content", contentLongHtml);
 			//         }
 			//         contentLong.html(contentLong.data("define"));
 			//         return;
 			//     }
 			//     $(this).parent().find(".filterSelectContentDetail").removeClass("filterSelectedButton");
 			//     $(this).addClass("filterSelectedButton");
 			//     if (contentLong.html().indexOf("所有") > -1) {
 			//         contentLong.data("define", contentLong.html()).html($(this).find("span").html()).data("content", $(this).find("span").html());
 			//         return;
 			//     }
 			//     contentLongText = contentLongHtml + "&nbsp;" + buttonContent;
 			//     if (contentLong.html() !== contentLong.data("content")) {
 			//         return;
 			//     }
 			//     if (contentLong.html().indexOf("所有") > -1) {
 			//     	contentLong.data("define",contentLong.html())	
 			//     }
 			//     contentLong.html(buttonContent);
 			// })
 		}
 	}
 	$(".manuArea div").eq(0).click(function() { //重置按钮
 		getplaymuic();
 		//   if (isIphone) {
 		// 	    $(".scrollContent").removeClass("CategoryPg");
 		// }else{
 		//  	$(".scrollContent").removeClass("CategoryAz");
 		// };
 		$(".filterSelectContentDetail").removeClass("filterSelectedButton");
 		$(".categoryIcon").attr("src", "img/640_16.png");
 		$(".categoryIcon1").attr("src", "img/640_11.png");
 		$.each($(".content-long-to-dotted"),
 			function(index, item) {
 				if ($(item).data("define")) {
 					var itemDefine = $(item).data("define");
 					$(item).html(itemDefine).data("content", itemDefine);
 				}
 			});
 	});

 	function selectCategoryOut() {
 		eventPrevent = false;
 		$(".scrollContent").css({
 			"overflow": "auto"
 		});
 		$(".bgColor").hide();
 		$(".translateShow").removeClass("translateShow").addClass("translateHide");
 		$(".categoryMark").hide();
 		// $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
 		$(".categoryIcon").attr("src", "img/640_16.png");
 		$(".categoryIcon1").attr("src", "img/640_11.png");
 		setTimeout(function() {
 				$(".categoryContentArea").hide();
 			},
 			500);
 	}
 	$(".manuArea div").eq(1).click(function() {
 		getplaymuic();
 		$(".manuArea").hide();
 		selectCategoryOut();
 		jsonInfo = {};
 		var groupArr = [];
 		if ($(".filterSelectedButton").length) {
 			$.each($(".filterArea"),
 				function(index, item) {
 					var filterSelectedDetail = $(item).find(".filterSelectedButton");
 					if (filterSelectedDetail.length > 0) {
 						var keys = filterSelectedDetail.eq(0).data("keys");
 						if (typeof $(item).data("group") !== "undefined") {
 							var groupElement = {};
 							groupElement.groupId = $(item).data("group");
 							groupElement[keys] = filterSelectedDetail.data("id");
 							groupArr.push(groupElement);
 						} else {
 							jsonInfo[keys] = filterSelectedDetail.data("id");
 						}
 					}
 				});
 			if (groupArr.length) {
 				jsonInfo.groupIds = groupArr;
 			}
 			jsonFilter.filterInfo = jsonInfo;
 			jsonFilter.pageSize = 12;
 			jsonFilter.page = 0;
 			pageIndex = 0;
 			if (typeof(jsonFilter.filterInfo) !== "undefined") {
 				$(".categoryIcon1").attr("src", "img/640_06.png");
 			}
 			$(".box").css("display", "-webkit-box");
 			// console.log(jsonFilter)
 			ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 		} else {
 			delete jsonFilter.filterInfo;
 			// jsonFilter.filterInfo = jsonInfo;
 			jsonFilter.pageSize = 12;
 			jsonFilter.page = 0;
 			pageIndex = 0;
 			ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 		}
 	});
 	
 	$(".emptyHistory").click(function() {
 		confirm("确认清空搜索历史记录？", ["确认", "取消"],
 			function() {
 				$(".searchVagaa").hide();
 				hotKeysBox = [];
 				window.localStorage.clear();
 			}),

 		function() {};
 	});
 }
 var jsonFilter = {};
 var selectedText;
 $(function() {
 	// init(jsonString);
 	ikanWebInterface.docReady('');
 	$(document).on("click",".hotKeys span",function(){
 		var hotKeys = $(this).text();
 		hotKeys = hotKeys.replace(/\"/ig, "").replace(/\\/ig, "");
 		$("#search").val(inputSlice(hotKeys));
 		if ($(this).val() !== "") {
 			var newHotKeys = [];
 			for (var j = 0; j < hotKeysBox.length; j++) {
 				if (hotKeysBox[j] !== hotKeys) {
 					newHotKeys.push(hotKeysBox[j]);
 				}
 			}
 			newHotKeys.unshift(hotKeys);
 			hotKeysBox = newHotKeys;
 			setItem();
 		}
 		clearFilter();
 		switch ($(".selectArea span").text()) {
 		    case '全部':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',bool,48);
 		        break;
 		    case '动漫':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',bool,48);
 		        break;
 		    case '玩具':
 		    	jsonFilter.page = 0;
 		    	jsonFilter.pageSize = 12;
 		    	pageIndex = 0;
 		    	jsonFilter.searchKey = hotKeys;
 		    	selectedText="";
 				$(".categoryListBox").hide();
 				$(".categoryMainListSelect").removeClass("categoryMainListSelect");
 				$(".categoryMainLimite").addClass("categoryMainListSelect");
 				$(".bgShadow").addClass("searchFlag");
 		    	ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 		            // ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
 		         break;
 		    case '知识':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,48);
 		        break;
 		    default:
 		        break;
 		}
 		// ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
 		setTimeout(function(){
 			$(".bgShadow").removeClass("searchFlag");
 			searchCancel();
 		},600)
 	});
 	$(document).fix("click", ".productDetail",
 		function() {
 			if (!clickUsed && !lazyLoad.parentFixed(event)) return;
 			$(".alertArea").hide();
 			ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"),' ',48);
 		}, {
 			"commOnce": true
 		});
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
 });

 function backTop() {
 	if (isIphone) {
 		return $(".scrollContent")[0].scrollTop = 0;
 	}
 	document.body.scrollTop = 0;
 }
 var loadBottomHtml = $("#loadBottom").html();
 var searchNullFlag = false;

 function productLoad(data) {
 	loadIndex++;
 	data = typeof(data) == "string" ? JSON.parse(data) : data;
 	if (data.searchKey) $("#search").val(data.searchKey);
 	if (data.status && data.status == 10) {
 		if (pageIndex == 0) {
 			dead();
 			$(".dead").unbind("click").on("click",
 				function() {
 					getplaymuic();
 					ikanWebInterface.reloadPage();
 					$(".bgShadow").hide();
 					// ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
 					$(".box").show();
 					$(".dead").hide();
 				});
 			return;
 		}
 		$("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
 		if(pageIndex>0)pageIndex--;
 		pageLoadFinish = true;
 		$(".loadBottom").unbind("click").on("click",
 			function() {
 				getplaymuic();
 				pageIndex++;
 				var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
 				ikanWebInterface.command(5069, jsonString, "productLoad",48);
 			});
 		return;
 	}else{
        $(".dead").hide();
        $(".scrollContent").show();
     }
 	$("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
 	noService = false;
 	if (data.status && data.status == 9 || (data.products.length == 0 && pageIndex == 0)) {
 		noService=true;
 		$("#searchImg").show();
 		$(".scrollContent").hide();
 		$(".box").hide();
 		return;
 	}
 	$(".sampleSearchArea").hide();
 	if (data.searchNullFlag || searchNullFlag) {
 		if (data.searchNullFlag == 1) {
 			$(".sampleSearchArea").show();
 			searchNullFlag = true;
 		};
 	}
 	if ($(".bgShadow").hasClass("shadowSlide")&&!$(".bgShadow").hasClass("searchFlag")) return;
 	$("#searchImg").hide();
 	$(".box").hide();
 	$(".scrollContent").show();
 	$(".categoryArea").show();
 	$(".bgShadow").removeClass("shadowSlide");
 	data = data.products;
 	var productArr = [];
 	if (data.length) {
 		if (data.length < 12) {
 			$("#loadBottom").html("已经加载完成");
 			pageBottomFinish = false;
 		}
 		var myTemplate = Handlebars.compile($("#table-template").html());
 		Handlebars.registerHelper("transformat",
 			function(value) {
 				if (value.length > 27) {
 					return value.slice(0, 25) + "...";
 				} else {
 					return value;
 				}
 			});
 		Handlebars.registerHelper("imgUrlRechange",
 			function(value, index) {
 				var imgUrls = ImageUrl(value, ".300x300");
 				var index = loadIndex * 12 + (index - 0);
 				if (loadIndex > 0) {
 					index = "productDetail" + index;
 					productArr.push([imgUrls, index]);
 				}
 				return imgUrls;
 			});
 		Handlebars.registerHelper("indexChange",
 			function(index) {
 				return loadIndex * 12 + (index - 0);
 			});
 		Handlebars.registerHelper("priceChange",
 			function(price) {
 				return parseFloat(price).toFixed(2);
 			});
 		Handlebars.registerHelper("stockoutTest",
 			function(storageStatus, stockoutImageShow) {
 				if (storageStatus == 0) {
 					return stockoutImageShow;
 				} else {
 					return "";
 				}
 			});
 		Handlebars.registerHelper("grayTest",
 			function(storageStatus, gray) {
 				if (storageStatus == 0) {
 					return gray;
 				} else {
 					return "";
 				}
 			});
 		Handlebars.registerHelper("fontChange",
 			function(storageStatus, stockoutFont) {
 				if (storageStatus == 0) {
 					return stockoutFont;
 				} else {
 					return "";
 				}
 			});
 		if (pageIndex == 0) {
 			backTop();
 			$('.productArea').html(myTemplate(data));
 		} else {
 			$('.productArea').append(myTemplate(data));
 		}
 		if (typeof(vertical) !== "undefined") {
 			vertical.refresh();
 		}
 		if (loadIndex > 1) {
 			for (var i = 0; i < productArr.length; i++) {
 				if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
 					ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
 				}
 			}
 		}
 	} else {
 		$("#loadBottom").html("已经加载完成");
 		pageBottomFinish = false;
 	}
 	pageLoadFinish = true;
 	$(".loader").addClass("bottomImageRotate");
 }
 //搜索完成或取消

 function searchCancel() {
 	eventPrevent = false;
 	$(".bgShadow").removeClass("shadowSlide");
 	$(".alertDetail").removeClass("alertDetailSelect").eq(2).addClass("alertDetailSelect");
 	$(".selectArea span").text("玩具");
 	$("#search").attr("placeholder","搜索玩具");
 	if(noService){
        $("#searchImg").show();
    }else{
        $(".scrollContent").show();
    }
 	hotKeyFunc("productHotKeys");
 	alertAreaOut();
 	$(".categoryArea").show();
 }

 function alertAreaOut() {
 	$(".alertArea").hide();
 }
 //判断输入框是否为空格
 var BlankSpace = true;

 function checkBlankSpace(str) {
 	while (str.lastIndexOf(" ") >= 0) {
 		str = str.replace(" ", "");
 	}
 	if (str.length == 0) {
 		BlankSpace = false;
 	} else {
 		BlankSpace = true;
 	}
 }

 function clearFilter() {
 	selectedText="";
 	jsonFilter = {};
 	$.each($(".categoryDetailButton span"),
 		function() {
 			$(this).text($(this).data("clear"));
 		});
 	if ($(".rankCategoryArea span").length) $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
 	if ($(".babyAgeSelectDetail").length) $(".babyAgeSelectDetail").removeClass("selectCategory");
 	if ($(".manuArea div").length) {
 		$(".filterSelectContentDetail").removeClass("filterSelectedButton");
 		$(".categoryIcon").attr("src", "img/640_16.png");
 		$(".categoryIcon1").attr("src", "img/640_11.png");
 		$.each($(".content-long-to-dotted"),
 			function(index, item) {
 				if ($(item).data("define")) {
 					var itemDefine = $(item).data("define");
 					$(item).html(itemDefine).data("content", itemDefine);
 				}
 			});
 	}
 }

 function setItem() {
 	var newHotKeysBox = hotKeysBox;
 	newHotKeysBox = newHotKeysBox.join("&quot");
 	localStorage.setItem("keys", newHotKeysBox);
 }
 var searchFunc = function() {
 	getplaymuic();
 	eventPrevent = false;
 	$(".translateShow").removeClass("translateShow").addClass("translateHide");
 	$(".categoryContentArea").hide();
 	$(".bgColor").hide();
 	if (!$(".ManuButton").hasClass("ManuLeave")) {
 		// eventPrevent = true;
 		// $("#search").focus();
 		// $(this).attr("placeholder", "");
 		$(".alertArea").hide();
 		$(".selectArea").css({
 			display: "-webkit-box"
 		}).show();
 		// $(".categoryContentArea").hide().children().removeClass("translateShow").addClass("translateHide");
 		// $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
 		$(".categoryIcon").attr("src", "img/640_16.png");
 		$(".categoryIcon1").attr("src", "img/640_11.png");
 		$(".categoryMark").hide();
 	}
 	// $(".categoryArea").hide();
 	$(".bgShadow").addClass("shadowSlide");
 	$(".callBox").hide();
 	if ($(".scrollContent").hide()) {
 		// $(".scrollContent").show();
 		$("#searchImg").hide();
 	}
 	$(".scrollContent").hide()
 	$(".categoryArea").hide();
 	var localhotKeys = window.localStorage;
 	if (localhotKeys.length == 0) {
 		$(".searchVagaa").hide();
 	} else {
 		$(".searchVagaa").show();
 		localhotKeys = localhotKeys.getItem("keys");
 		localhotKeys = localhotKeys.split("&quot").splice(0, 10);
 		hotKeysBox = localhotKeys;
 		for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
 			htmls += '<span id="hotKeys' + i + '">' + localhotKeys[i] + '</span>';
 		}
 		$(".vagaa").html(htmls);
 		// $(".scrollContent").css("background","#efefef");
 		if (isIphone) {
 			$(".scrollContent")[0].scrollTop = 0;
 		}
 	}
 	$(".vagaa span").click(function() {
 		var hotKeys = $(this).text();
 		$("#search").val(inputSlice(hotKeys));
 		var newHotKeys = [];
 		hotKeysBox = localhotKeys;
 		for (var j = 0; j < hotKeysBox.length; j++) {
 			if (hotKeysBox[j] !== hotKeys) {
 				newHotKeys.push(hotKeysBox[j]);
 			}
 		}
 		newHotKeys.unshift(hotKeys);
 		hotKeysBox = newHotKeys;
 		clearFilter();
 		setItem();
 		switch ($(".selectArea span").text()) {
 		    case '全部':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',bool,48);
 		        break;
 		    case '动漫':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',bool,48);
 		        break;
 		    case '玩具':
	 		    jsonFilter.page = 0;
	 		    jsonFilter.pageSize = 12;
	 		    pageIndex = 0;
	 		    jsonFilter.searchKey = hotKeys;
	 		    selectedText="";
 				$(".categoryListBox").hide();
 				$(".categoryMainListSelect").removeClass("categoryMainListSelect");
 				$(".categoryMainLimite").addClass("categoryMainListSelect");
 				$(".bgShadow").addClass("searchFlag");
	 		    ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',48);
 		            // ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
 		         break;
 		    case '知识':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,48);
 		        break;
 		    default:
 		        break;
 		}
 		setTimeout(function(){
 			$(".bgShadow").removeClass("searchFlag");
 			searchCancel();
 		},600)
 	});
 	$("body").on("touchmove", function() {
 		$("#search").blur()
 	});
 };
 var shopcartFunc = function() {
 	getplaymuic();
 	if($(".bgShadow").hasClass("shadowSlide")){
 		searchCancel();
 		if (noService) {
 			console.log(noService)
 			$(".scrollContent").hide();
            $("#searchImg").show();
 		}
 	}else{
 		ikanWebInterface.back();
 	}
 };
 var hotKeyFunc=function  (hotType) {
     if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
         $(".hotText,.hotKeys").show();
         var hotJson=hotKeysJson[hotType];
         for (var htmls = "", i = 0; i < hotJson.length; i++) {
             htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
         }
         $(".hotKeys").html(htmls);
     }
     else{
         $(".hotText,.hotKeys").hide();
     }
 }
 var alertDetailFunc=function(){
     getplaymuic();
     $(".alertDetail").removeClass("alertDetailSelect");
     $(this).addClass("alertDetailSelect");
     var type = $(".selectArea span").text($(".alertDetailSelect").text());
     switch (type.text()) {
         case '全部':
             $("#search").attr("placeholder","搜索动漫/玩具/知识");
             hotKeyFunc("recommendHotKeys");
             break;
         case '动漫':
             $("#search").attr("placeholder","搜索动漫");
             hotKeyFunc("albumHotKeys");
             break;
         case '玩具':
             $("#search").attr("placeholder","搜索玩具");
             hotKeyFunc("productHotKeys");
              break;
         case '知识':
             $("#search").attr("placeholder","搜索知识");
             hotKeyFunc("knowledgeHotKeys");
             break;
         default:
             break;
     }
     alertAreaOut();
 };
 var selectAreaFunc = function() {
 	getplaymuic();
 	if(!$(".bgShadow").hasClass("shadowSlide"))searchFunc();
 	if ($(".categoryContentArea").css("display") == "block") {
 		$(".categoryContentArea").hide();
 		$(".categoryMark").hide();
 		$(".categoryContentArea").children().removeClass("translateShow").addClass("translateHide");
 		$(".categoryIcon").attr("src", "img/640_16.png");
 		$(".categoryIcon1").attr("src", "img/640_11.png");
 		if (jsonFilter.filterInfo) {
 			$(".categoryIcon1").attr("src", "img/640_06.png");
 		}
 		$(".manuArea").hide();
 	}
 	if ($(".alertArea").css("display") == "block") {
 		$(".alertArea").css("display", "none");
 		return;
 	}
 	$(".alertArea").show();
 };

 function headerClickFunc() {
 	var headerOptions = {
 		"#search": searchFunc,
 		".cart_cancel": shopcartFunc,
 		".alertDetail": alertDetailFunc,
 		".selectArea": selectAreaFunc,
 		".callTopIcon": callTopFunc,
 		".deleteIcon":searchFunc
 	};
 	return headerOptions;
 }
 // 搜索部分js逻辑
 !(function() {
 	$("#search,.deleteIcon").click(function() {
 		if ($(this).hasClass("deleteIcon")) $("#search").val("");
 		if (androidVersionNum == 0 || androidVersionNum >= 440) searchFunc.apply(this);
 	})
 	$("#search").blur(function() {
 		// $(this).attr("placeholder", "搜索玩具");
 	});
 	$(".ManuButton").click(function() {
 		getplaymuic();
 		if (!$(".manuSlide").hasClass("translateInAnimation")) {
 			eventPrevent = true;
 			$(".bgShadow").show().addClass("opacityAnimation");
 			$(this).css({
 				backgroundImage: "img/index/manu2.png"
 			});
 			$(".manuSlide").removeClass("translateOutAnimation").addClass("translateInAnimation");
 			return;
 		}
 		eventPrevent = false;
 		$(".bgShadow").hide();
 		$(this).css({
 			backgroundImage: "img/index/manu1.png"
 		});
 		$(".manuSlide").removeClass("translateInAnimation").addClass("translateOutAnimation");
 	});
 	// $(document).on("click", ".bgShadow",
 	// function() {
 	//     eventPrevent = false;
 	//     $(".bgShadow")[0].scrollTop = 0;
 	//     $(".alertArea").hide();
 	//     // $(this).removeClass("shadowSlide");
 	//     $(".scrollContent").show();
 	//     $(".categoryArea").show()
 	// });
 	$(".cart_cancel").click(function() {
 		if (androidVersionNum == 0 || androidVersionNum >= 440) shopcartFunc.apply(this);
 	});
 	$(".cartButton").click(function() { //逻辑todo购物车
 		getplaymuic();
 		if ($(this).hasClass("cart_cancel")) {
 			return;
 		}
 		this.src = "img/shopingcart1s.png";
 		ikanWebInterface.startIkanScheme('ikan://shoppingcart/',' ',48);
 	});
 	if (isIphone) {
 		$("#search").on("search", function(event) {
 			onSearch();
 		});
 	} else {
 		$("#search").on("keydown", function(event) {
 			if (event.keyCode == 13) {
 				onSearch();
 			}
 		});
 	}

 	function onSearch() {
 		$("input").blur();
 		var hotKeys = $("#search").val();
 		hotKeys = hotKeys.replace(/\"/ig, "").replace(/\\/ig, "").replace(/\//ig, "");
 		$("#search").val(inputSlice(hotKeys));
 		checkBlankSpace(hotKeys);
 		if (hotKeys !== " " && BlankSpace == true) {
 			var newHotKeys = [];
 			for (var j = 0; j < hotKeysBox.length; j++) {
 				if (hotKeysBox[j] !== hotKeys) {
 					newHotKeys.push(hotKeysBox[j]);
 				}
 			}
 			newHotKeys.unshift(hotKeys);
 			hotKeysBox = newHotKeys;
 			setItem();
 		}
 		clearFilter();
 		// $(".box").css("display", "-webkit-box");
 		// ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
 		switch ($(".selectArea span").text()) {
 		    case '全部':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}', bool,48);
 		        break;
 		    case '动漫':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}', bool,48);
 		        break;
 		    case '玩具':
 		            ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,48);
 		         break;
 		    case '知识':
 		        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,48);
 		        break;
 		    default:
 		        break;
 		}
 		// ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":' + JSON.stringify(jsonFilter) + '}', bool);
 		setTimeout(function(){
 			searchCancel();
 		},600)
 	};
 	$(document).on("click", ".selectArea",
 		function() { //弹出菜单事件
 			if (androidVersionNum == 0 || androidVersionNum >= 440) selectAreaFunc.apply(this);
 		});
 	$(window).swipe(function() {
 		if ($(".alertArea").show()) {
 			$(".alertArea").hide();
 		}
 	});
 	//弹出菜单的点击事件
 	$(document).on("click", ".alertDetail",
 		function() {
 			if (androidVersionNum == 0 || androidVersionNum >= 440) alertDetailFunc.apply(this);
 		});
 })()