$(function() {
    $(".openVip").click(function() {
        getplaymuic();
        var id = $(this).data("id");
        ikanWebInterface.becomeVIP("990000" + id + "01")
    })
})

