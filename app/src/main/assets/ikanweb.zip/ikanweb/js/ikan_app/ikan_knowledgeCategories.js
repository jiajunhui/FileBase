var jsonString='{"ageRange":{"tagList":[{"tagId":1,"tagValue":"0-3岁","groupId":13,"tagName":"年龄"},{"tagId":2,"tagValue":"3-6岁","groupId":13,"tagName":"年龄"},{"tagId":3,"tagValue":"6+","groupId":13,"tagName":"年龄"}],"groupId":13,"cname":"年龄"},"compositiveSort":[{"sortName":"综合","sortId":0},{"sortName":"热播","sortId":1},{"sortName":"最新","sortId":2}],"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"categorys":[{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/85f85197-df66-4cd7-bef8-c2217b7539ac.png","categoryName":"英语","albumCategoryId":14},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/81fe8529-b71f-4c1c-bbdc-a2d7e9dd5dd9.png","categoryName":"数学逻辑","albumCategoryId":10},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/0ac60dee-8574-4de4-8f07-53a2fc39e917.png","categoryName":"国学语文","albumCategoryId":11},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/f848e1cf-c0ec-4bc6-b7d4-6adbad01bf3a.png","categoryName":"音乐儿歌","albumCategoryId":12},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/bb9b0d9d-9810-4adf-ac0e-8a42c3c8d909.png","categoryName":"科学科普","albumCategoryId":13},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/63ae5aec-8ded-4ed2-a02b-ed48dbaa7615.png","categoryName":"生活常识","albumCategoryId":15}],"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"hotKeys":["蓝猫淘气3000问","朵拉"],"searchKey":"蓝猫","productHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"knowledgeVideos":[{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫小学拼音","typeName":"国学语文","id":483,"vip":false,"totalCount":18,"snapshot":"http://webimg.ikan.cn/test/ximages/album/6d6660e4-9cce-4c83-8556-720a94b023ee.jpg","age":"6~8岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫百科全书","typeName":"科学科普","id":509,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/c96d0792-2f4c-446c-aa57-d3b953f30482.jpg","age":"6~12岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫淘气3000问 恐龙时代","typeName":"科学科普","id":399,"vip":false,"totalCount":264,"snapshot":"http://webimg.ikan.cn/test/ximages/album/541bacbe-95c3-443d-ac8f-60da76cbc9fb.jpg","age":"6~12岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫启蒙英语100句","typeName":"英语","id":503,"vip":false,"totalCount":50,"snapshot":"http://webimg.ikan.cn/test/ximages/album/264a967f-db3b-4a0d-aef6-87caa762c356.jpg","age":"3~8岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫小学科学","typeName":"科学科普","id":482,"vip":false,"totalCount":48,"snapshot":"http://webimg.ikan.cn/test/ximages/album/39a13f21-e8be-430c-a1aa-380128b5ccdb.jpg","age":"6~12岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫MTV歌曲","typeName":"音乐儿歌","id":471,"vip":false,"totalCount":280,"snapshot":"http://webimg.ikan.cn/test/ximages/album/a767e051-3a07-4b19-9509-b0cbafc61010.jpg","age":"3~8岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫小学英语第二部","typeName":"英语","id":548,"vip":false,"totalCount":43,"snapshot":"http://webimg.ikan.cn/test/ximages/album/d0f6da51-0006-4daf-a250-7365d7805d85.jpg","age":"6~12岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫小学英语第三部","typeName":"英语","id":546,"vip":false,"totalCount":42,"snapshot":"http://webimg.ikan.cn/test/ximages/album/ff649609-0c65-47b1-8369-671dd6c491e1.jpg","age":"6~12岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫趣味识字","typeName":"国学语文","id":500,"vip":false,"totalCount":65,"snapshot":"http://webimg.ikan.cn/test/ximages/album/34b580e1-ad86-4889-9ea9-98c2dea6ba9f.jpg","age":"3~5岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫小学英语第一部","typeName":"英语","id":502,"vip":false,"totalCount":47,"snapshot":"http://webimg.ikan.cn/test/ximages/album/0b25e7f1-fcc2-4dc3-8be1-5e4e6b9bc29f.jpg","age":"6~12岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫幼儿语言","typeName":"英语","id":489,"vip":false,"totalCount":108,"snapshot":"http://webimg.ikan.cn/test/ximages/album/f1ab09a5-b09b-4aed-8e3f-45f375985477.jpg","age":"3~5岁"},{"totalNumber":26,"nowCount":0,"specialType":0,"name":"蓝猫快乐活动幼儿园","typeName":"生活常识","id":477,"vip":false,"totalCount":300,"snapshot":"http://webimg.ikan.cn/test/ximages/album/681bd6c9-9853-4d83-8ba8-c81d78e8e6b8.jpg","age":"3~5岁"}],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉"]}';
 function insit(json) {
    // try {
    // initTest(json)
    // } catch (e) {
    //     document.write(e.name);
    //     document.write(e.number);
    //     document.write(e.description);
    //     document.write(e.message);
    //     document.write(json)
    // }
    setTimeout(function() {
        init(json);
    },
    100);
}
var hotKeysBox = [];
var  noService=false;
function init(json) { //初始化页面方法
    debug(json)
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    var search = '<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
    search.innerHTML = "";
    $(".bgShadow").html(search);
    jsonFilter.searchKey = json.searchKey;
    $(".scrollContent").show();
    $("#search").val(inputSlice(json.searchKey));
    if(json.albumHotKeys)hotKeysJson.albumHotKeys=json.albumHotKeys;
    if(json.productHotKeys)hotKeysJson.productHotKeys=json.productHotKeys;
    if(json.knowledgeHotKeys)hotKeysJson.knowledgeHotKeys=json.knowledgeHotKeys;
    if(json.recommendHotKeys)hotKeysJson.recommendHotKeys=json.recommendHotKeys;
    $(".emptyHistory").click(function() {
        confirm("确认清空搜索历史记录？", ["确认", "取消"],
        function() {
            $(".searchVagaa").hide();
            hotKeysBox = [];
            window.localStorage.clear();
        }),
        function() {};
    });
    if (json.status && json.status == 10) {
        dead();
        var localhotKeys = window.localStorage;
        $("#search").html(localhotKeys[0])
        $(".dead").unbind("click").on("click",
        function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".bgShadow").hide();
            // ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad');
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    if (json.status && json.status == 9) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        noService=true;
        return;
    }
    
    
    data9 = json.knowledgeHotKeys;
    if (data9) {
        for (var htmls = "",
        i = 0; i < data9.length; i++) {
            htmls += '<span id="hotKeys' + i + '">' + data9[i] + '</span>';
        }
        $(".hotKeys").html(htmls);
    }
    if(data9 == null){
        $(".hotKeys").hide()
        $(".hotText").hide()
    }
    productLoad(json);
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    },
    300);
    var backBut = true,
    cartBat = true,
    performanceBut = true;

    function callPageLoad(pageIndex) { //分页回掉函数
        jsonFilter.pageSize = 12;
        jsonFilter.page = pageIndex;
        ikanWebInterface.command(5074, JSON.stringify(jsonFilter), "productLoad",50);
    }
    loadImage("scrollContent", callPageLoad);
    var markPostionArr = ["2.36rem", "7.9rem", "12.88rem"];
    var categoryContentObj = $("div[class^='categoryContent']");
    var categoryInterval = null;
    var preIndex = 0;
    $(".categoryDetailButton").unbind("click").bind("click",
    function(event) {
        getplaymuic();
        clearTimeout(categoryInterval);
        if ($(".alertArea").css("display") == "block") {
            $(".alertArea").css("display", "none");
        }
        $(".callTopButton").hide();
        $(".bg").removeClass("translateHide").css("opacity", 1);
        // $(".categoryArea").css("border-bottom", "1px solid #fff");
        eventPrevent = true;
        var categoryIndex = $(this).index();
        if ($(".translateShow").length == 0) {
            $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
        if (categoryIndex == 2 && $(".categoryMainListSelect").hasClass("unlimitedCategories")) {
            $(".categoryMark").attr("src","img/categoryMarkHs.png")
        }else{
            $(".categoryMark").attr("src","img/categoryMark.png")
        }
        if (categoryContentObj.eq(categoryIndex).hasClass("translateShow")) {
            eventPrevent = false;
            $(".bgColor").hide();
            $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
            $(".categoryMark").hide();
            categoryInterval=setTimeout(function(){$(".categoryContentArea").hide();},500)
            categoryContentObj.eq(categoryIndex).removeClass("translateShow").addClass("translateHide");
            $(".categoryIcon").attr("src", "img/640_16.png").eq(3).attr("src", "img/640_11.png");
            if (jsonFilter.filterInfo) {
                $(".categoryIcon").eq(3).attr("src", "img/640_06.png");
            }
            return;
        }
        $(".bgColor").show();
        $(".categoryMark").css({
            left: markPostionArr[categoryIndex]
        }).show();
        var categoryContentEval = "categoryContent" + categoryIndex + "()";
        $(".categoryIcon").attr("src", "img/640_16.png").eq(3).attr("src", "img/640_11.png");
        if (jsonFilter.filterInfo) {
            $(".categoryIcon").eq(3).attr("src", "img/640_06.png");
        }
        $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_14.png");
        eval(categoryContentEval);
        $(".manuArea").hide();
        if ($(".translateShow").length) {
            categoryContentObj.eq(preIndex).removeClass("translateShow");
        } else {
            $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
        categoryContentObj.removeClass("translateHide").removeClass("translateShow").addClass("translateHide").eq(categoryIndex).removeClass("translateHide").addClass("translateShow");
        preIndex = categoryIndex;
        if ($(".categoryContentArea").css("display") == "block") {
            $(".bg").unbind("click").click(function() {
                getplaymuic();
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon").eq(3).attr("src", "img/640_06.png");
                }
                $(".bgColor").hide();
                $(".categoryMark").hide();
                $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
                eventPrevent = false;
                $(".translateShow").removeClass("translateShow").addClass("translateHide");
                setTimeout(function(){$(".categoryContentArea").hide()},300);
                $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_16.png");
            });
        }
    });
    //综合排序
    function categoryContent0() {
        if ($(".rankCategoryArea").length == 0) {
            data1 = json.compositiveSort;
            var categoryHtml = '';
            for (var i = 0; i < data1.length; i++) {
                categoryHtml += '<div class="rankCategoryArea" data-id=' + data1[i].sortId + ' data-group=' + data1[i].groupId + '><span>' + data1[i].sortName + '</span><img src="img/index/categorySelect.png" alt=""></div>';
            }
            $(".categoryContentDetail1").html(categoryHtml);
            $(".rankCategoryArea span").eq(0).addClass("selectCategory").parent().find("img").show();
            $(".rankCategoryArea").click(function() {
                getplaymuic();
                $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
                $(this).find("span").addClass("selectCategory").parent().find("img").show();
                $(".categoryDetailButton span").eq(0).html($(this).find("span").html());
                jsonFilter.sortId = $(this).data("id");
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',50);
            });
        }
    }

    function categoryContent1() {
        if ($(".babyAgeSelectDetail").length == 0) {
            var dataGroup = json.ageRange.groupId;
            var data2 = json.ageRange.tagList;
            var categoryHtml = '<div class="babyAgeSelectDetail noLimitedAge">不限</div>';
            for (var i = 0; i < data2.length; i++) {
                categoryHtml += '<div class="babyAgeSelectDetail" data-id=' + data2[i].tagId + '>' + data2[i].tagValue + '</div>';
            }
            $(".babyAgeSelect").html(categoryHtml);
            $(".babyAgeSelectDetail").click(function() {
                getplaymuic();
                $(".babyAgeSelectDetail").removeClass("selectCategory");
                $(this).addClass("selectCategory");
                if ($(this).hasClass("noLimitedAge")) {
                    delete jsonFilter.ageRange;
                    $(".categoryDetailButton span").eq(1).html("年龄");
                } else {
                    $(".categoryDetailButton span").eq(1).html($(this).text());
                    var ageRange = {};
                    ageRange.groupId = dataGroup;
                    ageRange.tagId = $(this).data("id");
                    jsonFilter.ageRange = ageRange;
                }
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',50);
            });
        }
    }

    function categoryContent2() {
        if ($(".categoryMainListDetail").length == 0) {
            data3 = json.categorys;
            var categoryHtml = '<div class="categoryMainListDetail unlimitedCategories"><img src="img/more.png" alt=""><span>不限</span></div>';
            for (var i = 0; i < data3.length; i++) {
                categoryHtml += '<div class="categoryMainListDetail" data-id=' + data3[i].albumCategoryId + '><img src="' + data3[i].imageSrc + '" alt=""><span>' + data3[i].categoryName + '</span></div>';
            }
            $(".categoryMainList").html(categoryHtml);
            $(".categoryMainListDetail").click(function() {
                getplaymuic();
                if ($(this).hasClass("unlimitedCategories")) {
                    $(".categoryMark").attr("src","img/categoryMarkHs.png")
                    $(".categoryDetailButton span").eq(2).html("分类");
                    delete jsonFilter.categoryId;
                } else {
                    $(".categoryMark").attr("src","img/categoryMark.png")
                    $(".categoryDetailButton span").eq(2).html($(this).text());
                    jsonFilter.categoryId = $(this).data("id");
                }
                $(".categoryMainListDetail").removeClass("categoryMainListSelect");
                $(this).addClass("categoryMainListSelect");
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                $(".categoryMark").hide();
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',50);
            });
        }
    }

    function selectCategoryOut() {
        eventPrevent = false;
        $(".bgColor").hide();
        $(".translateShow").removeClass("translateShow").addClass("translateHide");
        $(".categoryMark").hide();
        $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
        $(".categoryIcon").attr("src", "img/640_16.png").eq(3).attr("src", "img/640_11.png");
        setTimeout(function() {
            $(".categoryContentArea").hide();
        },
        500);
    }
   
    
}
var jsonFilter = {};
var hotKeysJson={};
var vipRedMarkText, redMarkText;
var creditPolicy = 0;

function returnCreditPolicy(json, id) { //积分回掉函数
    creditPolicy++;
    var num = Math.abs(JSON.parse(json).credits);
    if (id == "true") {
        vipRedMarkText = "积分：非VIP每集消耗" + num + "积分";
    } else {
        redMarkText = "积分：观看每集奖励" + num + "积分";
    }
    if (creditPolicy == 2) {
        ikanWebInterface.docReady("");
    }
}
$(function() {
    // init(jsonString);
    ikanWebInterface.getCreditPolicy("PLAYVIPVIDEO", "true");
    ikanWebInterface.getCreditPolicy("PLAYVIDEO", "false");
    $(document).on("click",".hotKeys span",function(){
            var hotKeys = $(this).text();
            hotKeys = hotKeys.replace(/\"/ig, "").replace(/\\/ig, "");
            $("#search").val(inputSlice(hotKeys));
            if ($(this).val() !== "") {
                var newHotKeys = [];
                for (var j = 0; j < hotKeysBox.length; j++) {
                    if (hotKeysBox[j] !== hotKeys) {
                        newHotKeys.push(hotKeysBox[j]);
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox = newHotKeys;
                setItem();
            }
            clearFilter();
            switch ($(".selectArea span").text()) {
                case '全部':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',bool,50);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',bool,50);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,50);
                     break;
                case '知识':
                    jsonFilter.page = 0;
                    jsonFilter.pageSize = 12;
                    pageIndex = 0;
                    jsonFilter.searchKey = hotKeys;
                    ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',50);
                    break;
                default:
                    break;
            }
            searchCancel();
        });
    $(document).fix("click", ".mangaAreaDetail",
    function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        $(".alertArea").hide();
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',50);
    },
    {
        "commOnce": true
    });
    
});

function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop = 0;
    }
    document.body.scrollTop = 0;
}
var loadBottomHtml = $("#loadBottom").html();
var searchNullFlag = false;
function productLoad(data) {
    loadIndex++;
    data = typeof(data) == "string" ? JSON.parse(data) : data;
     if(data.searchKey)$("#search").val(data.searchKey);
    if (data.status && data.status == 10) {
        if(pageIndex==0){
            dead();
            var localhotKeys = window.localStorage;
            $("#search").html(localhotKeys[0])
            $(".dead").unbind("click").on("click",
            function() {
                getplaymuic();
                ikanWebInterface.reloadPage();
                $(".bgShadow").hide();
                // ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad');
                $(".box").show();
                $(".dead").hide()
            });
            return
        }
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click",
        function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5074, jsonString, "productLoad",50);
        });
        return;
    }else{
        $(".dead").hide();
        $(".scrollContent").show();
     }
    noService = false;
    if (data.status && data.status == 9 || (data.knowledgeVideos.length == 0 && pageIndex == 0) ) {
        noService=true;
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        return;
    }
    if (data.searchNullFlag || searchNullFlag) {
        if (data.searchNullFlag==1) {
            $(".sampleSearchArea").show();
            searchNullFlag = true;
        };
    }
    if ($(".bgShadow").hasClass("shadowSlide"))return;
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    $(".box").hide();
    $(".bgShadow").removeClass("shadowSlide");
    $(".sampleSearchArea").hide();
    $("#searchImg").hide();
    $(".scrollContent").show().css({
        opacity: 1
    });
    $(".categoryArea").show();
    data = data.knowledgeVideos;
    var productArr = [];
    if (data.length) {
        if (data.length < 12) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imgUrlRechange",
        function(value, index) {
            var imgUrls = ImageUrl(value, ".220x300");
            var index = loadIndex * 12 + index;
            if (loadIndex > 0) {
                index = "cartoon" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("imageGrayTest",
        function(v1, v2) {
            if (v1 == true) {
                return v2;
            } else {
                return "";
            }
        });
        Handlebars.registerHelper("indexChange",
        function(index) {
            return loadIndex * 12 + index;
        });
        Handlebars.registerHelper("cartonsInformation",
        function(nowCount, totalCount) {
            var numInfo = (nowCount == 0) || (typeof(nowCount) == "undefined") ? totalCount + "集全": "更新至" + nowCount + "集";
            return numInfo;
        });
        Handlebars.registerHelper("getAlbumCredits",
        function(isVip) { //积分函数
            var isVipText = isVip ? vipRedMarkText: redMarkText;
            return isVipText;
        });
        if (pageIndex == 0) {
            backTop();
            $('.cartoonArea').html(myTemplate(data));
        } else {
            $('.cartoonArea').append(myTemplate(data));
        }
        if (typeof(vertical) !== "undefined") {
            vertical.refresh();
        }
        if (loadIndex > 1) {
            for (var i = 0; i < productArr.length; i++) {
                if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                    ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
                }
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}
//搜索完成或取消
function searchCancel() {
    eventPrevent = false;
    $(".alertDetail").removeClass("alertDetailSelect").eq(3).addClass("alertDetailSelect");
    $(".selectArea span").text("知识");
    $("#search").attr("placeholder","搜索知识");
    if(noService){
        $("#searchImg").show();
    }else{
        $(".scrollContent").show();
    }
    $(".bgShadow").removeClass("shadowSlide");
    $(".categoryArea").show();
    hotKeyFunc("knowledgeHotKeys");
    alertAreaOut();
}
function alertAreaOut() {
    $(".alertArea").hide();
}
//判断输入框是否为空格
    var BlankSpace=true;
    function checkBlankSpace(str){
        while(str.lastIndexOf(" ")>=0){
            str = str.replace(" ","");
        }
        if(str.length == 0){
            BlankSpace=false;
        }else{
            BlankSpace=true;
        }
    }
function clearFilter() {
    jsonFilter = {};
    $.each($(".categoryDetailButton span"),
    function() {
        $(this).text($(this).data("clear"));
    });
    $(".categoryMainListSelect").removeClass("categoryMainListSelect");
    $(".unlimitedCategories").addClass("categoryMainListSelect");
    if ($(".rankCategoryArea span").length) $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
    if ($(".babyAgeSelectDetail").length) $(".babyAgeSelectDetail").removeClass("selectCategory");
    if ($(".manuArea div").length) {
        $(".filterSelectContentDetail").removeClass("filterSelectedButton");
        $.each($(".content-long-to-dotted"),
        function(index, item) {
            if ($(item).data("define")) {
                var itemDefine = $(item).data("define");
                $(item).html(itemDefine).data("content", itemDefine);
            }
        });
    }
}
function setItem() {
    var newHotKeysBox = hotKeysBox;
    newHotKeysBox = newHotKeysBox.join("&quot");
    localStorage.setItem("keys", newHotKeysBox);
}
var searchFunc = function() {
    getplaymuic();
    eventPrevent=false;
    $(".bgColor").hide();
    $(".translateShow").removeClass("translateShow").addClass("translateHide");
    $(".categoryContentArea").hide();
    if (!$(".ManuButton").hasClass("ManuLeave")) {
        // eventPrevent = true;
        // $("#search").focus();
        // $(this).attr("placeholder", "");
        $(".alertArea").hide();
        $(".selectArea").css({
            display: "-webkit-box"
        }).show();
        // $(".categoryContentArea").hide().children().removeClass("translateShow").addClass("translateHide");
        $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryMark").hide();
    }
    // $(".categoryArea").hide();
    $(".bgShadow").addClass("shadowSlide");
    $(".callBox").hide();
    if ($(".scrollContent").hide()) {
        // $(".scrollContent").show();
        $("#searchImg").hide();
    }
    $(".scrollContent").hide()
    $(".categoryArea").hide();
    var localhotKeys = window.localStorage;
    if (localhotKeys.length == 0) {
        $(".searchVagaa").hide();
    } else {
        $(".searchVagaa").show();
        localhotKeys = localhotKeys.getItem("keys");
        localhotKeys = localhotKeys.split("&quot").splice(0,10);
        hotKeysBox = localhotKeys;
        for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
            htmls += '<span id="hotKeys' + i + '">' + localhotKeys[i] + '</span>';
        }
        $(".vagaa").html(htmls);
        // $(".scrollContent").css("background","#efefef");
        if (isIphone) {
            $(".scrollContent")[0].scrollTop = 0;
        }
    }
    $(".vagaa span").click(function() {
        var hotKeys = $(this).text();
        $("#search").val(inputSlice(hotKeys));
        var newHotKeys = [];
        hotKeysBox = localhotKeys;
        for (var j = 0; j < hotKeysBox.length; j++) {
            if (hotKeysBox[j] !== hotKeys) {
                newHotKeys.push(hotKeysBox[j]);
            }
        }
        newHotKeys.unshift(hotKeys);
        hotKeysBox = newHotKeys;
        clearFilter();
        setItem();
        switch ($(".selectArea span").text()) {
            case '全部':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',bool,50);
                break;
            case '动漫':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',bool,50);
                break;
            case '玩具':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,50);
                 break;
            case '知识':
                jsonFilter.page = 0;
                jsonFilter.pageSize = 12;
                pageIndex = 0;
                jsonFilter.searchKey = hotKeys;
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',50);
            default:
                break;
        }
        searchCancel();
    });
    $(".vagaa span").click(function() {
        var hotKeys = $(this).text();
        $("#search").val(inputSlice(hotKeys));
        var newHotKeys = [];
        hotKeysBox = localhotKeys;
        for (var j = 0; j < hotKeysBox.length; j++) {
            if (hotKeysBox[j] !== hotKeys) {
                newHotKeys.push(hotKeysBox[j]);
            }
        }
        newHotKeys.unshift(hotKeys);
        hotKeysBox = newHotKeys;
        setItem();
        jsonFilter.page = 0;
        jsonFilter.pageSize = 12;
        pageIndex = 0;
        jsonFilter.searchKey = hotKeys;
        ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',50);
        searchCancel();
    });
    $("body").on("touchmove", function(){$("#search").blur()});
};
var shopcartFunc = function() {
    getplaymuic();
    if($(".bgShadow").hasClass("shadowSlide")){
        searchCancel();
        if (noService) {
            console.log(noService)
            $(".scrollContent").hide();
            $("#searchImg").show();
        }
    }else{
        ikanWebInterface.back();
    }
 };
 var hotKeyFunc=function  (hotType) {
    if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
        $(".hotText,.hotKeys").show();
        var hotJson=hotKeysJson[hotType];
        for (var htmls = "", i = 0; i < hotJson.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    else{
        $(".hotText,.hotKeys").hide();
    }
}
 var alertDetailFunc=function(){
     getplaymuic();
     $(".alertDetail").removeClass("alertDetailSelect");
     $(this).addClass("alertDetailSelect");
     var type = $(".selectArea span").text($(".alertDetailSelect").text());
     switch (type.text()) {
        case '全部':
            $("#search").attr("placeholder","搜索动漫/玩具/知识");
            hotKeyFunc("recommendHotKeys");
            break;
        case '动漫':
            $("#search").attr("placeholder","搜索动漫");
            hotKeyFunc("albumHotKeys");
            break;
        case '玩具':
            $("#search").attr("placeholder","搜索玩具");
            hotKeyFunc("productHotKeys");
             break;
        case '知识':
            $("#search").attr("placeholder","搜索知识");
            hotKeyFunc("knowledgeHotKeys");
            break;
        default:
            break;
    }
     alertAreaOut();
 };
var selectAreaFunc = function() {
    getplaymuic();
    if(!$(".bgShadow").hasClass("shadowSlide"))searchFunc();
    if ($(".categoryContentArea").css("display") == "block") {
        $(".categoryContentArea").hide();
        $(".categoryMark").hide();
        $(".categoryContentArea").children().removeClass("translateShow").addClass("translateHide");
        $(".manuArea").hide();
    }
    if ($(".alertArea").css("display") == "block") {
        $(".alertArea").css("display", "none");
        return;
    }
    $(".alertArea").show();
};
function headerClickFunc() {
    var headerOptions = {
        "#search": searchFunc,
        ".cart_cancel": shopcartFunc,
        ".alertDetail": alertDetailFunc,
        ".selectArea": selectAreaFunc,
        ".callTopIcon": callTopFunc,
        ".deleteIcon":searchFunc
    };
    return headerOptions;
}
// 搜索部分js逻辑
! (function() {
    //搜索框点击事件动画
    $("#search,.deleteIcon").click(function() {
        if($(this).hasClass("deleteIcon"))$("#search").val("");
        if (androidVersionNum == 0 || androidVersionNum >= 440) searchFunc.apply(this);
    })
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $("#search").blur(function() {
        // $(this).attr("placeholder", "搜索知识");
    });
    // $(document).on("click", ".bgShadow",function() {
    //     getplaymuic();
    //     eventPrevent = false;
    //     $(".bgShadow")[0].scrollTop = 0;
    //     $(".alertArea").hide();
    //     // $(this).removeClass("shadowSlide");
    //     $(".scrollContent").show();
    //     $(".categoryArea").show();
    // });

    $(".cart_cancel").click(function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) shopcartFunc.apply(this);
    });
    if(isIphone){
        $("#search").on("search", function(event) {
           onSearch();     
        });
    }
    else{
        $("#search").on("keydown", function(event) {
            if(event.keyCode==13){
                onSearch();     
            }
        });
    }
    function onSearch() {
            var hotKeys = $("#search").val();
            hotKeys=hotKeys.replace(/\"/ig,"").replace(/\\/ig,"").replace(/\//ig,"");
            $("#search").val(inputSlice(hotKeys));
            checkBlankSpace(hotKeys);
            if (hotKeys!==" "&&BlankSpace==true) {
                var newHotKeys = [];
                for (var j = 0; j < hotKeysBox.length; j++) {
                    if (hotKeysBox[j] !== hotKeys) {
                        newHotKeys.push(hotKeysBox[j]);
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox = newHotKeys;
                setItem();
            }
            // $(".box").css("display", "-webkit-box");
            clearFilter();
            switch ($(".selectArea span").text()) {
                case '全部':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}', bool,50);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}', bool,50);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,50);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,50);
                    break;
                default:
                    break;
            }
            $("input").blur();
            searchCancel();
    };
    $(document).on("click", ".selectArea",
    function() { //弹出菜单事件
        if (androidVersionNum == 0 || androidVersionNum >= 440) selectAreaFunc.apply(this);
    });
    $(window).swipe(function() {
        if ($(".alertArea").show()) {
            $(".alertArea").hide();
        }
    });
    //弹出菜单的点击事件
    $(document).on("click", ".alertDetail",
    function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) alertDetailFunc.apply(this);
    });
})()