jsonString = '{"ageRange":{"tagList":[{"tagId":1,"tagValue":"0-3岁","groupId":13,"tagName":"年龄"},{"tagId":2,"tagValue":"3-6岁","groupId":13,"tagName":"年龄"},{"tagId":3,"tagValue":"6+","groupId":13,"tagName":"年龄"}],"groupId":13,"cname":"年龄"},"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"categorys":[{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/c6c9d5ce-6f69-4857-9537-119ec1929efc.png","categoryName":"亲情友谊","albumCategoryId":2},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/fc14905a-9f12-47c8-ae4c-861b26f9aca0.png","categoryName":"冒险励志","albumCategoryId":3},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/a0d0f440-4f0b-4a8c-8851-83ea218ce920.png","categoryName":"科幻魔法","albumCategoryId":4},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/806d382c-b164-448f-82b6-6e756f329734.png","categoryName":"运动竞技","albumCategoryId":7},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/7b76e693-ac30-4f97-89ac-02d095e5968d.png","categoryName":"宝贝综艺","albumCategoryId":9}],"albums":[{"totalNumber":3,"nowCount":0,"specialType":0,"name":"火力少年王5之传奇再现","typeName":"运动竞技","id":349,"vip":false,"totalCount":40,"snapshot":"http://webimg.ikan.cn/test/ximages/album/ed3bd25a-411e-4c4b-bb21-8e4a1250bda4.png","age":"6~12岁"},{"totalNumber":3,"nowCount":0,"specialType":0,"name":"火力少年王动画版1","typeName":"运动竞技","id":7,"vip":false,"totalCount":40,"snapshot":"http://webimg.ikan.cn/test/ximages/album/25e65611-afd3-4bd2-b2c1-ca475e9b6bf1.png","age":"5岁以上"},{"totalNumber":3,"nowCount":0,"specialType":0,"name":"火力少年王动画版2","typeName":"运动竞技","id":17,"vip":false,"totalCount":24,"snapshot":"http://webimg.ikan.cn/test/ximages/album/d2fa87e8-f7c3-4be0-8b2c-b7c63aec1d58.png","age":"6岁以上"}],"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"hotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"searchKey":"火力少年","filterTags":[{"tagList":[{"tagId":6,"tagValue":"大陆","groupId":24,"tagName":"地域"},{"tagId":7,"tagValue":"港台","groupId":24,"tagName":"地域"},{"tagId":8,"tagValue":"日韩","groupId":24,"tagName":"地域"},{"tagId":9,"tagValue":"欧美","groupId":24,"tagName":"地域"}],"groupId":24,"cname":"地域","sortNum":1},{"tagList":[{"tagId":10,"tagValue":"儿歌","groupId":25,"tagName":"主题"},{"tagId":12,"tagValue":"拼音","groupId":25,"tagName":"主题"},{"tagId":13,"tagValue":"数学","groupId":25,"tagName":"主题"},{"tagId":14,"tagValue":"英语","groupId":25,"tagName":"主题"},{"tagId":15,"tagValue":"美术","groupId":25,"tagName":"主题"},{"tagId":16,"tagValue":"双语","groupId":25,"tagName":"主题"},{"tagId":11,"tagValue":"国学","groupId":25,"tagName":"主题"},{"tagId":17,"tagValue":"习惯","groupId":25,"tagName":"主题"},{"tagId":18,"tagValue":" 安全","groupId":25,"tagName":"主题"},{"tagId":19,"tagValue":"亲子","groupId":25,"tagName":"主题"},{"tagId":20,"tagValue":"冒险","groupId":25,"tagName":"主题"},{"tagId":21,"tagValue":"童话","groupId":25,"tagName":"主题"},{"tagId":22,"tagValue":"励志","groupId":25,"tagName":"主题"},{"tagId":23,"tagValue":"校园","groupId":25,"tagName":"主题"},{"tagId":24,"tagValue":"真人","groupId":25,"tagName":"主题"},{"tagId":25,"tagValue":"运动","groupId":25,"tagName":"主题"},{"tagId":26,"tagValue":"竞技","groupId":25,"tagName":"主题"},{"tagId":27,"tagValue":"魔法","groupId":25,"tagName":"主题"},{"tagId":28,"tagValue":"搞笑","groupId":25,"tagName":"主题"},{"tagId":29,"tagValue":"智慧","groupId":25,"tagName":"主题"},{"tagId":30,"tagValue":"早教","groupId":25,"tagName":"主题"},{"tagId":31,"tagValue":"友谊","groupId":25,"tagName":"主题"},{"tagId":32,"tagValue":"百科","groupId":25,"tagName":"主题"},{"tagId":33,"tagValue":"勇气","groupId":25,"tagName":"主题"},{"tagId":34,"tagValue":"梦想","groupId":25,"tagName":"主题"}],"groupId":25,"cname":"主题","sortNum":2},{"tagList":[{"tagId":4,"tagValue":"男孩","groupId":15,"tagName":"性别"},{"tagId":5,"tagValue":"女孩","groupId":15,"tagName":"性别"}],"groupId":15,"cname":"性别","sortNum":0}],"productHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉"],"sortVos":[{"sortName":"综合","sortId":0},{"sortName":"热播","sortId":1},{"sortName":"最新","sortId":2}]}';

function init(json) {
    setTimeout(function() {
        initTest(json)
    },
    100)
}
var hotKeysBox = [];
var  noService=false;
function initTest(json) {
    var search = '<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
    search.innerHTML = "";
    $(".bgShadow").html(search);
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    jsonFilter.page=0;
    jsonFilter.pageSize=12;
     jsonFilter.searchKey = json.searchKey;
     if(json.albumHotKeys)hotKeysJson.albumHotKeys=json.albumHotKeys;
     if(json.productHotKeys)hotKeysJson.productHotKeys=json.productHotKeys;
     if(json.knowledgeHotKeys)hotKeysJson.knowledgeHotKeys=json.knowledgeHotKeys;
     if(json.recommendHotKeys)hotKeysJson.recommendHotKeys=json.recommendHotKeys;
     $("#search").val(inputSlice(json.searchKey));
     $(".scrollContent").show();
     $(".emptyHistory").click(function() {
        confirm("确认清空搜索历史记录？", ["确认", "取消"],
        function() {
            $(".searchVagaa").hide();
            hotKeysBox = [];
            window.localStorage.clear()
        }),
        function() {}
    })
    if (json.status && json.status == 10) {
        dead();
        var localhotKeys = window.localStorage;
        $("#search").html(localhotKeys[0])
        $(".dead").unbind("click").on("click",
        function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".bgShadow").hide();
            // ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad');
            $(".box").show();
            $(".dead").hide()
        });
        return
    }
    if (json.status && json.status == 9) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        noService=true;
        debug(noService)
        return
    }
    $(".heaerTitle").text(json.title);
    data9 = json.albumHotKeys;
    if (data9) {
        for (var htmls = "",
        i = 0; i < data9.length; i++) {
            htmls += '<span id="hotKeys' + i + '">' + data9[i] + '</span>'
        }
        $(".hotKeys").html(htmls)
    }
    if(data9 == null){
        $(".hotKeys").hide()
        $(".hotText").hide()
    }
    var backBut = true,
    cartBat = true,
    performanceBut = true;
    productLoad(json);
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    },
    300);
    function callPageLoad(pageIndex) {
        jsonFilter.pageSize = 12;
        jsonFilter.page = pageIndex;
        ikanWebInterface.command(5073, JSON.stringify(jsonFilter), "productLoad",49)
    }
    loadImage("scrollContent", callPageLoad);
    var markPostionArr = ["1.8rem", "5.34rem", "9.3rem", "13.4rem"];
    var categoryContentObj = $("div[class^='categoryContent']");
    var categoryInterval = null;
    var preIndex = 0;
    $(".categoryDetailButton").unbind("click").bind("click",
    function(event) {
        clearTimeout(categoryInterval);
        getplaymuic();        
        if ($(".alertArea").css("display") == "block") {
            $(".alertArea").css("display", "none")
        }
        $(".callTopButton").hide();
        $(".bg").removeClass("translateHide").css("opacity", 1);
        // $(".categoryArea").css("border-bottom", "1px solid #fff");
        eventPrevent = true;
        var categoryIndex = $(this).index();
        if ($(".translateShow").length == 0) {
            $(".categoryContentArea").show().css({
                opacity: 1
            })
        }
        if (categoryIndex == 2 && $(".categoryMainListSelect").hasClass("unlimitedCategories")) {
            $(".categoryMark").attr("src","img/categoryMarkHs.png")
        }else{
            $(".categoryMark").attr("src","img/categoryMark.png")
        }
        if (categoryContentObj.eq(categoryIndex).hasClass("translateShow")) {
            eventPrevent = false;
            $(".bgColor").hide();
            // $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
            $(".categoryMark").hide();
            categoryInterval=setTimeout(function(){$(".categoryContentArea").hide();},500)
            categoryContentObj.eq(categoryIndex).removeClass("translateShow").addClass("translateHide");
            $(".categoryIcon").attr("src", "img/640_16.png");
            $(".categoryIcon1").attr("src", "img/640_11.png");
            if (jsonFilter.filterInfo) {
                $(".categoryIcon1").attr("src", "img/640_06.png")
            }
            return
        }
        $(".bgColor").show();
        var categoryContentEval = "categoryContent" + categoryIndex + "()";
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_14.png");
        $(".categoryMark").css({left: markPostionArr[categoryIndex]}).show();
        if (jsonFilter.filterInfo) {
            $(".categoryIcon1").attr("src", "img/640_06.png");
        }
        eval(categoryContentEval);
        $(".manuArea").hide();
        if (categoryIndex == 3) {
            $(".categoryIcon1").attr("src", "img/640_06.png");
            setTimeout(function() {
                $(".manuArea").css({
                    display: "-webkit-box"
                }).removeClass("translateHide")
            },
            0)
        }
        if ($(".translateShow").length) {
            categoryContentObj.eq(preIndex).removeClass("translateShow")
        } else {
            $(".categoryContentArea").show().css({
                opacity: 1
            })
        }
        categoryContentObj.removeClass("translateHide").removeClass("translateShow").addClass("translateHide").eq(categoryIndex).removeClass("translateHide").addClass("translateShow");
        preIndex = categoryIndex;
        if ($(".categoryContentArea").css("display") == "block") {
            $(".bg").unbind("click").click(function() {
                getplaymuic();
                $(".categoryMark").hide();
                $(".bgColor").hide();
                // $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
                eventPrevent = false;
                $(".translateShow").removeClass("translateShow").addClass("translateHide");
                setTimeout(function(){$(".categoryContentArea").hide()},300);
                $(".categoryIcon").attr("src", "img/640_16.png");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }else{
                    $(".categoryIcon1").attr("src", "img/640_11.png");
                }
            })
        }
    });
    function categoryContent0() {
        if ($(".rankCategoryArea").length == 0) {
            data1 = json.sortVos;
            var categoryHtml = '';
            for (var i = 0; i < data1.length; i++) {
                categoryHtml += '<div class="rankCategoryArea" data-id=' + data1[i].sortId + ' data-group=' + data1[i].groupId + '><span>' + data1[i].sortName + '</span><img src="img/index/categorySelect.png" alt=""></div>'
            }
            $(".categoryContentDetail1").html(categoryHtml);
            $(".rankCategoryArea span").eq(0).addClass("selectCategory").parent().find("img").show();
            $(".rankCategoryArea").click(function() {
                getplaymuic();
                $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
                $(this).find("span").addClass("selectCategory").parent().find("img").show();
                $(".categoryDetailButton span").eq(0).html($(this).find("span").html());
                jsonFilter.sortId = $(this).data("id");
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49)
            })
        }
    }
    function categoryContent1() {
        if ($(".babyAgeSelectDetail").length == 0) {
            var dataGroup = json.ageRange.groupId;
            var data2 = json.ageRange.tagList;
            var categoryHtml = '<div class="babyAgeSelectDetail noLimitedAge">不限</div>';
            for (var i = 0; i < data2.length; i++) {
                categoryHtml += '<div class="babyAgeSelectDetail" data-id=' + data2[i].tagId + '>' + data2[i].tagValue + '</div>'
            }
            $(".babyAgeSelect").html(categoryHtml);
            $(".babyAgeSelectDetail").click(function() {
                getplaymuic();
                $(".babyAgeSelectDetail").removeClass("selectCategory");
                $(this).addClass("selectCategory");
                if ($(this).hasClass("noLimitedAge")) {
                    delete jsonFilter.ageRange;
                    $(".categoryDetailButton span").eq(1).html("年龄")
                } else {
                    $(".categoryDetailButton span").eq(1).html($(this).text());
                    var ageRange = {};
                    ageRange.groupId = dataGroup;
                    ageRange.tagId = $(this).data("id");
                    jsonFilter.ageRange = ageRange
                }
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49)
            })
        }
    }
    function categoryContent2() {
        if ($(".categoryMainListDetail").length == 0) {
            data3 = json.categorys;
            var categoryHtml = '<div class="categoryMainListDetail unlimitedCategories"><img src="img/more.png" alt=""><span>不限</span></div>';
            var selectStyle = "";
            for (var i = 0; i < data3.length; i++) {
                selectStyle = "";
                if (data3[i].isSelected == 1) {
                    selectStyle = " categoryMainListSelect"
                }
                categoryHtml += '<div class="categoryMainListDetail' + selectStyle + '" data-id=' + data3[i].albumCategoryId + '><img src=' + data3[i].imageSrc + ' alt=""><span>' + data3[i].categoryName + '</span></div>'
            }
            $(".categoryContentDetail3").html(categoryHtml);
            $(".categoryMainListDetail").click(function() {
                getplaymuic();
                if ($(this).hasClass("unlimitedCategories")) {
                    $(".categoryMark").attr("src","img/categoryMarkHs.png")
                    $(".categoryDetailButton span").eq(2).html("分类");
                    delete jsonFilter.categoryId
                } else {
                    $(".categoryMark").attr("src","img/categoryMark.png")
                    $(".categoryDetailButton span").eq(2).html($(this).text());
                    jsonFilter.categoryId = $(this).data("id")
                }
                $(".categoryMainListDetail").removeClass("categoryMainListSelect");
                $(this).addClass("categoryMainListSelect");
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                $(".categoryMark").hide();
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49)
            })
        }
    }
    function categoryContent3() {
        eventPrevent = false;
        if ($(".filterSelectContentDetail").length == 0) {
            var categoryHtml = "";
            var sortNumFiter = {};
            data4 = json.filterTags;
            var data4Keys = Object.keys(data4);
            for (var i = 0; i < data4Keys.length; i++) {
                categoryButtonHtml = "",
                dataDetail = data4[data4Keys[i]];
                if (dataDetail instanceof Array) {
                    for (var k = 0; k < dataDetail.length; k++) {
                        dataDetailCont = dataDetail[k];
                        categoryHtmlAdd(dataDetailCont)
                    }
                } else {
                    categoryHtmlAdd(dataDetail)
                }
                function categoryHtmlAdd(dataDetails) {
                    categoryHtml = "";
                    var selectId = false;
                    var groupIdHtml = "";
                    for (var detailkeys in dataDetails) {
                        if (detailkeys.indexOf("select") > -1) {
                            selectId = dataDetails[detailkeys]
                        }
                        if (detailkeys == "groupId") {
                            groupIdHtml = 'data-group=' + dataDetails.groupId
                        }
                        if (dataDetails[detailkeys] instanceof Array) {
                            taglist = detailkeys
                        }
                    }
                    var dataDetailArr = dataDetails[taglist];
                    for (var keys in dataDetailArr[0]) {
                        if ("groupId" in dataDetailArr[0]) {
                            tagId = "tagId";
                            tagValue = "tagValue"
                        } else {
                            if (keys.indexOf("Id") > -1) {
                                tagId = keys
                            } else {
                                tagValue = keys
                            }
                        }
                    }
                    for (var categoryButtonHtml = "",
                    j = 0; j < dataDetailArr.length; j++) {
                        var selectStyle = (selectId && dataDetailArr[j][tagId] == selectId) ? " filterSelectedButton": "";
                        categoryButtonHtml += '<div class="filterSelectContentDetail' + selectStyle + '" data-id=' + dataDetailArr[j][tagId] + ' data-keys=' + tagId + '><span>' + dataDetailArr[j][tagValue] + '</span></div>'
                    }
                    categoryHtml += '<section class="filterArea"' + groupIdHtml + '><div class="filterSelectTitle"><span class="filterTitleName">' + dataDetails.cname + ':</span><p class="content-long-to-dotted">不限</p><img src="img/textButton1.png" alt=""></div><div class="filterSelectContent">' + categoryButtonHtml + '</div></section>';
                    sortNumFiter[dataDetails.sortNum] = categoryHtml
                }
            }
            for (var i = 0,categoryHtml = ""; i in sortNumFiter; i++) {
                categoryHtml += sortNumFiter[i]
            }
            $(".categoryContentDetail4").html(categoryHtml);
            var buttonHeight = $(window).width() / 10;
            $.each($(".filterSelectContent"),
            function(index, item) { !
                function(_this) {
                    setTimeout(function() {
                        var thisHeight = $(_this).height();
                        $(_this).data("height", thisHeight);
                        $(_this).css({
                            height: buttonHeight
                        });
                        if (thisHeight < buttonHeight * 1.5) $(_this).parent().find("img").addClass("triggleHide").hide()
                    },
                    10)
                } (this)
            });
            $(".filterSelectTitle").click(function() {
                $(".categoryContentDetail4").css({
                    "overflow": "hidden"
                });
                setTimeout(function() {
                    $(".categoryContentDetail4").css({
                        "overflow": "auto"
                    })
                },
                600);
                getplaymuic();
                if ($(this).find("img").hasClass("triggleHide")) return;
                $(this).find("img").toggleClass("zhuan");
                var dataHeight, _this = $(this).parent().find(".filterSelectContent");
                dataHeight = $(this).parent().find(".filterSelectContent").data("height");
                dataHeight = dataHeight - 0;
                _this.data("height", Math.ceil(_this.height())).height(dataHeight)
            });
            $(".filterSelectContentDetail").click(function() {
                getplaymuic();
                var contentLong = $(this).parent().parent().find(".content-long-to-dotted");
                var contentLongHtml = contentLong.data("content"),
                buttonContent = $(this).find("span").html(),
                contentLongText;
                if ($(this).hasClass("filterSelectedButton")) {
                    $(this).removeClass("filterSelectedButton");
                    var buttonContentPlace = contentLongHtml.indexOf(buttonContent);
                    if (buttonContentPlace > -1) {
                        if (buttonContentPlace > 0) {
                            buttonContent = "&nbsp;" + buttonContent
                        }
                        if (contentLongHtml == buttonContent) {
                            contentLongHtml = contentLong.data("define");
                            contentLong.html(contentLongHtml).data("content", contentLongHtml);
                            return
                        }
                        contentLongHtml = contentLongHtml.split(buttonContent);
                        contentLongHtml = contentLongHtml.join("");
                        contentLong.html(contentLongHtml).data("content", contentLongHtml)
                    }
                    contentLong.html(contentLong.data("define"));
                    return
                }
                $(this).parent().find(".filterSelectContentDetail").removeClass("filterSelectedButton");
                $(this).addClass("filterSelectedButton");
                if (contentLong.html().indexOf("不限") > -1) {
                    contentLong.data("define", contentLong.html()).html($(this).find("span").html()).data("content", $(this).find("span").html());
                    return
                }
                contentLong.html(buttonContent)
            })
        }
    }
    $(".manuArea div").eq(0).click(function() {
        getplaymuic();
        $(".filterSelectContentDetail").removeClass("filterSelectedButton");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        $.each($(".content-long-to-dotted"),
        function(index, item) {
            if ($(item).data("define")) {
                var itemDefine = $(item).data("define");
                $(item).html(itemDefine).data("content", itemDefine)
            }
        })
    });
    $(".manuArea div").eq(1).click(function() {
        getplaymuic();
        $(".manuArea").hide();
        selectCategoryOut();
        jsonInfo = {};
        var groupArr = [];
        if ($(".filterSelectedButton").length) {
            $.each($(".filterArea"),
            function(index, item) {
                var filterSelectedDetail = $(item).find(".filterSelectedButton");
                if (filterSelectedDetail.length > 0) {
                    var keys = filterSelectedDetail.eq(0).data("keys");
                    if (typeof $(item).data("group") !== "undefined") {
                        var groupElement = {};
                        groupElement.groupId = $(item).data("group");
                        groupElement[keys] = filterSelectedDetail.data("id");
                        groupArr.push(groupElement)
                    } else {
                        jsonInfo[keys] = filterSelectedDetail.data("id")
                    }
                }
            });
            if (groupArr.length) {
                jsonInfo.groupIds = groupArr
            }
            jsonFilter.filterInfo = jsonInfo;
            jsonFilter.pageSize = 12;
            jsonFilter.page = 0;
            pageIndex = 0;
            if (typeof(jsonFilter.filterInfo) !== "undefined") {
                $(".categoryIcon1").attr("src", "img/640_06.png");
            }
            $(".box").css("display", "-webkit-box");
            ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49)
        } else {
            delete jsonFilter.filterInfo;
            // jsonFilter.filterInfo = jsonInfo;
            jsonFilter.pageSize = 12;
            jsonFilter.page = 0;
            pageIndex = 0;
            ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49)
        }
    });
    function selectCategoryOut() {
        eventPrevent = false;
        $(".bgColor").hide();
        $(".translateShow").removeClass("translateShow").addClass("translateHide");
        $(".categoryMark").hide();
        // $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        setTimeout(function() {
            $(".categoryContentArea").hide()
        },
        500)
    }
}
var vipRedMarkText, redMarkText;
var creditPolicy = 0;
function returnCreditPolicy(json, id) {
    creditPolicy++;
    var num = Math.abs(JSON.parse(json).credits);
    if (id == "true") {
        vipRedMarkText = "积分：非VIP每集消耗" + num + "积分"
    } else {
        redMarkText = "积分：观看每集奖励" + num + "积分"
    }
    if (creditPolicy == 2) {
        ikanWebInterface.docReady("")
    }
}
var jsonFilter = {};
var hotKeysJson={};
$(function() {
    // init(jsonString);
     ikanWebInterface.getCreditPolicy("PLAYVIPVIDEO", "true");
     ikanWebInterface.getCreditPolicy("PLAYVIDEO", "false");
     $(document).on("click",".hotKeys span",function(){
        var hotKeys = $(this).text();
        hotKeys = hotKeys.replace(/\"/ig, "").replace(/\\/ig, "");
        $("#search").val(inputSlice(hotKeys));
        if ($(this).val() !== "") {
            var newHotKeys = [];
            for (var j = 0; j < hotKeysBox.length; j++) {
                if (hotKeysBox[j] !== hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
            }
            newHotKeys.unshift(hotKeys);
            hotKeysBox = newHotKeys;
            setItem();
        }
        clearFilter();
        switch ($(".selectArea span").text()) {
            case '全部':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',bool,49);
                break;
            case '动漫':
                jsonFilter.page = 0;
                jsonFilter.pageSize = 12;
                pageIndex = 0;
                jsonFilter.searchKey = hotKeys;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49);
                break;
            case '玩具':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,49);
                 break;
            case '知识':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,49);
                break;
            default:
                break;
        }
        // ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
        searchCancel();
     });
    $(document).fix("click", ".mangaAreaDetail",
    function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        $(".alertArea").hide();
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',49)
    },
    {
        "commOnce": true
    });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
});
function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop = 0
    }
    document.body.scrollTop = 0
}
var loadBottomHtml = $("#loadBottom").html();
var searchNullFlag = false;
function productLoad(data) {
    loadIndex++;
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    // debug(data)
    if(data.searchKey)$("#search").val(data.searchKey);
    if (data.status && data.status == 10) {
        if(pageIndex==0){
            dead();
            $(".dead").unbind("click").on("click",
            function() {
                getplaymuic();
                ikanWebInterface.reloadPage();
                $(".bgShadow").hide();
                // ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad');
                $(".box").show();
                $(".dead").hide()
            });
            return
        }
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click",function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5073, jsonString, "productLoad",49)
        });
        return
    }else{
        $(".dead").hide();
        $(".scrollContent").show();
     }
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    noService=false;
    if (data.status && data.status == 9 || (data.albums.length == 0 && pageIndex == 0)) {
        noService=true;
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        pageBottomFinish = false
        return
    }
    if (data.searchNullFlag || searchNullFlag) {
        if (data.searchNullFlag==1) {
            $(".sampleSearchArea").show();
            searchNullFlag = true;
        };
    }
    if ($(".bgShadow").hasClass("shadowSlide"))return;
    $("#searchImg").hide();
    $(".box").hide();
    $(".scrollContent").show();
    $(".categoryArea").show();
    $(".bgShadow").removeClass("shadowSlide");
    $(".sampleSearchArea").hide();
    
    data = data.albums;
    var productArr = [];
    if (data.length) {
        if (data.length < 12) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imageGrayTest",
        function(v1, v2) {
            if (v1 == true) {
                return v2
            } else {
                return ""
            }
        });
        Handlebars.registerHelper("imgUrlRechange",
        function(value, index) {
            var imgUrls = ImageUrl(value, ".220x300");
            var index = loadIndex * 12 + index;
            if (loadIndex > 0) {
                index = "cartoon" + index;
                productArr.push([imgUrls, index])
            }
            return imgUrls
        });
        Handlebars.registerHelper("indexChange",
        function(index) {
            return loadIndex * 12 + index
        });
        Handlebars.registerHelper("getAlbumCredits",
        function(isVip) {
            var isVipText = isVip ? vipRedMarkText: redMarkText;
            return isVipText
        });
        Handlebars.registerHelper("cartonsInformation",
        function(nowCount, totalCount) {
            var numInfo = (nowCount == 0) || (typeof(nowCount) == "undefined") ? totalCount + "集全": "更新至" + nowCount + "集";
            return numInfo
        });
        if (pageIndex == 0) {
            backTop();
            $('.cartoonArea').html(myTemplate(data))
        } else {
            $('.cartoonArea').append(myTemplate(data))
        }
        if (typeof(vertical) !== "undefined") {
            vertical.refresh()
        }
        if (loadIndex > 1) {
            for (var i = 0; i < productArr.length; i++) {
                if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                    ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1])
                }
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate")
}
function searchCancel() {
    eventPrevent = false;
    $(".bgShadow").removeClass("shadowSlide");
    $(".alertDetail").removeClass("alertDetailSelect").eq(1).addClass("alertDetailSelect");
    $(".selectArea span").text("动漫");
    $("#search").attr("placeholder","搜索动漫");
    if(noService){
        $("#searchImg").show();
    }else{
        $(".scrollContent").show();
    }
    $(".categoryArea").show();
    hotKeyFunc("albumHotKeys");
    alertAreaOut()
}
function alertAreaOut() {
    $(".alertArea").hide()
}
//判断输入框是否为空格
    var BlankSpace=true;
    function checkBlankSpace(str){
        while(str.lastIndexOf(" ")>=0){
            str = str.replace(" ","");
        }
        if(str.length == 0){
            BlankSpace=false;
        }else{
            BlankSpace=true;
        }
    }
function clearFilter() {
    jsonFilter = {};
    $.each($(".categoryDetailButton span"),
    function() {
        $(this).text($(this).data("clear"))
    });
    $(".categoryMainListSelect").removeClass("categoryMainListSelect");
    $(".unlimitedCategories").addClass("categoryMainListSelect");
    if ($(".rankCategoryArea span").length) $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
    if ($(".babyAgeSelectDetail").length) $(".babyAgeSelectDetail").removeClass("selectCategory");
    if ($(".manuArea div").length) {
        $(".filterSelectContentDetail").removeClass("filterSelectedButton");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        $.each($(".content-long-to-dotted"),
        function(index, item) {
            if ($(item).data("define")) {
                var itemDefine = $(item).data("define");
                $(item).html(itemDefine).data("content", itemDefine)
            }
        })
    }
}
function setItem() {
    var newHotKeysBox = hotKeysBox;
    newHotKeysBox = newHotKeysBox.join("&quot");
    localStorage.setItem("keys", newHotKeysBox)
}
var searchFunc = function() {
    getplaymuic();
    pageBottomFinish = false;
    eventPrevent=false;
    $(".bgColor").hide();
    $(".translateShow").removeClass("translateShow").addClass("translateHide");
    $(".categoryContentArea").hide();
    if (!$(".ManuButton").hasClass("ManuLeave")) {
        // eventPrevent = true;
        // $("#search").focus();
        // $(this).attr("placeholder", "");
        $(".alertArea").hide();
        $(".selectArea").css({
            display: "-webkit-box"
        }).show();
        // $(".categoryContentArea").hide().children().removeClass("translateShow").addClass("translateHide");
        // $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        $(".categoryMark").hide()
    }
    // $(".categoryArea").hide();
    $(".bgShadow").addClass("shadowSlide");
    $(".callBox").hide();
    if ($(".scrollContent").hide()) {
        // $(".scrollContent").show();
        $("#searchImg").hide();
    }
    $(".scrollContent").hide()
    $(".categoryArea").hide()
    var localhotKeys = window.localStorage;
    if (localhotKeys.length == 0) {
        $(".searchVagaa").hide()
    } else {
        $(".searchVagaa").show();
        localhotKeys = localhotKeys.getItem("keys");
        localhotKeys = localhotKeys.split("&quot").splice(0,10);
        hotKeysBox = localhotKeys;
        for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
            htmls += '<span id="hotKeys' + i + '">' + localhotKeys[i] + '</span>'
        }
        $(".vagaa").html(htmls);
        // $(".scrollContent").css("background","#efefef");
        if (isIphone) {
            $(".scrollContent")[0].scrollTop = 0;
        }
    }
    $(".vagaa span").click(function() {
        var hotKeys = $(this).text();
        $("#search").val(inputSlice(hotKeys));
        var newHotKeys = [];
        hotKeysBox = localhotKeys;
        for (var j = 0; j < hotKeysBox.length; j++) {
            if (hotKeysBox[j] !== hotKeys) {
                newHotKeys.push(hotKeysBox[j]);
            }
        }
        newHotKeys.unshift(hotKeys);
        hotKeysBox = newHotKeys;
        setItem();
        clearFilter();
        switch ($(".selectArea span").text()) {
            case '全部':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',bool,49);
                break;
            case '动漫':
                jsonFilter.page = 0;
                jsonFilter.pageSize = 12;
                pageIndex = 0;
                jsonFilter.searchKey = hotKeys;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',49);
                break;
            case '玩具':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,49);
                 break;
            case '知识':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,49);
                break;
            default:
                break;
        }
        searchCancel();
    });
    $(".vagaa span").click(function() {
        var hotKeys = $(this).text();
        $("#search").val(inputSlice(hotKeys));
        var newHotKeys = [];
        hotKeysBox = localhotKeys;
        for (var j = 0; j < hotKeysBox.length; j++) {
            if (hotKeysBox[j] !== hotKeys) {
                newHotKeys.push(hotKeysBox[j])
            }
        }
        newHotKeys.unshift(hotKeys);
        hotKeysBox = newHotKeys;
        setItem();
        
        searchCancel();
    })
    $("body").on("touchmove", function(){$("#search").blur()});
};
var shopcartFunc = function() {
    getplaymuic();
    if($(".bgShadow").hasClass("shadowSlide")){
            searchCancel();
        if (noService) {
            console.log(noService)
            $(".scrollContent").hide();
            $("#searchImg").show();
        }
    }else{
        ikanWebInterface.back();
    }
 };
 var hotKeyFunc=function  (hotType) {
    if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
        $(".hotText,.hotKeys").show();
        var hotJson=hotKeysJson[hotType];
        for (var htmls = "", i = 0; i < hotJson.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    else{
        $(".hotText,.hotKeys").hide();
    }
};
 var alertDetailFunc=function(){
     getplaymuic();
     $(".alertDetail").removeClass("alertDetailSelect");
     $(this).addClass("alertDetailSelect");
     var type = $(".selectArea span").text($(".alertDetailSelect").text());
     switch (type.text()) {
         case '全部':
             $("#search").attr("placeholder","搜索动漫/玩具/知识");
             hotKeyFunc("recommendHotKeys");
             break;
         case '动漫':
             $("#search").attr("placeholder","搜索动漫");
             hotKeyFunc("albumHotKeys");
             break;
         case '玩具':
             $("#search").attr("placeholder","搜索玩具");
             hotKeyFunc("productHotKeys");
              break;
         case '知识':
             $("#search").attr("placeholder","搜索知识");
             hotKeyFunc("knowledgeHotKeys");
             break;
         default:
             break;
     }
     alertAreaOut();
 };
var selectAreaFunc = function() {
    getplaymuic();
    if(!$(".bgShadow").hasClass("shadowSlide"))searchFunc();
    if ($(".categoryContentArea").css("display") == "block") {
        $(".categoryContentArea").hide();
        $(".categoryMark").hide();
        $(".categoryContentArea").children().removeClass("translateShow").addClass("translateHide");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        if (jsonFilter.filterInfo) {
            $(".categoryIcon1").attr("src", "img/640_06.png");
        }
        $(".manuArea").hide()
    }
    if ($(".alertArea").css("display") == "block") {
        $(".alertArea").css("display", "none");
        return
    }
    $(".alertArea").show()
};
function headerClickFunc() {
    var headerOptions = {
        "#search": searchFunc,
        ".cart_cancel": shopcartFunc,
        ".alertDetail": alertDetailFunc,
        ".selectArea": selectAreaFunc,
        ".callTopIcon": callTopFunc,
        ".deleteIcon":searchFunc
    };
    return headerOptions
} ! (function() {
    $("#search,.deleteIcon").click(function() {
        if($(this).hasClass("deleteIcon"))$("#search").val("");
        if (androidVersionNum == 0 || androidVersionNum >= 440) searchFunc.apply(this);
    })
    $("#search").blur(function() {
        // $(this).attr("placeholder", "搜索动漫");
    });
    // $(document).on("click", ".bgShadow",
    // function() {
    //     getplaymuic();
    //     eventPrevent = false;
    //     $(".bgShadow")[0].scrollTop = 0;
    //     $(".alertArea").hide();
    //     // $(this).removeClass("shadowSlide")
    //     $(".scrollContent").show()
    //     $(".categoryArea").show()
    // });
    $(".cart_cancel").click(function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) shopcartFunc.apply(this)
    });
    if(isIphone){
        $("#search").on("search", function(event) {
           onSearch();     
        });
    }
    else{
        $("#search").on("keydown", function(event) {
            if(event.keyCode==13){
                onSearch();     
            }
        });
    }
    function onSearch() {
            $("input").blur();
            var hotKeys = $("#search").val();
            hotKeys=hotKeys.replace(/\"/ig,"").replace(/\\/ig,"").replace(/\//ig,"");
            $("#search").val(inputSlice(hotKeys));
            checkBlankSpace(hotKeys);
            if (hotKeys!==" "&&BlankSpace==true) {
                var newHotKeys = [];
                for (var j = 0; j < hotKeysBox.length; j++) {
                    if (hotKeysBox[j] !== hotKeys) {
                        newHotKeys.push(hotKeysBox[j])
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox = newHotKeys
                setItem();
            }
            // $(".box").css("display", "-webkit-box");
            clearFilter();
            switch ($(".selectArea span").text()) {
                case '全部':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}', bool,49);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}', bool,49);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,49);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,49);
                    break;
                default:
                    break;
            }
            searchCancel();
            // ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad')
    };
    $(document).on("click", ".selectArea",
    function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) selectAreaFunc.apply(this)
    });
    $(window).swipe(function() {
        if ($(".alertArea").show()) {
            $(".alertArea").hide()
        }
    });
    $(document).on("click", ".alertDetail",
    function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) alertDetailFunc.apply(this)
    })
})();