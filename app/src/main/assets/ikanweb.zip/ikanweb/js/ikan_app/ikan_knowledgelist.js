var jsonString = '{"categorys":[{"isSelected":"0","albumCategoryId":14,"imageSrc":"http://webimg.ikan.cn/ximages/video/albumCategory/85f85197-df66-4cd7-bef8-c2217b7539ac.png","categoryName":"英语"},{"isSelected":"0","albumCategoryId":10,"imageSrc":"http://webimg.ikan.cn/ximages/video/albumCategory/81fe8529-b71f-4c1c-bbdc-a2d7e9dd5dd9.png","categoryName":"数学逻辑"},{"isSelected":"0","albumCategoryId":11,"imageSrc":"http://webimg.ikan.cn/ximages/video/albumCategory/0ac60dee-8574-4de4-8f07-53a2fc39e917.png","categoryName":"国学语文"},{"isSelected":"0","albumCategoryId":12,"imageSrc":"http://webimg.ikan.cn/ximages/video/albumCategory/f848e1cf-c0ec-4bc6-b7d4-6adbad01bf3a.png","categoryName":"音乐儿歌"},{"isSelected":"1","albumCategoryId":13,"imageSrc":"http://webimg.ikan.cn/ximages/video/albumCategory/bb9b0d9d-9810-4adf-ac0e-8a42c3c8d909.png","categoryName":"科学科普"},{"isSelected":"0","albumCategoryId":15,"imageSrc":"http://webimg.ikan.cn/ximages/video/albumCategory/63ae5aec-8ded-4ed2-a02b-ed48dbaa7615.png","categoryName":"生活常识"}],"title":"科学科普","knowledgeVideos":[{"specialType":0,"id":400,"totalCount":424,"snapshot":"http://webimg.ikan.cn/ximages/album/e552933d-25eb-4690-b8c3-b1527f484b73.png","nowCount":0,"age":"6~12岁","typeName":"科学科普","vip":0,"name":"蓝猫淘气3000问 幽默系列"},{"specialType":0,"id":397,"totalCount":312,"snapshot":"http://webimg.ikan.cn/ximages/album/89c3a3f2-6ebd-4b69-9d7e-c5844ab7ae58.png","nowCount":0,"age":"6~12岁","typeName":"科学科普","vip":0,"name":"蓝猫淘气3000问 海洋世界"},{"specialType":0,"id":328,"totalCount":26,"snapshot":"http://webimg.ikan.cn/ximages/album/1d53c03f-7f6f-49dc-8463-ada4901a197a.jpg","nowCount":0,"age":"6岁以上","typeName":"科学科普","vip":0,"name":"培养当代革命军人核心价值观二"},{"specialType":0,"id":424,"totalCount":52,"snapshot":"http://webimg.ikan.cn/ximages/album/2df46974-d88f-4c2c-ae4f-2b1f04492cff.png","nowCount":0,"age":"3~8岁","typeName":"科学科普","vip":0,"name":"拯救地球，麦圈可可在行动"},{"specialType":0,"id":486,"totalCount":60,"snapshot":"http://webimg.ikan.cn/ximages/album/94d4a3ae-1df3-4847-9ccf-e9b2919248d7.png","nowCount":0,"age":"3~5岁","typeName":"科学科普","vip":0,"name":"蓝猫幼儿科学"},{"specialType":0,"id":549,"totalCount":14,"snapshot":"http://webimg.ikan.cn/ximages/album/55e3d4a9-d6b4-428d-a26c-b530760e5b72.png","nowCount":0,"age":"6岁以上","typeName":"科学科普","vip":0,"name":"绿豆蛙建国60年"},{"specialType":0,"id":563,"totalCount":210,"snapshot":"http://webimg.ikan.cn/ximages/album/a6cf4bd7-f474-4481-a197-dd46b254bdca.jpg","nowCount":210,"age":"3~9岁","typeName":"科学科普","vip":0,"name":"哈哈熊漫游世界"},{"specialType":0,"id":537,"totalCount":33,"snapshot":"http://webimg.ikan.cn/ximages/album/ef07a9af-3ae4-40ac-a485-8288c1bb7cda.jpg","nowCount":0,"age":"3~5岁","typeName":"科学科普","vip":0,"name":"洪恩宝宝问世界"},{"specialType":0,"id":398,"totalCount":400,"snapshot":"http://webimg.ikan.cn/ximages/album/9ba67808-da7e-433e-9a1b-5d64c2979c56.png","nowCount":0,"age":"6~12岁","typeName":"科学科普","vip":0,"name":"蓝猫淘气3000问 航天系列"},{"specialType":0,"id":499,"totalCount":120,"snapshot":"http://webimg.ikan.cn/ximages/album/1258e107-9d13-461c-879b-d319faba55d4.png","nowCount":0,"age":"3~8岁","typeName":"科学科普","vip":0,"name":"蓝猫明星梦工厂"},{"specialType":0,"id":482,"totalCount":48,"snapshot":"http://webimg.ikan.cn/ximages/album/e5470a23-aa6b-442e-b1a6-4ba92a018c96.png","nowCount":0,"age":"6~12岁","typeName":"科学科普","vip":0,"name":"蓝猫小学科学"},{"specialType":0,"id":557,"totalCount":52,"snapshot":"http://webimg.ikan.cn/ximages/album/10dd4322-01ad-432b-839f-6cbbc7fe0ed9.jpg","nowCount":0,"age":"3~12岁","typeName":"科学科普","vip":0,"name":"奇妙小世界"}],"compositiveSort":[{"sortId":0,"sortName":"综合"},{"sortId":1,"sortName":"热播"},{"sortId":2,"sortName":"最新"}],"ageRange":{"tagList":[{"groupId":13,"tagId":1,"tagValue":"0-3岁","tagName":"年龄"},{"groupId":13,"tagId":2,"tagValue":"3-6岁","tagName":"年龄"},{"groupId":13,"tagId":3,"tagValue":"6+","tagName":"年龄"}],"groupId":13,"cname":"年龄"},"categoryId":13}';
function init(json) {
    // try {
    // initTest(json)
    //     } catch (e) {
    //         document.write(e.name);
    //         document.write(e.number);
    //         document.write(e.description);
    //         document.write(e.message);
    //         document.write(json);
    //     }
    setTimeout(function() {
        initTest(json);
    }, 100);
}
function initTest(json) { //初始化页面方法
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    $(".scrollContent").show();
    if (json.status && json.status == 9 ) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        return;
    }
    console.log(json)
    productLoad(json);
    if(json.title){
        $(".heaerTitle").html(json.title);
        $(".categoryDetailButton").eq(2).find("span").html(json.title);
    }

    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    }, 300);
    var backBut = true,
        cartBat = true,
        performanceBut = true;
    loadImage("scrollContent", callPageLoad);
    jsonFilter.categoryId = json.categoryId;
    function callPageLoad(pageIndex) { //分页回掉函数
        jsonFilter.pageSize = 12;
        jsonFilter.page = pageIndex;
        ikanWebInterface.command(5074, JSON.stringify(jsonFilter), "productLoad",15);
    }
    var markPostionArr = ["2.36rem", "7.9rem", "12.88rem"];
    var categoryContentObj = $("div[class^='categoryContent']");
    var categoryInterval = null;
    $(".categoryDetailButton").unbind("click").bind("click", function(event) {
        getplaymuic();
        clearTimeout(categoryInterval);
        $(".callTopButton").hide();
        $(".bg").removeClass("translateHide").css("opacity", 1);
        // $(".categoryArea").css("border-bottom", "1px solid #f8f8f8");
        eventPrevent = true;
        var categoryIndex = $(this).index();
        if($(".translateShow").length==0){
             $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
        if (categoryIndex == 2 && $(".categoryMainListSelect").hasClass("unlimitedCategories")) {
            $(".categoryMark").attr("src","img/categoryMarkHs.png")
        }else{
            $(".categoryMark").attr("src","img/categoryMark.png")
        }
        if (categoryContentObj.eq(categoryIndex).hasClass("translateShow")) {
            eventPrevent = false;
            $(".bgColor").hide();
            $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
            $(".categoryMark").hide();
            categoryInterval=setTimeout(function(){$(".categoryContentArea").hide();},500);
            categoryContentObj.eq(categoryIndex).removeClass("translateShow").addClass("translateHide");
            $(".categoryIcon").attr("src", "img/640_16.png").eq(3).attr("src", "img/640_11.png");
            if (jsonFilter.filterInfo) {
                $(".categoryIcon").eq(3).attr("src", "img/640_06.png");
            }
            return;
        }
        $(".bgColor").show();
        $(".categoryMark").css({
            left: markPostionArr[categoryIndex]
        }).show();
        var categoryContentEval = "categoryContent" + categoryIndex + "()";
        $(".categoryIcon").attr("src", "img/640_16.png").eq(3).attr("src", "img/640_11.png");
        if (jsonFilter.filterInfo) {
            $(".categoryIcon").eq(3).attr("src", "img/640_06.png");
        }
        $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_14.png");
        eval(categoryContentEval);
        $(".manuArea").hide();
        if ($(".translateShow").length) {
            categoryContentObj.eq(preIndex).removeClass("translateShow");
        } else {
            $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
        categoryContentObj.removeClass("translateHide").removeClass("translateShow").addClass("translateHide").eq(categoryIndex).removeClass("translateHide").addClass("translateShow");
        preIndex = categoryIndex;
        if ($(".categoryContentArea").css("display") == "block") {
            $(".bg").unbind("click").click(function() {
                getplaymuic();
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon").eq(3).attr("src", "img/640_06.png");
                }
                $(".bgColor").hide();
                $(".categoryMark").hide();
                $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);")
                eventPrevent = false;
                $(".translateShow").removeClass("translateShow").addClass("translateHide");
                setTimeout(function(){$(".categoryContentArea").hide()},300);
                $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_16.png");
            });
        }
    });
    //综合排序
    function categoryContent0() {
        if ($(".rankCategoryArea").length == 0) {
            data1 = json.compositiveSort;
            var categoryHtml = '';
            for (var i = 0; i < data1.length; i++) {
                categoryHtml += '<div class="rankCategoryArea" data-id=' + data1[i].sortId + ' data-group=' + data1[i].groupId + '><span>' + data1[i].sortName + '</span><img src="img/index/categorySelect.png" alt=""></div>';
            }
            $(".categoryContentDetail1").html(categoryHtml);
            $(".rankCategoryArea span").eq(0).addClass("selectCategory").parent().find("img").show();
            $(".rankCategoryArea").click(function() {
                getplaymuic();
                $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
                $(this).find("span").addClass("selectCategory").parent().find("img").show();
                $(".categoryDetailButton span").eq(0).html($(this).find("span").html());
                jsonFilter.sortId = $(this).data("id");
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',15);
            });
        }
    }
    function categoryContent1() {
        if ($(".babyAgeSelectDetail").length == 0) {
            var dataGroup = json.ageRange.groupId;
            var data2 = json.ageRange.tagList;
            var categoryHtml = '<div class="babyAgeSelectDetail noLimitedAge">不限</div>';
            for (var i = 0; i < data2.length; i++) {
                categoryHtml += '<div class="babyAgeSelectDetail" data-id=' + data2[i].tagId + '>' + data2[i].tagValue + '</div>';
            }
            $(".babyAgeSelect").html(categoryHtml);
            $(".babyAgeSelectDetail").click(function() {
                getplaymuic();
                $(".babyAgeSelectDetail").removeClass("selectCategory");
                $(this).addClass("selectCategory");
                if ($(this).hasClass("noLimitedAge")) {
                    delete jsonFilter.ageRange;
                    $(".categoryDetailButton span").eq(1).html("年龄");
                } else {
                    $(".categoryDetailButton span").eq(1).html($(this).text());
                    var ageRange = {};
                    ageRange.groupId = dataGroup;
                    ageRange.tagId = $(this).data("id");
                    jsonFilter.ageRange = ageRange;
                }
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',15);
            });
        }
    }
    function categoryContent2() {
        if ($(".categoryMainListDetail").length == 0) {
            data3 = json.categorys;
            var selectStyle = "";
            var categoryHtml = '<div class="categoryMainListDetail unlimitedCategories"><img src="img/more.png" alt=""><span>不限</span></div>';
            for (var i = 0; i < data3.length; i++) {
                selectStyle = "";
                if (data3[i].isSelected == 1) {
                    selectStyle = " categoryMainListSelect";
                }
                categoryHtml += '<div class="categoryMainListDetail' + selectStyle + '" data-id=' + data3[i].albumCategoryId + '><img src="' + data3[i].imageSrc + '" alt=""><span>' + data3[i].categoryName + '</span></div>';
            }
            $(".categoryMainList").html(categoryHtml);
            $(".categoryMainListDetail").click(function() {
                getplaymuic();
                if ($(this).hasClass("unlimitedCategories")) {  
                    $(".categoryMark").attr("src","img/categoryMarkHs.png")
                    $(".heaerTitle").html("全部分类");
                    $(".categoryDetailButton span").eq(2).html("分类");
                    delete jsonFilter.categoryId;
                } else {
                    $(".categoryMark").attr("src","img/categoryMark.png")
                    $(".categoryDetailButton span").eq(2).html($(this).text());
                    jsonFilter.categoryId = $(this).data("id");
                    $(".heaerTitle").html($(this).text());
                }
                $(".categoryMainListDetail").removeClass("categoryMainListSelect");
                $(this).addClass("categoryMainListSelect");
                selectCategoryOut();
                $(".box").css("display", "-webkit-box");
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                $(".categoryMark").hide();
                ikanWebInterface.command(5074, JSON.stringify(jsonFilter), 'productLoad',15);
            });
        }
    }
    function selectCategoryOut() {
        eventPrevent = false;
        $(".bgColor").hide();
        $(".translateShow").removeClass("translateShow").addClass("translateHide");
        $(".categoryMark").hide();
        $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
        $(".categoryIcon").attr("src", "img/640_16.png").eq(3).attr("src", "img/640_11.png");
        setTimeout(function() {
            $(".categoryContentArea").hide();
        }, 500);
    }
}
var jsonFilter = {};
var vipRedMarkText = 1,
    redMarkText = "2";
var creditPolicy = 0;
var back=function(){
    getplaymuic();
    ikanWebInterface.back(); //安卓
};
var shoppingCart=function(){
    getplaymuic();
    ikanWebInterface.startIkanScheme('ikan://download/',' ',15);
};
function headerClickFunc(){
    var headerOptions={
        ".J_backButton":back,
        ".J_shoppingCart":shoppingCart,
        ".callTopIcon":callTopFunc
    };
    return headerOptions;
}
$(function() {
    // init(jsonString);
    $(".J_backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".J_shoppingCart").touchdown(function() {
        $(this).css({
            "background": "url(img/index/downloada.png) no-repeat center",
             "background-size":"36px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/index/download1.png) no-repeat center",
            "background-size":"36px"
        });
    });
    ikanWebInterface.getCreditPolicy("PLAYVIPVIDEO", "true");
    ikanWebInterface.getCreditPolicy("PLAYVIDEO", "false");
    $(".J_backButton").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
    });
    //逻辑todo购物车
    $(".J_shoppingCart").click(function() { 
        if(androidVersionNum==0||androidVersionNum>=440)shoppingCart.apply(this);
    });
    $(document).fix("click", ".mangaAreaDetail", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',15);
    }, {
        "commOnce": true
    });
});
function returnCreditPolicy(json, id) { //积分回掉函数
    creditPolicy++;
    var num = Math.abs(JSON.parse(json).credits);
    if (id == "true") {
        vipRedMarkText = "积分：非VIP每集消耗" + num + "积分";
    } else {
        redMarkText = "积分：观看每集奖励" + num + "积分";
    }
    if (creditPolicy == 2) {
        ikanWebInterface.docReady("");
    }
}
function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop = 0;
    }
    document.body.scrollTop = 0;
}
function productLoad(data) {
    // try {       
    productLoadTest(data)
        // } catch (e) {
        //     document.write(e.name);
        //     document.write(e.number);
        //     document.write(e.description);
        //     document.write(e.message);
        // }
}
var loadBottomHtml = $("#loadBottom").html();
var searchNullFlag=false;
function productLoadTest(data) {
    $("#searchImg").hide();
    loadIndex++;
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        if (pageIndex == 0) {
            dead();
            $(".dead").unbind("click").on("click",
                function() {
                    getplaymuic();
                    ikanWebInterface.reloadPage();
                    $(".bgShadow").hide();
                    // ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
                    $(".box").show();
                    $(".dead").hide();
                });
            return;
        }
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5074, jsonString, "productLoad",15);
        });
        return;
    }else{
        $(".dead").hide();
        $(".scrollContent").show();
     }
    $(".box").hide();
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    if (data.status && data.status == 9 || (data.knowledgeVideos.length == 0 && pageIndex == 0)) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        return;
    }
    if (data.searchNullFlag||searchNullFlag) { //相似搜索结果添加部分
        backTop();
        $(".sampleSearchArea").show();
        $(".cartoonArea").css({
            "margin-top": 0
        });
        searchNullFlag=true;
    } else {
        $(".sampleSearchArea").hide();
        $(".cartoonArea").css({
            "margin-top": "1.9rem"
        });
    }
    $(".scrollContent").show();
    data = data.knowledgeVideos;
    var productArr = [];
    if (data.length) {
        if (data.length < pageSize) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".220x300");
            var index = initSize+loadIndex * pageSize + index;
            if (loadIndex > 0) {
                index = "cartoon" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("imageGrayTest", function(v1, v2) {
            if (v1 == true) {
                return v2;
            } else {
                return "";
            }
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return index = initSize+loadIndex * pageSize + index;
        });
        Handlebars.registerHelper("getAlbumCredits", function(isVip) { //积分函数
            var isVipText = true;
            var isVipText = isVip ? vipRedMarkText : redMarkText;
            return isVipText;
        });
        Handlebars.registerHelper("cartonsInformation", function(nowCount, totalCount) {
            var numInfo = (nowCount == 0) || (typeof(nowCount) == "undefined") ? totalCount + "集全" : "更新至" + nowCount + "集";
            return numInfo;
        });
        if (pageIndex == 0) {
            backTop();
            $('.cartoonArea').html(myTemplate(data));
        } else {
            $('.cartoonArea').append(myTemplate(data));
        }
        if (typeof(vertical) !== "undefined") {
            vertical.refresh();
        }
        if (loadIndex > 1) {
            for (var i = 0; i < productArr.length; i++) {
                if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                    ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
                }
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}
    