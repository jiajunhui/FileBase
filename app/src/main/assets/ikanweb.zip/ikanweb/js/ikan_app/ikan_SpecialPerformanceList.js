function init(json) {
    // try{
    // 	initTest(json)
    // }
    // catch(e){
    // 	document.write(e.name);
    // 	document.write(e.number);
    // 	document.write(e.description);
    // 	document.write(e.message);
    // 	document.write(json.fontcolor("#fff"));
    // }
    setTimeout(function() {
        initTest(json);
    }, 100);
}
function initTest(json) {
        var BOX = '<div class="refreshBox"><div class="refreshImageBox"><img src="img/loading.png" alt="" class="refreshImage"></div><p class="refreshText">下拉刷新</p></div><div class="callTopButton"><img src="img/top.png" class="callTopIcon"></div>';
        var HTML = '<div class="activity_lists"></div><div id="loadBottom"><div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span></div>';
        var obj = $(".scrollContent");
        var obj1 = $(".callBox")
        $("*", obj).add([obj]).each(function() {
            $.event.remove(this);
            $(this).empty();
        });
        $("*", obj1).add([obj1]).each(function() {
            $.event.remove(this);
            $(this).empty();
        });
        $.event.remove(window);
        obj.innerHTML = "";
        $(".callBox").append(BOX);
        $(".scrollContent").prepend(HTML);
        initParam();
        json = typeof(json) == "string" ? JSON.parse(json) : json;
        if (json.status && json.status == 10) {
            dead();
            $(".dead").unbind("click").on("click", function() {
                getplaymuic();
                ikanWebInterface.reloadPage();
                $(".box").show();
                $(".dead").hide();
            });
            return;
        }
        var backBut = true,
            cartBat = true,
            performanceBut = true;
        activityLoad(json);
        setTimeout(function() {
            $(".box").hide();
        }, 500);
        $(".scrollContent").animate({
            opacity: 1
        }, 100);
        function callPageLoad(pageIndex) {
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5050, jsonString, "activityLoad",4);
        }
        loadImage("scrollContent", callPageLoad); //分页函数调用
        $(".clockTime").text("活动即将开始");
        var myDate = new Date();
        
    }
    // jsonString=[{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"0"
    // 	},
    // 		{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"1"
    // 	},
    // 	{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"1"
    // 	},
    // 	{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"0"
    // 	}
    // ];
jsonString = '{"specialList":[{"isBegin":false,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/acd88719-dc7a-478e-9194-164c483e0fa8.jpg","endDate":"2021.01.07 13:25","productCollect":"小推车  费雪","specialName":"费雪小推车满减专场","description":"费雪小推车   双十一促销   满20减10元","isOver":false,"id":20,"startDate":"2015.06.08 13:25"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/1c724cc9-f58f-4e5c-8826-f3c68497beff.png","endDate":"2020.12.11 17:28","productCollect":"变形金刚4 经典领袖级 擎天柱","specialName":"1元特惠","description":"手工改价格,1015594","isOver":false,"id":17,"startDate":"2015.11.23 10:30"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/28dea847-7cf7-40e8-b3af-9868797f9280.png","endDate":"2015.11.13 00:00","productCollect":"1元秒杀","specialName":"1元秒杀","description":"","isOver":true,"id":18,"startDate":"2015.09.13 00:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/b7230870-2bff-4c7f-bfb5-8690e93e6ea0.jpg","endDate":"2015-10-31 09:40","productCollect":"0-50元部分商品","specialName":"0\u201450元商品专场","description":"","isOver":true,"id":10,"startDate":"2015.09.13 15:15"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/e39f4d55-93de-4237-851b-7502c54a8b76.jpg","endDate":"2015.10.30 11:00","productCollect":"口罩商品","specialName":"口罩专场测试","description":"","isOver":true,"id":19,"startDate":"2015.10.21 11:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/261a8b27-0a55-4217-a337-32f980c5465d.png","endDate":"2015.10.11 23:59","productCollect":"APP独享VIP底价","specialName":"APP独享VIP底价","description":"","isOver":true,"id":1,"startDate":"2015.09.11 00:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/5e7046da-56df-4471-8f90-df0330b8b077.png","endDate":"2015.10.11 23:59","productCollect":"费雪品牌集合","specialName":"育儿专家强力推荐","description":"","isOver":true,"id":2,"startDate":"2015.09.11 00:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/c139cc80-0ebc-488e-9785-272439bafa6b.png","endDate":"2015.10.11 23:59","productCollect":"贝恩施品牌集合","specialName":"宝宝的童年，由我们相伴！","description":"","isOver":true,"id":3,"startDate":"2015.09.11 00:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/5529e6a6-8176-43b7-a40c-ee5b19888846.png","endDate":"2015.10.11 23:59","productCollect":"爱奇艺动画屋","specialName":"别闹了，缤纷价格4.3折起！","description":"","isOver":true,"id":4,"startDate":"2015.09.11 00:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/1c8b7b20-c2d4-45a7-b6ec-5876cbc73844.png","endDate":"2015.10.11 23:59","productCollect":"爱奇艺臻选玩具","specialName":"天赋是玩出来的！","description":"","isOver":true,"id":5,"startDate":"2015.09.11 00:00"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/b5f0afec-ffba-40a0-a97f-9166f74e89b2.png","endDate":"2015.10.11 23:59","productCollect":"限时秒杀5款","specialName":"限时秒杀惠","description":"","isOver":true,"id":6,"startDate":"2015.09.16 18:15"},{"isBegin":true,"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/1ac65fbb-177b-453c-97ea-0ae33598339e.png","endDate":"2015.10.11 23:59","productCollect":"乐高品牌集合","specialName":"玩具也能玩出聪明宝宝！","description":"","isOver":true,"id":7,"startDate":"2015.09.11 00:00"}]}';
//var jsonString='{"aa":123,"bb":123}'
var indexMark = "recommendIndex";
var back=function(){
    getplaymuic();
    ikanWebInterface.back();
};
function headerClickFunc(){
    var headerOptions={
        ".backButton":back,
        ".callTopIcon":callTopFunc
    };
    return headerOptions;
}
$(function() {
    // init(jsonString);
    $(".backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".backButton").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
    });
    ikanWebInterface.docReady('');
    //点击促销活动,页面跳转到详情页	
    $(document).fix("click", ".activity", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
            // var schemeContent = 'http://172.16.218.42/Web_app/ikan_specialPerformanceDetail.html#{"command":5018,"params":{"ebSpecialId":' + $(this).data("id") + '}}';
            var schemeContent = 'ikan://web/ikan_specialPerformanceDetail.html#{"command":5018,"params":{"ebSpecialId":' + $(this).data("id") + '}}';
            ikanWebInterface.startIkanScheme(schemeContent,' ',4);
    }, {
        "commOnce": true
    });
});
var loadBottomHtml = '<div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span>';
function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop =0;
    }
    document.body.scrollTop = 0;
}
function activityLoad(data) {
    var productArr = [];
    // debug(data)
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (!data.specialList) {
        $("#loadBottom").html("已经加载完成");
        return;
    }
    // debug(data)
    if (data.status && data.status == 10) {
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5050, jsonString, "activityLoad",4);
        });
        return;
    }
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    data = data.specialList;
    if (data.length) {
        if (data.length < 12) {
            setTimeout(function() {
                $("#loadBottom").html("已经加载完成");
                pageBottomFinish = false;
            }, 1000);
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("activityBeginTest", function(isBegin,activityBegins) {
            if (isBegin == false) {
                return activityBegins;
            } else {
                return '';
            }
        });
        Handlebars.registerHelper("imageGrayTest", function(v1, v2,v3) {
            if (v1 == true) {
                if (v2 == "shadowBox" && isIphone) {
                    return "";
                }
                return v2;
            } else {
                return v3;
            }
        });
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".590x368");
            var index = initSize+pageIndex * pageSize + index;
            if (pageIndex > 0) {
                index = "productDetail" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return index = initSize+pageIndex * pageSize + index;
        });
        Handlebars.registerHelper("startDateSplite", function(v1) {          
            if(v1.indexOf(".")>-1){
                var startDateTimesOne = v1.split(".");
            }else{
                var startDateTimesOne = v1.split("-");
            }
            // if(startDateTimesOne[1]<10){
                // var startDateMouth = startDateTimesOne[1].slice(1,2)
            // }else{
                var startDateMouth = startDateTimesOne[1]
            // }
            var startDateTimesTwo = startDateTimesOne[2].split(" ");
            // if(startDateTimesTwo[0]<10){
                // var startDateDay = startDateTimesTwo[0].slice(1,2)
            // }else{
                var startDateDay = startDateTimesTwo[0]
            // }
            var startDateTime = startDateTimesOne[0]+'年'+startDateMouth+'月'+startDateDay+'日'+' '+startDateTimesTwo[1];
            return startDateTime
        });

        if (pageIndex == 0) {
            backTop();
            $('.activity_lists').html(myTemplate(data));
        } else {
            $('.activity_lists').append(myTemplate(data));
        }
        if(pageIndex>0){
            for (var i = 0; i < productArr.length; i++) {
                ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
            }
        }
    } else {
        setTimeout(function() {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }, 1000);
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}