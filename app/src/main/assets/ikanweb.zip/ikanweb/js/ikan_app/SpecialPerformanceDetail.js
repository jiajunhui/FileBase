 var jsonString='{"ebProductList":[{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/96f49b9b-25f3-44cb-be8b-dbe7d8ca6701.jpg","totalNumber":0,"productCode":3001052,"skuCodes":[300105201],"price":129,"vprice":98,"sortNum":0,"storageStatus":0,"productName":"乐高 城市系列 消防指挥车 （5-12岁）","svprice":97,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301,300105302],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/b8075b5f-6778-45a4-b508-afd896f98651.jpg","totalNumber":0,"productCode":3001053,"skuCodes":[300105301],"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 火警救援（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/1f797709-2c87-4f53-a7f1-8dad7f0a587f.jpg","totalNumber":0,"productCode":3001054,"skuCodes":[300105401],"price":899,"vprice":683,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 消防总局(6-12岁）","svprice":597,"status":1}],"isBegin":false,"coupons":[{"minAmount":0,"couponName":"现金券-促销-测试","money":100,"available":false,"id":1015909,"isObtainCoupon":"0"},{"minAmount":500,"couponName":"满减券","money":50,"available":false,"id":1015911,"isObtainCoupon":"0"},{"minAmount":10,"couponName":"3645","money":10,"available":false,"id":1016154,"isObtainCoupon":"0"}],"specialImage":"http://webimg.ikan.cn/test/ximages/eb/special/e6f20edf-016e-40af-b694-1d1c2b03d45b.jpg","endDate":"2016.6.16 20:00","productCollect":"乐高系列产品","specialName":"乐高秒杀专场人让VC他热源儿童让他打钩","description":"乐高产品限量秒杀，抢到就是赚到，衣服和水电费 腐恶日偶偶尔哦肯定加合法加快速度。年底发斯蒂芬送快递就黄飞鸿肯定就是发生的会计法而巨额我了快速的就会发生的会计法轻轻去去去","isOver":false,"shareUrl":"http://172.16.218.11/mobile/share/mobileAppAddress.html?isRemote=0&redirectUrl=ikan://web/ikan_specialPerformanceDetail.html#@ltcommand:5018,params:@ltebSpecialId:33@gt@gt","id":33,"startDate":"2016.03.02 19:30"}'
function init(json) {
    // try {
    // initTest(json)
    // } catch (e) {
    //     document.write(e.name);
    //     document.write(e.number);
    //     document.write(e.description);
    //     document.write(e.message);
    //     document.write(json);
    // }
    setTimeout(function() {
        initTest(json);
    }, 100);
}
function initTest(json) { //初始化页面方法
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    console.log(json)
    ebSpecialId = json.id;
    var performanceBut = true;
    var specialName = slices(json.specialName, 11);
    $(".heaerTitle").html(specialName);
    $(".SpecialPerformanceTitle").html(json.specialName);
    var imgUrls = ImageUrl(json.specialImage, ".640x400");
    $(".activeArea img").data("image", imgUrls); //对活动页进行图片赋值
    // $(".startDate").html("开始时间：" + startDateSplite(json.startDate));
    // $(".endDate").html("结束时间：" + startDateSplite(json.endDate));
    startDateSplite(json.endDate);
    var t=window.setInterval(function(){
        ShowCountDown(y,m,d,h,s,'timeBox');
        if (leftsecond==0) {
            clearTimeout(t);
        }
    }, 1000);
    var description = json.description;
    if (description.length > 0) {
        $(".activeInstructions").html("活动说明：" + json.description);
    } else {
        $(".activeInstructions").html();
    }
    if (json.productCollect.length) {
        $(".SpecialPerformanceCategory").html("活动商品：" + json.productCollect);
    }else{
        $(".SpecialPerformanceCategory").html(); 
    }
    
    // $(".activeArea img").click(function() {
    //         if (!clickUsed && !lazyLoad.parentFixed(event)) return;
    //         var schemeContent ='ikan_specialPerformanceDetail.html#{"command":5018,"params":{"ebSpecialId":' + json.id + '}}';
    //         ikanWebInterface.startIkanScheme('http://172.16.218.42/Web_app/'+schemeContent);
    //     })
    //优惠券内容填充  字符串拼接json.coupons.length
    switch (json.coupons.length) {
        case 0: //如果是1个优惠券
            $(".activeDot").removeClass();
            $(".J_activeCouponsArea").removeClass();
            break;
        case 1: //如果是1个优惠券
            var isObtainCoupon = "",
                couponsText = "立即领取";
            if (json.coupons[0].isObtainCoupon == 1) {
                $(".activeContentDetail").unbind("click")
                isObtainCoupon = 'style="background-image:url(img/special11.png)"';
                couponsText = "已领取";
            }
            var htmlContent = '<div class="activeContent">';
            htmlContent += '<img src="img/gray3.png" alt="" class="activeLeftSide">';
            htmlContent += '<div class="activeContentDetail">';
            if (json.coupons[0].minAmount===0) {
                htmlContent += '<div class="activeContentText"><div class="activeText"><span>¥<i style="font-size:0.9rem">' + json.coupons[0].money +'</i></span></div><b>现金券</b></div>';
            }else{
                htmlContent += '<div class="activeContentText">满<i>' + json.coupons[0].minAmount + '</i><br><b>减' + json.coupons[0].money + '</b></div>';
            }
            htmlContent += '<div class="activeContentButton" data-id="' + json.coupons[0].id + '"' + isObtainCoupon + '><span>' + couponsText + '</span></div>';
            htmlContent += '</div><img src="img/gray4.png" alt="" class="activeRightSide"></div>';
            $(".J_activeCouponsArea").html(htmlContent);
            $(".activeContentDetail").bind("click", function() {
                getplaymuic();
                _this = $(this).find(".activeContentButton");
                _this.addClass("received");
                ikanWebInterface.authorize(5019, '{"couponId":' + _this.data("id") + '}', 'returnCouponConfirm',8);
            })
            break;
        case 2:
            var couponsArr = [];
            var couponsTextArr = [];
            for (var i = 0; i < json.coupons.length; i++) {
                var isObtainCoupon = "",
                    couponsText = "立即领取";

                if (json.coupons[i].isObtainCoupon == 1) {
                    var num = i + 1;
                    isObtainCoupon = 'style="background-image:url(img/special2' + num + '.png)"';
                    couponsText = "已领取";
                }
                couponsArr.push(isObtainCoupon);
                couponsTextArr.push(couponsText);
                debug(couponsArr[0]);
            }
            var htmlContent = '<div class="activeContent">';
            htmlContent += '<img src="img/gray1.png" alt="" class="activeLeftSide2">';
            htmlContent += '<div class="activeContentDetail2">';
            if (json.coupons[0].minAmount===0) {
                htmlContent += '<div class="activeContentText2 text21"><div class="activeText2"><span>¥<i style="font-size:0.9rem">' + json.coupons[0].money +'</i></span></div><b>现金券</b></div>';
            }else{
                htmlContent += '<div class="activeContentText2 text21 ContentText2">满<i>' + json.coupons[0].minAmount + '</i><br><b>减' + json.coupons[0].money + '</b></div>';
            }
            htmlContent += '<div class="activeContentButton2 button21" data-id="' + json.coupons[0].id + '"' + couponsArr[0] + '><span>' + couponsTextArr[0] + '</span></div>';
            htmlContent += '</div>';
            htmlContent += '<div class="activeContentDetail2">';
            if (json.coupons[1].minAmount===0) {
                htmlContent += '<div class="activeContentText2 text22"><div class="activeText2"><span>¥<i style="font-size:0.9rem">' + json.coupons[1].money +'</i></span></div><b>现金券</b></div>';
            }else{
                htmlContent += '<div class="activeContentText2 text22 ContentText2"><span>满<i>' + json.coupons[1].minAmount + '</i></span><br/><b>减' + json.coupons[1].money + '</b></p></div>';
            }
            htmlContent += '<div class="activeContentButton2 button22"  data-id="' + json.coupons[1].id + '"' + couponsArr[1] + '><span>' + couponsTextArr[1] + '</span></div></div>';
            htmlContent += '<img src="img/gray2.png" alt="" class="activeRightSide2"></div>';
            $(".J_activeCouponsArea").html(htmlContent);
            $(".activeContentDetail2").bind("click", function() {
                getplaymuic();
                $(this).children(".activeContentButton2").addClass("received");
                ikanWebInterface.authorize(5019, '{"couponId":' + $(this).children(".activeContentButton2").data("id") + '}', 'returnCouponConfirm',8);
            });
            break;
        case 3:
            var couponsArr = [];
            var couponsTextArr = [];
            for (var i = 0; i < json.coupons.length; i++) {
                var isObtainCoupon = "",
                    couponsText = "立即领取";
                if (json.coupons[i].isObtainCoupon == 1) {
                    $(".activeContentDetail3").unbind("click")
                    isObtainCoupon = 'style="background-image:url(img/special3' + i + '.png)"';
                    couponsText = "已领取";
                }
                couponsArr.push(isObtainCoupon);
                couponsTextArr.push(couponsText);
            }
            var htmlContent = '<div class="activeContent">';
            htmlContent += '<div class="activeContentDetail3">';
            if (json.coupons[0].minAmount===0) {
                htmlContent += '<div class="activeContentText3 text31"><div class="activeText2"><span>¥<i style="font-size:0.9rem">' + json.coupons[0].money +'</i></span></div><b>现金券</b></div>';
            }else{
                htmlContent += '<div class="activeContentText3 text31 ContentText2"><span>满<i>' + json.coupons[0].minAmount + '</i></span><br/><b>减' + json.coupons[0].money + '</b></p></div>';
            }
            htmlContent += '<div class="activeContentButton3 button31" data-id="' + json.coupons[0].id + '"' + couponsArr[0] + '><span>' + couponsTextArr[0] + '</span></div></div>';
            htmlContent += '<div class="activeContentDetail3">';
            if (json.coupons[1].minAmount===0) {
                htmlContent += '<div class="activeContentText3 text32"><div class="activeText2"><span>¥<i style="font-size:0.9rem">' + json.coupons[1].money +'</i></span></div><b>现金券</b></div>';
            }else{
                htmlContent += '<div class="activeContentText3 text32 ContentText2"><span>满<i>' + json.coupons[1].minAmount + '</i></span><br/><b>减' + json.coupons[1].money + '</b></p></div>';
            }
            htmlContent += '<div class="activeContentButton3 button32"  data-id="' + json.coupons[1].id + '"' + couponsArr[1] + '><span>' + couponsTextArr[1] + '</span></div></div>';
            htmlContent += '<div class="activeContentDetail3">';
            if (json.coupons[2].minAmount===0) {
                htmlContent += '<div class="activeContentText3 text33"><div class="activeText2"><span>¥<i style="font-size:0.9rem">' + json.coupons[2].money +'</i></span></div><b>现金券</b></div>';
            }else{
                htmlContent += '<div class="activeContentText3 text33 ContentText2"><span>满<i>' + json.coupons[2].minAmount + '</i></span><br/><b>减' + json.coupons[2].money + '</b></p></div>';
            }
            htmlContent += '<div class="activeContentButton3 button33"  data-id="' + json.coupons[2].id + '"' + couponsArr[2] + '><span>' + couponsTextArr[2] + '</span></div>';
            htmlContent += '</div></div>';
            $(".J_activeCouponsArea").html(htmlContent);
            $(".activeContentDetail3").bind("click", function() {
                getplaymuic();
                $(this).children(".activeContentButton3").addClass("received");
                ikanWebInterface.authorize(5019, '{"couponId":' + $(this).children(".activeContentButton3").data("id") + '}', 'returnCouponConfirm',8);
            });
            break;
    }
    // var textHeight = 0.75 / 16 * $(window).width(),
    //     dataHeight = $(".activeInstructions").height();
    // if (dataHeight >= textHeight) {
    //     // $(".SpecialPerformanceButton").show();
    //     $(".activeInstructions").height(textHeight).addClass("content-long-to-dotted");
    // }
    // $(".SpecialPerformanceContent").click(function() {
    //     if (performanceBut) {
    //         $(".activeInstructions").removeClass("content-long-to-dotted").height(dataHeight);
    //         $(this).find("img").removeClass("performanceBatUnselect").addClass("performanceButtonSelect");
    //         performanceBut = false;
    //         return;
    //     }
    //     $(".activeInstructions").height(textHeight);
    //     setTimeout(function() {
    //         $(".activeInstructions").addClass("content-long-to-dotted");
    //     }, 200)
    //     $(this).find("img").removeClass("performanceButtonSelect").addClass("performanceBatUnselect");
    //     performanceBut = true;
    // });
    productLoad(json);
    function callBack(pageIndex) {
        var jsonString = '{"pageSize":12,"page":' + pageIndex + ',"ebSpecialId":' + ebSpecialId + '}';
        ikanWebInterface.command(5022, jsonString, "productLoad",8);
    }
    loadImage("scrollContent", callBack);
    setTimeout(function() {
        $(".box").hide();
        $(".scrollContent").animate({
            opacity: 1
        }, 300);
    }, 500);
    $(".SpecialPerformanceButton").on("click", function() {
        getplaymuic();
        var num=json.shareUrl.length;
        num=135-num/2;
        var shareurl = json.specialImage;
        var shareTitle = specialName;
        if (description.length > 0) {
            var shareContent =description.length>num? description.substring(0, num) + '···':description;
        } else {
            var shareContent=specialName;
        }
        debug(shareurl+"@"+shareTitle+"@"+shareContent+"@"+json.shareUrl)
        ikanWebInterface.share(shareurl, shareTitle, shareContent, json.shareUrl,8);
    });
}
function startDateSplite(data){
    if(data.indexOf(".")>-1){
        var startDateTimesOne = data.split(".");
    }else{
        var startDateTimesOne = data.split("-");
    }
    y=startDateTimesOne[0];
    m = startDateTimesOne[1];
    var startDateTimesTwo = startDateTimesOne[2].split(" ");
    d = startDateTimesTwo[0];
    var startDateTimesThree=startDateTimesTwo[1].split(":");
    h=startDateTimesThree[0];
    s=startDateTimesThree[1];
    var startDateTime = y+'年'+m+'月'+d+'日'+' '+startDateTimesTwo[1];
    return startDateTime;
}
function ShowCountDown(year,month,day,hour,minute,divname){
        var now = new Date();
        var endDate = new Date(year, month-1, day,hour,minute);
        var leftTime=endDate.getTime()-now.getTime();
        leftsecond = parseInt(leftTime/1000);
        var htmls = document.getElementById(divname);
        if (leftsecond<=0) {
            htmls.innerHTML = '<span>0</span><span>0</span><span>0</span><p>天</p><span>0</span><span>0</span><p>时</p><span>0</span><span>0</span><p>分</p><span>0</span><span>0</span><p>秒</p>';
            return;
        };
        var day1=Math.floor(leftsecond/(60*60*24));
        var hour=Math.floor((leftsecond-day1*24*60*60)/3600);
        var minute=Math.floor((leftsecond-day1*24*60*60-hour*3600)/60);
        var second=Math.floor(leftsecond-day1*24*60*60-hour*3600-minute*60);
         day1=day1<1?"000":day1<10?'00'+day1:day1<100?"0"+day1:day1;
        hour=hour<10?'0'+hour:hour;
        minute=minute<10?'0'+minute:minute;
        second=second<10?'0'+second:second;
        day1=day1.toString();
        hour=hour.toString();
        minute=minute.toString();
        second=second.toString();
        htmls.innerHTML = '<span>'+day1.substring(0,1)+'</span>'+'<span>'+day1.substring(1,2)+'</span>'+'<span>'+day1.substring(2,3)+'</span>'+"<p>天</p>"+'<span>'+hour.substring(0,1)+'</span>'+'<span>'+hour.substring(1,2)+'</span>'+"<p>时</p>"+'<span>'+minute.substring(0,1)+'</span>'+'<span>'+minute.substring(1,2)+'</span>'+"<p>分</p>"+'<span>'+second.substring(0,1)+'</span>'+'<span>'+second.substring(1,2)+'</span>'+"<p>秒</p>";
}
function returnCouponConfirm(jsonString) {
    jsonString = typeof(jsonString) == "string" ? JSON.parse(jsonString) : jsonString;
    if (jsonString.status && jsonString.status == 9 ) {
        if (jsonString.err=="取消登录") return;
        $(".received").removeClass("received");
        return confirm(jsonString.err, ["确定"]); 
    }
    confirm(jsonString.msg);
    if(jsonString.msg == "领取成功") $(".received").css({
        backgroundImage: "url(img/special" + $("[class^='activeContentButton']").length + "" + ($(".received").parent().index()) + ".png)"
    }).removeClass("received").find("span").text("已领取");

}
var ebSpecialId;
ikanWebInterface.isShoppingCartAdd();
function returnShoppingCartAdd(isShoppingCart) {
    if (isShoppingCart === "true") return $(".J_shoppingCart").css({
        "background": "url(img/shopingcart1.png) no-repeat center",
        "background-size": "40px"
    });
    $(".J_shoppingCart").css({
        "background": "url(img/shopingcart.png) no-repeat center",
        "background-size": "40px"
    });
}
var back=function(){
    getplaymuic();
    ikanWebInterface.back();
};
var shopcartFunc=function() { //逻辑todo购物车
    this.src = "img/shopingcart1s.png";
    ikanWebInterface.startIkanScheme('ikan://shoppingcart/',' ',8);
};
function headerClickFunc(){
    var headerOptions={
        ".J_backButton":back,
        ".J_shoppingCart":shopcartFunc,
        ".callTopIcon":callTopFunc
    };
    return headerOptions;
}
function shoppingAddReturn(status){
    status = typeof(status) == "string" ? JSON.parse(status) : status;
    if(status.result){
        confirm("加车成功");
        $(".J_shoppingCart").css({
            "background": "url(img/shopingcart1.png) no-repeat center",
            "background-size": "40px"
        });
    }
    else confirm(status.msg);
}
var leftsecond;
$(function() {
    // init(jsonString);
    ikanWebInterface.docReady('');
    $(".J_backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".J_shoppingCart").touchdown(function() {
        $(this).css({
            "background": "url(img/shopingcartd.png) no-repeat center",
            "background-size": 40
        });
    }, function() {
        $(this).css({
            "background": "url(img/shopingcart.png) no-repeat center",
            "background-size": 40
        });
    });
    $(".J_backButton").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
    });
    $(".J_shoppingCart").fix("click", function() { //逻辑todo购物车
        if(androidVersionNum==0||androidVersionNum>=440)shopcartFunc.apply(this);
    }, {
        "commOnce": true
    });
})
 $(document).fix("click", ".shopAdd", function() {
    var skuArr=$(this).data("sku").split(",");
    if(skuArr.length>1) ikanWebInterface.productAddShoppingCart($(this).parent().parent().data("product"),8);
    else ikanWebInterface.shoppingAdd(skuArr[0],8);
}, {
    "commOnce": true
});
$(document).not(".shopAdd").fix("click", ".productDetail", function() {
    if (!clickUsed && !lazyLoad.parentFixed(event)) return;
    ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"),' ',8);
}, {
    "commOnce": true
});
var loadBottomHtml = $("#loadBottom").html();
function productLoad(data) {
    var productArr = [];
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5022, jsonString, "productLoad",8);
        });
        return;
    }
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    data = data.ebProductList;
    if (data.length) {
        if (data.length < pageSize) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".300x300");
            var index = initSize+pageIndex * pageSize + index;
            if (pageIndex > 0) {
                index = "productDetail" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return index = initSize+pageIndex * pageSize + index;
        });
        Handlebars.registerHelper("priceChange", function(price) {
            return parseFloat(price).toFixed(2);
        });
        Handlebars.registerHelper("skuChange", function(sku) {
            return sku.join(",");
        });
        Handlebars.registerHelper("stockoutTest", function(storageStatus, stockoutImageShow) {
                if (storageStatus == 0) {
                    return stockoutImageShow;
                } else {
                    return "";
                }
        });
        Handlebars.registerHelper("shopAddTest", function(storageStatus) {
                if (storageStatus == 0) {
                    return "display:none";
                } else {
                    return "";
                }
        });
        Handlebars.registerHelper("fontChange", function(storageStatus, stockoutFont) {
                if (storageStatus == 0) {
                    return stockoutFont;
                } else {
                    return "";
                }
        });
        $('.productArea').append(myTemplate(data));
        if (pageIndex > 0) {
            for (var i = 0; i < productArr.length; i++) {
                ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
            }
        }

    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}