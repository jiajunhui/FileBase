function insit(json) {
    // try{
    // 	initTest(json)
    // }
    // catch(e){
    // 		document.write(e.name);
    // 		document.write(e.number);
    // 		document.write(e.description);
    // 		document.write(e.message);
    // 		document.write(json)
    // }
    setTimeout(function() {
        initTest(json);
    }, 100);
}
jsonString = '{"brands":[{"brandName":"LEGO乐高","brandId":14},{"brandName":"Fisher-Price费雪","brandId":12},{"brandName":"Barbie芭比娃娃","brandId":22},{"brandName":"THOMAS&FRIENDS托马斯","brandId":21},{"brandName":"Transformers变形金刚","brandId":25},{"brandName":"木玩世家","brandId":26},{"brandName":"贝恩施","brandId":47},{"brandName":"澳贝","brandId":39},{"brandName":"优彼","brandId":43},{"brandName":"Hape","brandId":50},{"brandName":"Disney迪士尼","brandId":10},{"brandName":"培培乐","brandId":4},{"brandName":"喜羊羊与灰太狼","brandId":41},{"brandName":"HelloKitty","brandId":7},{"brandName":"Silverlit银辉","brandId":19},{"brandName":"RobocarPoli","brandId":20},{"brandName":"Schleich思乐","brandId":24},{"brandName":"Siku","brandId":23},{"brandName":"BRIO","brandId":29},{"brandName":"凯佩珑","brandId":33},{"brandName":"索凡","brandId":32},{"brandName":"Zoobies如比","brandId":6},{"brandName":"小马宝莉","brandId":44},{"brandName":"熊出没","brandId":15},{"brandName":"Pororo&Friends波乐乐","brandId":9},{"brandName":"NERF（热火）","brandId":45},{"brandName":"Colorato卡乐淘","brandId":5},{"brandName":"爱可丽","brandId":31},{"brandName":"KOKADO高佳多","brandId":30},{"brandName":"米米智玩","brandId":27},{"brandName":"DreamWorks梦工厂","brandId":18},{"brandName":"SpongeBob海绵宝宝","brandId":17},{"brandName":"英德","brandId":16},{"brandName":"富尔达","brandId":8},{"brandName":"Masterkidz贝思德","brandId":36}]}';
function init(json) {
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if (json.status && json.status == 10) {
        $(".box").hide();
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    data = json.brands;
    for (var htmls = "", i = 0; i < data.length; i++) {
        var brandLogo = typeof data[i].brandLogo !== "undefined" ? data[i].brandLogo : "";
        htmls += '<figure class="branderareas" data-id=' + data[i].brandId + '><div class="branderarea"><img src="" class="unload" id="brand' + i + '" data-image=' + ImageUrl(brandLogo, ".213x100") + ' alt=""></div><p class="content-long-to-dotted">' + data[i].brandName + '</p></figure>';
    }
    $(".brandercons").html(htmls);
    loadImage("scrollContent");
    $("figure").fix("click", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this);
        var schemeContent = 'ikan://web/ikan_toyList.html#{"command":"5075","params":{"searchKey":"","filterInfo":{"brandId":' + $(this).data("id") + '},"brandId":' + $(this).data("id") + ',"page":0,"pageSize":12}}';
        ikanWebInterface.startIkanScheme(schemeContent,' ',54);
    }, {
        "commOnce": true
    });
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    }, 300);
}
$(function() {
    // init(jsonString);	
    ikanWebInterface.docReady('');
    $(".backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".backButton").click(function() {
        getplaymuic();
        ikanWebInterface.back(); //安卓
    });
});