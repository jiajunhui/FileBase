function init(json) {
    try {
        // console.log(json)
        // $(".box").css("display":"-webkit-box");
        // setTimeout(function() {
            // document.write(json)
            initTest(json);
        // }, 100);
    } catch (e) {
        // $(".box").hide();
        // confirm("数据错误");
            // document.write(e.name);
            // document.write(e.number);
            // document.write(e.description);
            // document.write(e.message);
    }
    // setTimeout(function(){
    //     initTest(json);
    // },100)  
}
var reloadPage = 0;
var hotKeysBox=[];
var indexmark="index";
function initTest(json) {
    hotKeysJson={};
    reloadPage++;
    var BOX = '<div class="refreshBox"><div class="refreshImageBox"><img src="img/loading.png" alt="" class="refreshImage"></div><p class="refreshText">下拉刷新</p></div><div class="callTopButton"><img src="img/top.png" class="callTopIcon"></div>';
    var HTML = '<div class="bannerArea"><div class="swiper-container"><div class="swiper-wrapper bannerWrapper"></div><div class="swiper-pagination"></div></div></div><section class="specialActiveArea"></section><div class="marginTop2"></div><section class="postArea"><div class="bigPostArea"><div class="bigPostText"><p></p><p></p></div><div class="bigPostImage"><img  alt="" class="unload" id="bigPostImage"></div></div><div class="smallPostBox"><div class="smallPostArea"><div class="smallPostText"><p></p><p></p></div><div class="smallPostImage"><img  alt="" class="unload" id="smallPostImage1"></div></div><div class="smallPostArea"><div class="smallPostText"><p></p><p></p></div><div class="smallPostImage"><img  alt="" class="unload" id="smallPostImage2"></div></div></div></section><div class="marginTop2"></div><section class="videoRecommendArea"></section><section class="activeCart"><img  alt="" class="unload" id="bannerCart"></section><div class="marginTop"></div><section class="mangaArea"><div class="mangaTitle">热播动漫</div><div class="mangaContent"><div class="mangaScrollContent"></div></div></section><div class="marginTop1"></div><section class="productArea"><div class="mangaTitle">热卖益智玩具</div><div class="productDetailContent"></div></section><div id="loadBottom"><div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span></div>';
    var search='<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
    search.innerHTML = "";
    $(".bgShadow").html(search);
    var obj = $(".scrollContent");
    var obj1 = $(".callBox");
    $("*", obj).add([obj]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $("*", obj1).add([obj1]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $.event.remove(window);
    obj.innerHTML = "";
    $(".callBox").append(BOX);
    $(".scrollContent").prepend(HTML).show();
    initParam();
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if(json.albumHotKeys)hotKeysJson.albumHotKeys=json.albumHotKeys;
    if(json.productHotKeys)hotKeysJson.productHotKeys=json.productHotKeys;
    if(json.knowledgeHotKeys)hotKeysJson.knowledgeHotKeys=json.knowledgeHotKeys;
    if(json.recommendHotKeys)hotKeysJson.recommendHotKeys=json.recommendHotKeys;
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    if (json.status && json.status == 9) {
        $(".box").hide();
        return confirm(json.err, ["确定"]);
    }
    if (reloadPage > 0) {
        if (LastVideo !== false && LastVideo !== "null") {
            returnLastPlayRecord(LastVideo);
        }
    }
    // debug(json)
    var backBut = true,
        cartBat = true,
        performanceBut = true;
    if (json.products) {
        if (json.products.length % 2 !== 0) {
            json.products.pop();
        }
    }
    data1 = [{
        "imageUrl": "img/index/manuDetail4.png",
        "imageName": "热播动漫",
        "command": 5076,
        "url": "ikan_cartoonList"
    }, {
        "imageUrl": "img/index/manuDetail1.png",
        "imageName": "促销专场",
        "command": 5050,
        "url": "ikan_specialPerformanceList"
    }, {
        "imageUrl": "img/index/manuDetail2.png",
        "imageName": "精品文章",
        "command": 5051,
        "url": "ikan_specialSubjectList"
    }, {
        "imageUrl": "img/index/manuDetail3.png",
        "imageName": "精彩活动",
        "command": 5049,
        "url": "ikan_activityList"
    }]; //
    data5 = json.albums;
    data2 = json.recommends;
    data3 = json.navigations;
    data9 = json.hotKeys;
    try {
        if (typeof json.largePoster !== "undefined") {
            data6 = json.largePoster;
            $(".bigPostArea p").eq(0).html(slices(data6.postertitle, 10)); //标题
            $(".bigPostArea p").eq(1).html(slices(data6.postersubtitle, 6));
            $(".bigPostArea img").data("image", ImageUrl(data6.img, ".320x192")).data("id", data6.id).data("url", data6.url);
        }
        if (typeof json.seconedPosters !== "undefined") {
            data7 = json.seconedPosters;
            $(".smallPostText").eq(0).find("p").eq(0).html(slices(data7[0].postertitle, 4));
            $(".smallPostText").eq(0).find("p").eq(1).html(slices(data7[0].postersubtitle, 10));
            $(".smallPostText").eq(1).find("p").eq(0).html(slices(data7[1].postertitle, 4));
            $(".smallPostText").eq(1).find("p").eq(1).html(slices(data7[1].postersubtitle, 10));
            $(".smallPostArea").eq(0).data("id", data7[0].id);
            $(".smallPostArea").eq(1).data("id", data7[1].id);
            $(".smallPostArea").eq(0).find("img").data("image", ImageUrl(data7[0].img, ".214x150")).data("url", data7[0].url);
            $(".smallPostArea").eq(1).find("img").data("image", ImageUrl(data7[1].img, ".214x150")).data("url", data7[1].url);
        }
        if (typeof json.thirdPosters !== "undefined") {
            data4 = json.thirdPosters;
            for (var htmls = "", i = 0; i < 3; i++) {
                htmls += '<div class="videoRecommendDetail thirdPosterDetail" data-url=' + data4[i].url + ' data-id=' + data4[i].id + '><div class="videoRecommendText"><p>' + slices(data4[i].postertitle, 5) + '</p><p>' + slices(data4[i].postersubtitle, 6) + '</p></div><div class="imgbox"><img src="" class="unload"  data-image=' + ImageUrl(data4[i].img, ".134x124") + ' alt="" id="thirdPoster' + i + '"></div></div>';
            }
        }
        if (json.pushAlbum) {
            data8 = json.pushAlbum;
            // debug(data8)
            htmls += '<div class="videoRecommendDetail"><div class="videoContent" data-id=' + data8.id + '><img src="" data-image=' + ImageUrl(data8.snapshot, ".220x300") + ' alt="" class="unload videoContentImage" id="videoDetail4"><div class="watchMark">立即观看</div></div></div>';
            $(".videoRecommendArea").html(htmls);

        }
    } catch (e) {
    }
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".ManuButton").touchdown(function() {
        $(this).css({
            "background": "url(img/index/manu1a.png) no-repeat center",
            "backgroundSize":"32px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/index/manu1.png) no-repeat center",
            "backgroundSize":"32px"
        });
    });
    $(".cartButton").touchdown(function() {
        $(this).addClass("cartButtonGreen");
    }, function() {
        $(this).removeClass("cartButtonGreen");
    });
    for (var htmls = "", i = 0; i < data1.length; i++) {
        htmls += '<div class="activeManu" data-command=' + data1[i].command + ' data-url=' + data1[i].url + '><img src=' + data1[i].imageUrl + ' alt=""><br/><span>' + data1[i].imageName + '</span></div>';
    }
    // console.log(data1)
    $(".manuSlide").html(htmls);
    $(".activeManu").touchdown(function() {
        $(this).css({
            "background": "#f5f5f5"
        });
    }, function() {
        $(this).css({
            "background": "#ffffff"
        });
    });
    try {
        for (var htmls = "", i = 0; i < data2.length; i++) {
            htmls += '<div class="swiper-slide" data-id=' + data2[i].id + ' data-url=' + data2[i].redirect + '><img class="unload" data-image=' + ImageUrl(data2[i].img, ".640x240") + ' alt="" id="bannerIndex' + i + '"></div>';
        }
        jsonString=htmls;
        $(".bannerWrapper").html(htmls);
    } catch (e) {
        $(".bannerArea").css({
            overflow: "hidden",
            height: 0
        });
    }
    if (data3) {
        for (var htmls = "", i = 0; i < data3.length; i++) {
            htmls += '<div class="specialActiveManu" data-url=' + data3[i].url + ' data-id=' + data3[i].id + '><img id="specialActive'+i+'"  data-image="' + ImageUrl(data3[i].img, ".82x82") + '" alt="" class="unload"><br/>';
            if (data3[i].postertitle.length>5) {
                htmls += '<span>' + slices(data3[i].postertitle,5) + '</span></div>';
            }else{
                htmls += '<span>' + data3[i].postertitle + '</span></div>';
            }
            
        }
        $(".specialActiveArea").html(htmls);
    }
    if (data9) {
        for (var htmls = "", i = 0; i < data9.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+data9[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    if(data9 == null){ // box
        $(".hotKeys").hide()
        $(".hotText").hide()
    }
    if (json.banner) {
        $(".activeCart img").data("image", ImageUrl(json.banner.img, ".640x128")).data("id", json.banner.id).data("url", json.banner.url);
    } else {
        $(".activeCart").css("height", "0");
    }
    for (var htmls = "", i = 0; i < data5.length; i++) {
        if ((data5[i].nowCount == 0) || (typeof(data5[i].nowCount) == "undefined")) {
            var episodeDetail = data5[i].totalCount + "集全";
        } else {
            var episodeDetail = "更新至" + data5[i].nowCount + "集";
        }
        htmls += '<div class="mangaContentDetail swiper-slide" data-id=' + data5[i].id + '><div class="mangaContentDetailImage"><div class="defaultImage"><img  class="unload" alt="" data-image=' + ImageUrl(data5[i].snapshot, ".222x300") + ' id="mangaDetail' + i + '"></div></div><div class="mangaNameText"><p class="content-long-to-dotted">' + data5[i].name + '</p><p>' + episodeDetail + '</p></div>';
        if (data5[i].vip == true) {
            htmls += '<div class="VIPImg"><img src="img/vip.png"></div>';
        }
        htmls += '</div>';
    }
    $(".mangaScrollContent").html(htmls);
    //点击VIP
    //四个小图点击
    $(".specialActiveManu").unbind("click").fix("click", function() {
        if (swiper&&swiper.animating) return;
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = $(this).index()+1;
        var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "productLoad",2,'RECOMMEND_NAVIGATION_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',2,'RECOMMEND_NAVIGATION_'+num);
    }, {
        "commOnce": true
    });
   swiperInit();
var mangaRest=(androidVersionNum!==0&&androidVersionNum<440)?0.8/16:0;
var scrollWidth=$(window).width() * (5.8 / 16 * $(".mangaContentDetail").length-mangaRest);
        $(".mangaScrollContent").css({
            width: scrollWidth
        });
        var andoridTest=androidVersion.indexOf("4.4.2")>-1?false:true;
        // verticals = new IScroll(".mangaContent", {
        //     scrollX: true,
        //     scrollY: false,
        //     preventDefault: false,
        //     useTransition:andoridTest,
        //     click:true
        // });
    verticals = new IScroll(".mangaContent",  {useTransition:andoridTest,bounce:isIphone,bounceLock:true, vScroll:false,eventPassthrough: true, scrollX: true, scrollY: false, preventDefault: true});
    $(".mangaContent").on("touchend",function(){
        if(isIphone){
            if(-verticals.x>=scrollWidth-$(".mangaContent").width()){
                verticals.scrollTo($(".mangaContent").width()-scrollWidth,0,250,IScroll.utils.ease.elastic);
            }
        }
    })
    productLoad(json);
    $(".scrollContent").animate({
        opacity: 1
    }, 200);
    if (isIphone) {
        setTimeout(function() {
            $(".box").hide();
        }, 1200);
    }else{
        setTimeout(function() {
            $(".box").hide();
        }, 300);
    }
    
    function callPageLoad(pageIndex) {
        var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
        ikanWebInterface.command(5025, jsonString, "productLoad",2);
    }
    loadImage("scrollContent", callPageLoad);
        ikanWebInterface.getLastPlayRecord("2");
    lastPlayed = false;
    $(document).unbind("tap").fix("tap",".mangaContentDetail",function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',2);
    }, {
        "commOnce": true
    });
    $(".activeCart img").unbind("click").fix("click", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "productLoad",2,'RECOMMEND_BANNER_1');
        ikanWebInterface.startIkanScheme(schemeUrl,' ',2,'RECOMMEND_BANNER_1');
    }, {
        "commOnce": true
    });
    if (!isIphone) {
        ikanWebInterface.updateSearchState("0",false);
    }
}
var jsonString = '{"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"albums":[{"totalNumber":0,"nowCount":0,"specialType":0,"name":"巴啦啦小魔仙之奇迹舞步","id":262,"type":0,"vip":true,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/86380b73-c15b-4e8f-9d6f-6cbea272f752.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"巴啦啦小魔仙之彩虹心石","id":3,"type":0,"vip":false,"totalCount":36,"snapshot":"http://webimg.ikan.cn/test/ximages/album/f1f5e39b-6eaa-4ca3-8c75-2be02742a380.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"七巧板","id":261,"type":3,"vip":false,"totalCount":134,"snapshot":"http://webimg.ikan.cn/test/ximages/album/b84950e3-b751-4313-8827-2a5ccd94f3f3.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"蓝猫淘气3000问 星际大战","id":402,"type":0,"vip":false,"totalCount":384,"snapshot":"http://webimg.ikan.cn/test/ximages/album/3fe7337f-77d2-44f7-b928-5695febcae44.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"战斗王之飓风战魂Ⅱ发干的人个个梵蒂冈梵蒂冈地方干豆腐的风格大方认个梵蒂冈电饭锅电饭锅","id":376,"type":0,"vip":false,"totalCount":40,"snapshot":"http://webimg.ikan.cn/test/ximages/album/ab9c6014-eb23-4642-8abb-e333e3309c62.png"},{"totalNumber":0,"nowCount":120,"specialType":0,"name":"海绵宝宝","id":164,"type":0,"vip":false,"totalCount":120,"snapshot":"http://webimg.ikan.cn/test/ximages/album/9365aec8-acfc-404d-aac4-c9c066a68632.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"小马宝莉","id":467,"type":0,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"铠甲勇士","id":8,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/c5dfca0d-2711-4aaa-886d-1e051ea57d59.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"草原豆思之夺宝奇兵","id":404,"type":0,"vip":false,"totalCount":30,"snapshot":"http://webimg.ikan.cn/test/ximages/album/4caa5551-6393-4a5a-bc1f-482e4a2969b4.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"电击小子","id":5,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/cb650e2c-0c7b-4460-abc8-471ddb10d847.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"铁甲威虫","id":279,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/95880362-4385-4623-a930-e24e12678120.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"果宝特攻","id":6,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/3074904d-5db5-4ca8-99ca-c7e20e29086b.png"}],"thirdPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/2a779289-b9ae-4299-921a-144ae3b224fe.png","postertitle":"爱看VIP","description":"","sortNum":90,"id":120,"type":0,"postersubtitle":"兑换专区","url":"http://entrance.ikan.cn/act/vipRechange/vipRecharge.html"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/d9fa3bd1-41cb-48f1-bb6f-44a5d47a2d23.png","postertitle":"乐高积木","description":"","sortNum":91,"id":124,"type":0,"postersubtitle":"动手动脑","url":"ikan://product/3001107"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/1f89270f-6374-4d6a-ae71-949847cdd08f.png","postertitle":"朵拉玩具","description":"","sortNum":93,"id":123,"type":0,"postersubtitle":"带你去冒险","url":"ikan://product/3001107"}],"navigations":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/0322bf94-b2de-4ddd-946c-2130a06c1fd7.png","postertitle":"育儿推荐","description":"","sortNum":54,"id":136,"type":0,"postersubtitle":"","url":"ikan://web/ikan_specialSubject.html#{command:5060,params:{topicId:16}}"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/2fb5cd9a-c895-4838-94ed-463059f86d25.png","postertitle":"VIP权益更换花功夫呀","description":"","sortNum":67,"id":139,"type":0,"postersubtitle":"","url":"http://entrance.ikan.cn/act/vipRechange/vipRecharge.html"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/c069c404-5b53-4044-b75d-36ee54da667e.jpg","postertitle":"爆品推荐","description":"","sortNum":74,"id":133,"type":0,"postersubtitle":"","url":"ikan://product/2003016"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/4299e9c0-2bae-4833-959c-5c25f977cb5c.png","postertitle":"玩具评测","description":"","sortNum":75,"id":135,"type":0,"postersubtitle":"","url":"ikan://web/ikan_specialSubject.html#{command:5060,params:{topicId:15}}"}],"largePoster":{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/7ab7ca3f-5dd8-4a6c-89c6-26ca8dc4a3d6.jpg","postertitle":"男孩车神梦","description":"","sortNum":72,"id":137,"type":0,"postersubtitle":"银辉超跑驾临","url":"ikan://web/ikan_specialSubject.html#{command:5060,params:{topicId:23}}"},"banner":{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/6a89e6be-4615-41d0-8c7c-391cb30879c7.png","postertitle":"VIP福利波","description":"","sortNum":83,"id":192,"type":0,"postersubtitle":"火爆抢购ing","url":""},"productHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"seconedPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/b5bd9a7e-22d1-4821-afc6-678210e785f8.png","postertitle":"洪恩英语","description":"","sortNum":53,"id":147,"type":0,"postersubtitle":"跟洪恩一起学英语~","url":"ikan://album/544"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/ea6a4c19-a2fb-4511-a23b-f122d9b2b52e.png","postertitle":"宝狄星战","description":"","sortNum":55,"id":148,"type":0,"postersubtitle":"跟宝狄一起去历险~","url":"ikan://album/403"}],"banners":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/6a89e6be-4615-41d0-8c7c-391cb30879c7.png","postertitle":"VIP福利波","description":"","sortNum":83,"id":192,"type":0,"postersubtitle":"火爆抢购ing","url":""}],"products":[{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/49784690-8ab5-4898-86a5-56bac17f4735.jpg","totalNumber":0,"productCode":1004006,"price":19.9,"vprice":15,"sortNum":0,"storageStatus":1,"productName":"奥迪双钻 火力少年王5悠悠球 赤焰战虎（基础入门）","svprice":15,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/74bb6aaa-ccf4-40a9-b997-7f12da84420f.jpg","totalNumber":0,"productCode":3001230,"price":349,"vprice":265,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 水上飞机追击（5-12岁）","svprice":240,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/96c968c8-b411-4d01-b1d9-571980c64d06.jpg","totalNumber":0,"productCode":6480001,"price":0.01,"vprice":0.01,"sortNum":0,"storageStatus":1,"productName":"黑猫警长系列动画 手办第一弹 一只耳","svprice":0.01,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/05fb6e8a-fca3-4e55-8c24-1bd4bccd8995.jpg","totalNumber":0,"productCode":2001036,"price":169,"vprice":115,"sortNum":0,"storageStatus":1,"productName":"托马斯 朋友系列 查理和采石场套装","svprice":103,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/a54ff22e-654b-45b2-b68a-1b65f89aec66.jpg","totalNumber":0,"productCode":6314009,"price":69,"vprice":52,"sortNum":0,"storageStatus":1,"productName":"NERF（热火） 精英系列 凌鹰发射器（8岁+）","svprice":48,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/90f84ac9-0e7c-4157-9c8a-97b19f46966e.jpg","totalNumber":0,"productCode":2001005,"price":29,"vprice":20,"sortNum":0,"storageStatus":1,"productName":"托马斯 电动系列 合金小火车","svprice":20,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/0c14c734-3320-407d-8e09-e7067fb30026.jpg","totalNumber":0,"productCode":3001158,"price":249,"vprice":189,"sortNum":0,"storageStatus":1,"productName":"乐高 得宝系列 我的建筑套装（2-5岁）","svprice":175,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/e3964afc-aa1f-457f-8130-1872f85e2b49.jpg","totalNumber":0,"productCode":3001239,"price":399,"vprice":303,"sortNum":0,"storageStatus":1,"productName":"乐高 气功传奇系列 虎参谋的双面黑火战车（7-14岁）","svprice":272,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/1f09c5d7-16ba-4b55-862e-2f2cae5ad712.jpg","totalNumber":0,"productCode":3001209,"price":399,"vprice":303,"sortNum":0,"storageStatus":1,"productName":"乐高 气功传奇系列 鳄霸王的烈焰战车 （8-14岁） ","svprice":272,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/95c89e4b-d3dd-4353-991a-73d18239e989.jpg","totalNumber":0,"productCode":3001234,"price":799,"vprice":607,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 大型工程现场（6-12岁）","svprice":532,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/eecc8a86-6779-437f-aae4-75f51451e5c6.jpg","totalNumber":0,"productCode":2001042,"price":25,"vprice":21,"sortNum":0,"storageStatus":1,"productName":"托马斯 餐具智力学习筷 托马斯款 3-6岁","svprice":21,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/1ef17a2f-63c8-4162-b8fa-d325d03ac51c.jpg","totalNumber":0,"productCode":3001220,"price":2199,"vprice":1671,"sortNum":0,"storageStatus":1,"productName":"乐高玩具城市系列货运火车（6-12岁）","svprice":1442,"status":1}],"pushAlbum":{"totalNumber":0,"nowCount":0,"specialType":0,"name":"超兽武装之仁者无敌","id":4,"type":0,"vip":false,"totalCount":33,"snapshot":"http://webimg.ikan.cn/test/ximages/album/00b714a4-24da-4132-abb4-909e4ee8165b.png"},"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"hotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"recommends":[{"redirect":"ikan://web/ikan_specialPerformanceDetail.html#{command:5018,params:{ebSpecialId:27}}","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/dd6ab889-c394-42c2-a8c3-d7dbdcc544cf.jpg","id":1267,"sort":0},{"redirect":"ikan://web/ikan_specialPerformanceDetail.html#{command:5018,params:{ebSpecialId:33}}","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/de17490e-87a2-4741-b9a6-e997aa460d31.jpg","id":1297,"sort":1},{"redirect":"http://172.16.218.11/act/ikan_twoHoliday/ikan_twoHoliday.html","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/d5c51e80-b6cd-4ef4-a8a3-2f9bcbcad1d3.jpg","id":1270,"sort":2},{"redirect":"ikan://album/506","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/4f3df10d-d107-4bc0-9052-09f89d90bcf7.png","id":1247,"sort":4}],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉"]}';
    // jsonString='{"status":10}'
ikanWebInterface.isShoppingCartAdd();
function returnShoppingCartAdd(isShoppingCart) {
    if(!isIphone)swiperInit();
        touchClick=false;
    if (isShoppingCart === "true") return $(".cartMark").addClass("showMark").show();
    $(".cartMark").removeClass("showMark").hide();
}
var LastPlayUrl = false,
    lastPlayed = true,
    lastRunTime = 0,
    LastVideo = false;
function returnLastPlayRecord(LastPlay) {
    lastRunTime++;
    if (LastPlay === "null") {
        if(data8){
            LastPlay={};
            LastPlay.albumCover=data8.snapshot;
            LastPlay.albumId=data8.id;
            $(".watchMark").text("立即观看");
        }else{
            return;
        }
    }else{
        $(".watchMark").text("继续观看");
        LastPlay = JSON.parse(LastPlay);
    }
    var imgurl = ImageUrl(LastPlay.albumCover, ".220x300");
    $("#videoDetail4").removeClass("opacityAnimationLoad").data("image", imgurl);
    ikanWebInterface.asyncLoadImg(imgurl, "videoDetail4");
    $(".videoContent").data("id", LastPlay.albumId);
}
var oldTime=0;
var hotKeysJson={};
$(function() {
    // init(jsonString);
    ikanWebInterface.docReady('');
    $("body").on("touchstart",function(){
        oldTime=new Date().getTime();
    });
    $(document).on("click",".emptyHistory",function(){
        confirm("确认清空搜索历史记录？", ["确认", "取消"], function() {
                $(".searchVagaa").hide();
                hotKeysBox=[];
                window.localStorage.clear();
            }),
            function() {

            }
    }) 
    $(document).on("click",".hotKeys span",function(){
        if(swiper&&swiper.animating){
            swiper.animating=false;
            setTimeout(function(){swiper.slideNext();},300)
        }
        var hotKeys=$(this).text();
        $("#search").val(hotKeys);
        if ($(this).val()!==" ") {
            var newHotKeys=[];
            for(var j=0;j<hotKeysBox.length;j++){
                if (hotKeysBox[j]!==hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
            }
            newHotKeys.unshift(hotKeys);
            hotKeysBox=newHotKeys;
            setItem();
        }
        switch ($(".selectArea span").text()) {
            case '全部':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',2);
                break;
            case '动漫':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',2);
                break;
            case '玩具':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',2);
                 break;
            case '知识':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',2);
                break;
            default:
                break;
        }
        searchCancel();
    })
    $(document).fix("click",".bannerArea .swiper-slide", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = parseInt($(this).data("swiper-slide-index"))+1; 
        var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "productLoad",2,'RECOMMEND_IMAGE_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',2,'RECOMMEND_IMAGE_'+num);
    }, {
        "commOnce": true
    });
    $(document).fix("click", ".smallPostArea",function() {
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this).find("img");
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = $(this).index()+1;
        var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        console.log(jsonString)
        ikanWebInterface.command(5125, jsonString, "",2,'RECOMMEND_POSTER_SECOND_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',2,'RECOMMEND_POSTER_SECOND_'+num);
    }, {
        "commOnce": true
    });
    $(document).fix("click", ".bigPostArea", function() {
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this).find("img");
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var jsonString = '{"statisticsId":' + $(".bigPostImage img").data("id") + '}';
        console.log(jsonString)
        ikanWebInterface.command(5125, jsonString, "",2,'RECOMMEND_LARGE_POSTER');
        ikanWebInterface.startIkanScheme(schemeUrl,' ',2,'RECOMMEND_LARGE_POSTER');
    }, {
        "commOnce": true
    });
    $(document).fix("click",".thirdPosterDetail", function() {
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = $(this).index()+1;
        var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "",2,'RECOMMEND_POSTER_THIRD_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',2,'RECOMMEND_POSTER_THIRD_'+num);

    }, {
        "commOnce": true 
    });
    $(document).fix("click",".videoContent",function() {
        getplaymuic();
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        console.log('ikan://album/' + $(this).data("id"))
        var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
        ikanWebInterface.command(5125, jsonString, "",2);
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',2);
    }, {
        "commOnce": true 
    });
    $(document).on("click", ".activeManu", function() {
        if(androidVersionNum==0||androidVersionNum>=440)activeManuFunc.apply(this);
    });
    $(document).fix("click", ".productDetail", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var newTime=new Date().getTime();
        console.log('ikan://product/' + $(this).data("product"),' ',2)
        ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"),' ',2);
    }, {
        "commOnce": true
    });
});
var loadBottomHtml = '<div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span>';
function productLoad(data) {
    var productArr = [];
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5025, jsonString, "productLoad",2);
        });
        return;
    }
    if ($(".bgShadow").hasClass("shadowSlide"))return;
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    data = data.products;
    if (data.length % 2 !== 0) {
        data.pop();
    }
    if (data.length) {
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".300x300");
            var index = initSize+pageIndex * pageSize + index;
            if (pageIndex > 0) {
                index = "productDetail" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return index = initSize+pageIndex * pageSize + index;
        });
        Handlebars.registerHelper("priceChange", function(price) {
            return parseFloat(price).toFixed(2);
        });
        Handlebars.registerHelper("stockoutTest", function(storageStatus, stockoutImageShow) {
                if (storageStatus == 0) {
                    return stockoutImageShow;
                } else {
                    return "";
                }
        });
        Handlebars.registerHelper("grayTest", function(storageStatus, gray) {
                // if (storageStatus == 0) {
                //     return gray;
                // } else {
                //     return "";
                // }
        });
        Handlebars.registerHelper("fontChange", function(storageStatus, stockoutFont) {
                if (storageStatus == 0) {
                    return stockoutFont;
                } else {
                    return "";
                }
        });
        if (pageIndex == 0) {
            $('.productDetailContent').html(myTemplate(data));
        } else {
            $('.productDetailContent').append(myTemplate(data));
        }
        if (pageIndex > 0) {
            for (var i = 0; i < productArr.length; i++) {
                if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                    ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
                }
            }
        }
    } else {
        pageBottomFinish = false;
        $("#loadBottom").html("已经加载完成");
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}
// 搜索部分js逻辑
var txt=$(this).attr("placeholder");
function searchRuning(){
    return $(".cartButton").hasClass("cart_cancel");
}
function searchCancel() { //搜索完成或取消  callTop
    if (!isIphone) {
        ikanWebInterface.updateSearchState("0",false);
    }
    $(".bgShadow")[0].scrollTop = 0;
    eventPrevent = false;
    $(".alertDetail").removeClass("alertDetailSelect").eq(0).addClass("alertDetailSelect");
    $(".selectArea span").text("全部");
    $("#search").attr("placeholder","搜索动漫/玩具/知识");
    $("body")[0].scrollTop=currentScroll;
    $(".bgShadow").removeClass("shadowSlide");
    $(".alertArea").removeClass("block").hide();
    $(".ManuButton").removeClass("ManuLeave");
    $(".scrollContent").show();
    $(".label").css("margin-left", "0px");
    $(".cartButton").removeClass("cart_cancel");
    $(".selectArea").hide();
    $(".searchIcon").show();
    $(".manuSlide").hide();
    $(".box").hide();
    $("#search").val("");
    if ($(".cartMark").hasClass("showMark")) {
        $(".cartMark").show();
    }
    $(".callBox").show();
    if (!$(".callTopIcon").hasClass("topUp")) {
        $(".callTopButton").hide();
    }else{
        $(".callTopButton").show();
    };
    hotKeyFunc("recommendHotKeys");
    alertAreaOut();
}
function alertAreaOut() {
    $(".alertArea").removeClass("block").hide();
    swiper.animating=false;
    onceClick = false;
}
function backTop() {
    if (isIphone) {
        return $(".bgShadow")[0].scrollTop = 0;
    }
    document.body.scrollTop = 0;
}
function setItem(){
        var newHotKeysBox=hotKeysBox;
        newHotKeysBox=newHotKeysBox.join("&quot");
        localStorage.setItem("keys",newHotKeysBox);
}
var currentScroll=0;
var searchFunc=function() {
    var _this=this;
    currentScroll=$("body")[0].scrollTop;
    $(".scrollContent").hide();
    setTimeout(function(){
    getplaymuic();
    if (!isIphone) {
        ikanWebInterface.updateSearchState("0",true);
    }
    if(!$(".bgShadow").hasClass("shadowSlide")) setTimeout(function(){$(".bgShadow")[0].scrollTop = 0},100);
    $(".bgShadow").addClass("shadowSlide");
    $(".callBox").hide();
    var localhotKeys= window.localStorage;
    localhotKeys=localhotKeys.getItem("keys");
    if (!localhotKeys||localhotKeys.length==0) {
        $(".searchVagaa").hide();
        hotKeysBox=[];
    }else{
        $(".searchVagaa").show();
        localhotKeys=localhotKeys.split("&quot").splice(0,10);
        hotKeysBox=localhotKeys;
        for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+localhotKeys[i]+'</span>';
        }
        $(".vagaa").html(htmls);
    }
    $(".vagaa span").click(function(){
        if(swiper&&swiper.animating){
            swiper.animating=false;
            setTimeout(function(){swiper.slideNext();},300)
        }
        var hotKeys=$(this).text();
        var newHotKeys=[];
        hotKeysBox=localhotKeys;
            for(var j=0;j<hotKeysBox.length;j++){
                if (hotKeysBox[j]!==hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
        }
        newHotKeys.unshift(hotKeys);
        hotKeysBox=newHotKeys;
        setItem();
        switch ($(".selectArea span").text()) {
            case '全部':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',2);
                break;
            case '动漫':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',2);
                break;
            case '玩具':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',2);
                 break;
            case '知识':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',2);
                break;
            default:
                break;
        }
        searchCancel();
    });
    // $(_this).attr("placeholder","");
    $(".alertArea").removeClass("block").hide();
        if (!$(".ManuButton").hasClass("ManuLeave")) {
            $(".searchIcon").hide();
            $(".ManuButton").addClass("ManuLeave");
            $(".label").css("margin-left", "10px");
            $(".cartButton").addClass("cart_cancel");
            $(".manuSlide").hide();
            $(".selectArea").css({
                display: "-webkit-box"
            }).show();
            // $(".bgShadow").addClass("shadowSlide");
            $(".bgShadowBOX").hide();
            if ($(".cartMark").hasClass("showMark")) {
                $(".cartMark").hide();
            }
        }
    },200)
    // $("#search").focus();
    $("body").on("touchmove", function(){$("#search").blur()});
};
var activeManuFunc=function(){
    getplaymuic();
    $(this).css({
        "background": "#f5f5f5"
    });
    $(".manuSlide").removeClass("block").hide().children().css("background", "#fff");
    $(".activeManu").removeClass("manuActiveSelect");
    $(".bgShadowBOX").hide();
    eventPrevent = false;
    $(this).addClass("manuActiveSelect");
    var typeCommend = "";
    if ($(this).data("command") == "5076") typeCommend = ',"sortId":1';
    var schemeContent = 'ikan://web/' + $(this).data("url") + '.html#{"command":' + $(this).data("command") + ',"params":{"page":0,"pageSize":12' + typeCommend + ',"title":"' + $(this).find("span").html() + '"}}';
    console.log(schemeContent)
    ikanWebInterface.startIkanScheme(schemeContent,' ',2);
    $(this).removeClass("manuActiveSelect");
};
var manuFunc=function() {
    getplaymuic();
    if (!$(".manuSlide").hasClass("block")) {
        eventPrevent = true;
        $(".bgShadowBOX").show();
        $(".manuSlide").addClass("block").css("display", "-webkit-box");
        return;
    }
    eventPrevent = false;
    $(".manuSlide").removeClass("block").hide();
    $(".bgShadowBOX").hide();  
};
var shopcartFunc=function() { //逻辑todo购物车
            if ($(".cartButton").hasClass("cart_cancel")) {
                 return;
            }
            if($(".manuSlide").hasClass("block")){
                $(".manuSlide").removeClass("block").hide();
                $(".bgShadowBOX").hide()
                eventPrevent = false;
            }
            ikanWebInterface.startIkanScheme('ikan://shoppingcart/',' ',2);
};
var hotKeyFunc=function  (hotType) {
    if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
        $(".hotText,.hotKeys").show();
        var hotJson=hotKeysJson[hotType];
        for (var htmls = "", i = 0; i < hotJson.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    else{
        $(".hotText,.hotKeys").hide();
    }
}
var alertDetailFunc=function(){
    getplaymuic();
    $(".alertDetail").removeClass("alertDetailSelect");
    $(this).addClass("alertDetailSelect");
    var type = $(".selectArea span").text($(".alertDetailSelect").text());
    // alert(type.text())
    switch (type.text()) {
        case '全部':
            $("#search").attr("placeholder","搜索动漫/玩具/知识");
            hotKeyFunc("recommendHotKeys");
            break;
        case '动漫':
            $("#search").attr("placeholder","搜索动漫");
            hotKeyFunc("albumHotKeys");
            break;
        case '玩具':
            $("#search").attr("placeholder","搜索玩具");
            hotKeyFunc("productHotKeys");
             break;
        case '知识':
            $("#search").attr("placeholder","搜索知识");
            hotKeyFunc("knowledgeHotKeys");
            break;
        default:
            break;
    }
    alertAreaOut();
};
var bgShadowFunc=function(){
    getplaymuic();
    eventPrevent = false;
    $(this).hide();
    $(".manuSlide").removeClass("block").hide();
};
var selectAreaFunc=function(){
    getplaymuic();
    if (!$(".alertArea").hasClass("block")) {
        $(".alertArea").addClass("block").show();
        return;
    }
    $(".alertArea").removeClass("block").hide();
};
function headerClickFunc(){
    var headerOptions={
        "#search":searchFunc,
        ".ManuButton":manuFunc,
        ".cartButton":shopcartFunc,
        ".alertDetail":alertDetailFunc,
        ".selectArea":selectAreaFunc,
        ".callTopIcon":callTopFunc,
        ".activeManu":activeManuFunc,
        ".bgShadowBOX":bgShadowFunc,
        ".deleteIcon":searchFunc
    };
    return headerOptions;
}
//判断输入框是否为空格
var BlankSpace=true;
function checkBlankSpace(str){
    while(str.lastIndexOf(" ")>=0){
        str = str.replace(" ","");
    }
    if(str.length == 0){
        BlankSpace=false;
    }else{
        BlankSpace=true;
    }
}
!(function() {
    //搜索框点击事件动画
    $("#search,.deleteIcon").click(function(){
        if($(this).hasClass("deleteIcon")) $("#search").val("");
        if(androidVersionNum==0||androidVersionNum>=440)searchFunc.apply(this);
    });
    // $("#search").blur(function(){
    //         $(this).attr("placeholder","搜索动漫/玩具/知识");
    //     });
    $(".ManuButton").on("touchstart",function(){}).click(function(){
        if(androidVersionNum==0||androidVersionNum>=440)manuFunc.apply(this);
    });
    $(".bgShadowBOX").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)bgShadowFunc.apply(this);
    });
    //取消按钮点击事件
    $(document).on("click", ".cart_cancel", function() { 
        getplaymuic();
        reloadPage = false;
        if(typeof swiper=="object"){
            swiper.update();
            swiper.animating = false;
        }
        setTimeout(function(){
            searchCancel();
        },60)
    });
    $(".cartButton").fix("click",function() { //逻辑todo购物车
        if(androidVersionNum==0||androidVersionNum>=440)shopcartFunc.apply(this);
    }, {
        "commOnce": true
    });
    if(isIphone){
        $("#search").on("search", function(event) {
           onSearch();     
        });
    }
    else{
        $("#search").on("keydown", function(event) {
            if(event.keyCode==13){
                onSearch();     
            }
        });
    }
function onSearch (){
    if(swiper&&swiper.animating){
        swiper.animating=false;
        setTimeout(function(){swiper.slideNext();},300)
    }
    $("input").blur();
    var hotKeys=$("#search").val();
    hotKeys=hotKeys.replace(/\"/ig,"").replace(/\\/ig,"").replace(/\//ig,"");
    $("#search").val(hotKeys);
    checkBlankSpace(hotKeys);
    if (hotKeys!==" "&&BlankSpace==true) {
        var newHotKeys=[];
        for(var j=0;j<hotKeysBox.length;j++){
            if (hotKeysBox[j]!==hotKeys) {
                newHotKeys.push(hotKeysBox[j]);
            }
        }
        newHotKeys.unshift(hotKeys);
        hotKeysBox=newHotKeys;
        setItem();
    }
    // ikanWebInterface.startIkanScheme('http://172.16.218.42/Web_app/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}');
    console.log($(".selectArea span").text())
    switch ($(".selectArea span").text()) {
        case '全部':
            ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',2);
            break;
        case '动漫':
            ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',2);
            break;
        case '玩具':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',2);
             break;
        case '知识':
            ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',2);
            break;
        default:
            break;
    }
    searchCancel();
}
    //弹出菜单事件
    $(".selectArea").click(function() { 
        if(androidVersionNum==0||androidVersionNum>=440)selectAreaFunc.apply(this);
    });
    //弹出菜单的点击事件
    $(document).on("click", ".alertDetail", function() { 
        if(androidVersionNum==0||androidVersionNum>=440)alertDetailFunc.apply(this);
    });
})()