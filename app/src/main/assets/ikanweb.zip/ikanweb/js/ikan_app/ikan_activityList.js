function init(json) {
    // 	try{
    // 		initTest(json)
    // 	catch(e){
    // 			document.write(e.name);
    // 			document.write(e.number);
    // 			document.write(e.description);
    // 			document.write(e.message);
    // 			document.write(json)
    // 	}
    // }
    if (isIphone) {
        setTimeout(function() {
            initTest(json);

        }, 100)
    } else {
        initTest(json);

    }
}

function initTest(json) {
        var BOX = '<div class="refreshBox"><div class="refreshImageBox"><img src="img/loading.png" alt="" class="refreshImage"></div><p class="refreshText">下拉刷新</p></div><div class="callTopButton"><img src="img/top.png" class="callTopIcon"></div>';
        var HTML = '<div class="activity_lists"></div><div id="loadBottom"><div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span></div>';
        var obj = $(".scrollContent");
        var obj1 = $(".callBox")
        $("*", obj).add([obj]).each(function() {
            $.event.remove(this);
            $(this).empty();
        });
        $("*", obj1).add([obj1]).each(function() {
            $.event.remove(this);
            $(this).empty();
        });
        $.event.remove(window);
        obj.innerHTML = "";
        $(".callBox").append(BOX);
        $(".scrollContent").prepend(HTML);
        initParam()
        json = typeof(json) == "string" ? JSON.parse(json) : json;
        if (json.status && json.status == 10) {
            dead();
            $(".dead").unbind("click").on("click", function() {
                getplaymuic();
                ikanWebInterface.reloadPage();
                $(".box").show();
                $(".dead").hide();
            });
            return;
        }
        if (json.status && json.status == 9 || (json.activityList && json.activityList.length == 0)) {
            $(".box").hide();
            $(".scrollContent").css({
                opacity: 1
            });
            confirm("服务器异常")
            return;
        }
        $(".callTopIcon").touchdown(function(){
            $(this).attr("src","img/topTouch.png");
        },function(){
            $(this).attr("src","img/top.png");
        })
        var backBut = true,
            cartBat = true,
            performanceBut = true;
        activityLoad(json);
        $(".box").hide();
        $(".scrollContent").css({
            opacity: 1
        });

        function callPageLoad(pageIndex) {
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5049, jsonString, "activityLoad",6);
        }
        loadImage("scrollContent", callPageLoad); //分页函数调用
        // $(".box").hide();
    }
    // jsonString=[{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"0"
    // 	},
    // 		{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"1"
    // 	},
    // 	{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"1"
    // 	},
    // 	{
    // 		"imageUrl":"img/010.png",
    // 		"title":"蜡笔小新美食大战",
    // 		"time":"活动时间:2015年7月3日-2015年8月8日",
    // 		"type":"0"
    // 	}
    // ];

jsonString = '{"activityList":[{"activityId":94,"clientImg":"http://webimg.ikan.cn/ximages/act/activity/2f745ba0-3add-450d-8be4-d92bd0694fe2.jpg","isOver":false,"location":"全国","beginTime":"2015-05-18","endTime":"2016-02-06","terminal":"dbdf091ed3f68dc2","title":"蒙牛未来星活动","userId":10006197,"url":"http://www.ikan.cn/act/mobile/mengniu.html","via":"ACT"},{"activityId":92,"clientImg":"http://webimg.ikan.cn/ximages/act/activity/2ba6d755-f3bb-44a8-bd05-a3273a5a8f7c.jpg","isOver":false,"location":"quanguo","beginTime":"2014-10-17","endTime":"2015-11-01","terminal":"dbdf091ed3f68dc2","title":"参与\u201c每日一砸\u201d  赢取专属悠悠球","userId":10006197,"url":"http://www.ikan.cn/item/9013189.html","via":"ACT"},{"activityId":91,"clientImg":"http://webimg.ikan.cn/images/upload/client_activity_img/2014/20141023/1414059493236q1lh2.jpg","isOver":true,"location":"","beginTime":"2014-10-24","endTime":"2014-10-31","terminal":"dbdf091ed3f68dc2","title":"【参与活动】仅10元得国际专业儿童防霾口罩！","userId":10006197,"url":"","via":"ACT"},{"activityId":87,"clientImg":"http://webimg.ikan.cn/images/upload/client_activity_img/2014/20141010/1412939996180uydbh.jpg","isOver":true,"location":"","beginTime":"2014-10-12","endTime":"2014-10-31","terminal":"dbdf091ed3f68dc2","title":"晒《铠甲》票根，得玩具啦！","userId":10006197,"url":"","via":"ACT"},{"activityId":86,"clientImg":"http://webimg.ikan.cn/images/upload/client_activity_img/2014/20140927/1411814562205x9ebq.jpg","isOver":false,"location":"全国","beginTime":"2014-09-27","endTime":"2015-12-22","terminal":"dbdf091ed3f68dc2","title":"爱看十一放\u201c价\u201d啦 双款礼包大放送","userId":10006197,"url":"i","via":"ACT"},{"activityId":84,"clientImg":"http://webimg.ikan.cn/images/upload/client_activity_img/2014/20140923/1411473220323odseo.jpg","isOver":false,"location":"i","beginTime":"2014-09-19","endTime":"2016-08-14","terminal":"dbdf091ed3f68dc2","title":"爱看联手妈妈网低价开团 妈网用户专享","userId":10006197,"url":"i","via":"ACT"},{"activityId":83,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2014/20140404/xinlangleju1.jpg","isOver":true,"location":"","beginTime":"2014-09-05","endTime":"2014-09-28","terminal":"dbdf091ed3f68dc2","title":"爱看携手新浪乐居 积分玩具大兑换","userId":10006197,"url":"","via":"ACT"},{"activityId":78,"clientImg":"http://webimg.ikan.cn/images/upload/client_activity_img/2014/20140527/14011740121340qk69.jpg","isOver":true,"location":"","beginTime":"2014-04-07","endTime":"2014-08-31","terminal":"dbdf091ed3f68dc2","title":"北京卫视黄金档招募，快带孩子上电视吧！","userId":10006197,"url":"","via":"ACT"},{"activityId":77,"clientImg":"http://webimg.ikan.cn/images/upload/client_activity_img/2014/20140527/1401174000427qb5o4.jpg","isOver":true,"location":"爱看客户端","beginTime":"2014-05-29","endTime":"2014-06-04","terminal":"dbdf091ed3f68dc2","title":"双节童乐 好礼蛋生\u2014\u2014万元红包等你抢！","userId":10006197,"url":"","via":"ACT"},{"activityId":75,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2014/20140331/client_1396261426199t09v5.jpg","isOver":true,"location":"","beginTime":"2014-03-31","endTime":"2014-04-07","terminal":"dbdf091ed3f68dc2","title":"巴啦啦小魔仙\u2014魔法棒★魔法彩泥★免费送","userId":10006197,"url":"","via":"ACT"},{"activityId":74,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2014/20140327/client_1395900531986212tr.jpg","isOver":true,"location":"","beginTime":"2014-03-24","endTime":"2014-03-30","terminal":"dbdf091ed3f68dc2","title":"巴啦啦小魔仙精美礼品大放送","userId":10006197,"url":"","via":"ACT"},{"activityId":73,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2013/20130704/client_1372929044945q3il0.jpg","isOver":true,"location":"","beginTime":"2013-07-04","endTime":"2013-08-30","terminal":"dbdf091ed3f68dc2","title":"爱看暑期档\u2014动漫免费畅享","userId":10006197,"url":"","via":"ACT"},{"activityId":72,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2013/20130531/client_1369986852486i5jse.jpg","isOver":true,"location":"","beginTime":"2013-05-31","endTime":"2013-06-03","terminal":"dbdf091ed3f68dc2","title":"6．1儿童节 . 爱看送礼物","userId":10006197,"url":"","via":"ACT"},{"activityId":71,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2013/20130531/client_1369986544178fgqad.jpg","isOver":true,"location":"","beginTime":"2013-06-01","endTime":"2013-06-01","terminal":"dbdf091ed3f68dc2","title":"凭\u201c爱看动漫乐园\u201d客户端 畅游嘉佳奥迪哈乐会","userId":10006197,"url":"","via":"ACT"},{"activityId":69,"clientImg":"http://webimg.ikan.cn/images/upload/activity/2013/20130131/client_1359603205195rfjna.jpg","isOver":true,"location":"北京 远洋未来广场","beginTime":"2013-02-01","endTime":"2013-02-03","terminal":"dbdf091ed3f68dc2","title":"2月1日-3日远洋未来广场大型亲子活动","userId":10006197,"url":"","via":"ACT"}]}';
//var jsonString='{"aa":123,"bb":123}'
var hFiveImageRoad = true,
    loadIndex = 0;
var back=function(){
        getplaymuic();
        ikanWebInterface.back();
 };
 function headerClickFunc(){
        var headerOptions={
            ".backButton":back,
            ".callTopIcon":callTopFunc
        };
        return headerOptions;
    }

$(function() {

    $(".backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".backButton").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
    });
    // init(jsonString);	
    ikanWebInterface.docReady('');
    $(document).fix("click", ".activity", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        ikanWebInterface.startIkanScheme($(this).data("url"),' ',6);
    }, {
        "commOnce": true
    });
})
var loadBottomHtml = '<div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span>';

function activityLoad(data) {
    var productArr = [];
    loadIndex++;
    // if(data.activityList.length){
    // 	$("#loadBottom").html("已经加载完成");
    // 	return;
    // }
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5049, jsonString, "activityLoad",6);
        });
        return false;
    }
    data = data.activityList;
    if (data.length) {
        if (data.length < 12) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imageGrayTest", function(v1, v2,v3) {
            if (v1 == true) {
                if (v2 == "shadowBox" && isIphone) {
                    return "";
                }
                return v2;
            } else {
                return v3;
            };
        });
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".590x368");
            var index = loadIndex * 12 + index;
            if (loadIndex >= 1) {
                index = "productDetail" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return loadIndex * 12 + index;
        });
        if (pageIndex == 0) {
            $('.activity_lists').html(myTemplate(data));
        } else {
            $('.activity_lists').append(myTemplate(data));
        }
        if (loadIndex >= 1) {
            for (var i = 0; i < productArr.length; i++) {
                // debug(productArr[i][0] + productArr[i][1])
                // alert("1")
                ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}