var jsonString='{"result":true,"topiclist":[{"topicId":76,"createtime":"2016-02-19","subTitle":"啊啊啊啊啊啊啊啊啊啊啊啊啊","author":"爱看","isOver":true,"startTime":"2016-02-19","endTime":"2016-02-26","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊","url":"http://webimg.ikan.cn/test/ximages/eb/poster/7e14fbe3-7d4d-4b05-bce8-c8c4327a74ca.jpg","topicType":1},{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/b8b65179-9f80-4c81-b5c5-c8589eadfc8f.jpg","http://images.kandongman.com.cn/ximages/eb/poster/88ece4d3-1e2a-4dcc-9469-e023a86e811d.jpg","http://images.kandongman.com.cn/ximages/eb/poster/59943af8-71ad-4fb1-b647-3690849a531d.jpg","http://images.kandongman.com.cn/ximages/eb/poster/28b7ae92-16a9-456f-81b0-52afaec9a03b.jpg","http://images.kandongman.com.cn/ximages/eb/poster/402825ff-95fa-4791-a7da-4d284e65b0e8.jpg","http://images.kandongman.com.cn/ximages/eb/poster/3432dd42-1b56-46bc-ae00-839b9e477f72.jpg","http://images.kandongman.com.cn/ximages/eb/poster/26d2d949-35ca-4241-b73a-5ed154bc5c26.jpg","http://images.kandongman.com.cn/ximages/eb/poster/ebb83aff-a22b-454b-84bc-040e97c44d54.jpg","http://images.kandongman.com.cn/ximages/eb/poster/277fb795-5911-413f-b99e-3566d77f51b2.jpg","http://images.kandongman.com.cn/ximages/eb/poster/f26e08b7-c554-4032-bb01-e84743e49dfc.jpg"],"topicId":10,"createtime":"2015-09-18","subTitle":"荐适合儿童的动画片","author":"爱看儿童乐园","isOver":true,"startTime":"2015-09-18","endTime":"2015-10-18","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"全球十大经典3D动画片! 全球十大经典3D动画片! 全球十大经典3D动画片! ","url":"http://webimg.ikan.cn/test/ximages/eb/poster/9570aeba-f482-4d1c-91b0-91e4c43c8d38.jpg","topicType":2},{"topicId":75,"createtime":"2016-02-19","subTitle":"繁花锦盛的时节，最适合饮茶","author":"测试","isOver":true,"startTime":"2016-02-19","endTime":"2016-02-25","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"禅意诗情啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊","url":"http://webimg.ikan.cn/test/ximages/eb/poster/66678bfd-fb48-4a58-8f22-5ccb0a96ce02.jpg","topicType":2},{"topicId":73,"createtime":"2016-02-19","subTitle":"水母水母","author":"爱看","isOver":true,"startTime":"2016-02-19","endTime":"2016-02-22","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"水母","url":"http://webimg.ikan.cn/test/ximages/eb/poster/29f42d48-7088-4fa8-8c21-fea43580b270.jpg","topicType":1},{"topicId":68,"createtime":"2016-02-18","subTitle":"文章测试","author":"爱看","isOver":false,"startTime":"2016-02-15","endTime":"2016-03-30","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"文章测试","url":"http://webimg.ikan.cn/test/ximages/eb/poster/a0f7c725-413d-4ef3-819d-bde7f0df75d4.png","topicType":5},{"topicId":70,"createtime":"2016-02-18","subTitle":"才打开附件是打开飞机的","author":"发到发斯蒂芬斯蒂芬斯蒂芬","isOver":true,"startTime":"2016-02-17","endTime":"2016-02-18","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"侧时","url":"http://webimg.ikan.cn/test/ximages/eb/poster/ced7104f-2436-4ca8-9446-08c8bd7cc7c8.jpg","topicType":1},{"topicId":71,"createtime":"2016-02-19","subTitle":"范德萨发生的广告覆盖","author":"鼓捣鼓捣发光飞碟","isOver":true,"startTime":"2016-02-19","endTime":"2016-02-20","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"问地方第三方斯蒂芬斯蒂芬","url":"http://webimg.ikan.cn/test/ximages/eb/poster/67ab1347-7c01-4d71-9112-9bd318a0f546.jpg","topicType":1},{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/1ed3f878-2bf8-4e0d-b700-5dfeb094d1a2.jpg","http://images.kandongman.com.cn/ximages/eb/poster/bfff3c12-79d6-4ee9-9f08-0a15c7cb54a8.jpg","http://images.kandongman.com.cn/ximages/eb/poster/6b598326-3b29-4ebf-a190-e1568cab356f.jpg","http://images.kandongman.com.cn/ximages/eb/poster/810e099e-2f2c-4122-99ef-01e72d19e9b9.jpg","http://images.kandongman.com.cn/ximages/eb/poster/f3377937-7fea-4192-9d1a-2a9703ac6774.jpg","http://images.kandongman.com.cn/ximages/eb/poster/f2b15a34-cfdd-4a76-bc4f-6a30715c290b.jpg","http://images.kandongman.com.cn/ximages/eb/poster/a4f55ded-38f6-47c3-8136-d6dd236d9b00.jpg","http://images.kandongman.com.cn/ximages/eb/poster/1f10ac0a-854e-44ef-8a00-b12e7ede4778.jpg","http://images.kandongman.com.cn/ximages/eb/poster/c0e93342-b661-4fb5-ae50-ac952b80b16e.jpg","http://images.kandongman.com.cn/ximages/eb/poster/20e1dbda-d427-4e54-ae11-004643db7351.jpg","http://images.kandongman.com.cn/ximages/eb/poster/b81cada1-5edf-454f-9048-0a08606ea36d.jpg","http://images.kandongman.com.cn/ximages/eb/poster/0a6ab9bf-8246-4d8a-8d16-5b9e746198ab.jpg","http://images.kandongman.com.cn/ximages/eb/product/defa31e5-7355-482b-8f4e-da3ee6db8289.jpg"],"topicId":23,"createtime":"2015-11-30","subTitle":"震撼视听的玩具体验\u2014\u2014银辉超跑驾临","author":"爱看小编","isOver":false,"startTime":"2015-11-30","endTime":"2016-11-30","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"男孩车神梦：壕气冲天的超跑玩具","url":"http://webimg.ikan.cn/test/ximages/eb/poster/3bff2057-86af-45cd-a003-74fac534e873.jpg","topicType":1},{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/a466fccd-9c4b-416f-bd49-21a3da81ec3c.jpg","http://images.kandongman.com.cn/ximages/eb/poster/6fcd84a8-e9b6-4b05-9c9d-4b63620cb40e.jpg","http://images.kandongman.com.cn/ximages/eb/poster/d72b5652-0b89-40ef-9024-ba560a9343e9.jpg","http://images.kandongman.com.cn/ximages/eb/poster/958ffaaa-53ad-4d5f-9261-f3f3d3e93abd.jpg","http://images.kandongman.com.cn/ximages/eb/poster/a830bac0-af00-4832-800c-531cc9fbfec3.jpg","http://images.kandongman.com.cn/ximages/eb/poster/77626700-a112-4923-992c-57bdccb6f6c3.jpg"],"topicId":59,"createtime":"2015-12-31","subTitle":"一个敏感期，将使儿童获得一种品质。","author":"爱看小编","isOver":false,"startTime":"2015-12-31","endTime":"2016-12-31","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"宝宝为什么爱吃手?","url":"http://webimg.ikan.cn/test/ximages/eb/poster/889cb8e1-4cfe-44cf-823c-c9022b496840.jpg","topicType":3},{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/5dbe5548-65ab-4efb-8dc4-59bd2b0d3fba.png","http://images.kandongman.com.cn/ximages/eb/poster/6f443977-e00a-494a-8478-e5adf65110ad.png","http://images.kandongman.com.cn/ximages/eb/poster/ae04f8fe-601a-4ee1-9461-a3392ecc5bbd.png"],"topicId":62,"createtime":"2016-01-11","subTitle":"培养宝贝7秒钟的黄金注意力","author":"爱看","isOver":false,"startTime":"2016-01-04","endTime":"2017-05-02","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"宝贝看过来~","url":"http://webimg.ikan.cn/test/ximages/eb/poster/45deae64-409a-4032-a793-3e87ffa4e50c.png","topicType":2},{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/8340581b-eca1-419c-ab04-b07856a72055.jpg","http://images.kandongman.com.cn/ximages/eb/poster/e066a29f-c4d0-4794-a70b-a795e1951efd.jpg","http://images.kandongman.com.cn/ximages/eb/poster/2daf4704-ffd2-49ff-a4b7-baf39007bf65.jpg","http://images.kandongman.com.cn/ximages/eb/poster/ff8968cb-4ee0-46a0-8bce-2df3fe8e006a.jpg","http://images.kandongman.com.cn/ximages/eb/poster/4efbb666-f4f8-415f-afb0-700bac7411e3.jpg","http://images.kandongman.com.cn/ximages/eb/poster/bc6dbb76-b703-4c24-9340-6c87686e1ed3.jpg","http://images.kandongman.com.cn/ximages/eb/poster/dfbb16c3-7e3c-417a-a6af-59318952fe67.jpg"],"topicId":58,"createtime":"2015-12-30","subTitle":"逼孩子说\u201c对不起\u201d，可能不如教会孩子如何说\u201c谢谢\u201d更好","author":"爱看小编","isOver":false,"startTime":"2015-12-30","endTime":"2016-12-31","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"教会孩子如何说\u201c谢谢\u201d","url":"http://webimg.ikan.cn/test/ximages/eb/poster/7dce24f3-ae9b-49c8-a25a-4ded892989d4.jpg","topicType":3},{"topicImage":["http://images.kandongman.com.cn/ximages/eb/poster/20aa44c4-b986-42dc-8544-35a2d5d8ad4d.png","http://images.kandongman.com.cn/ximages/eb/poster/159a6922-d7ca-4d39-9582-1750f645f034.png","http://images.kandongman.com.cn/ximages/eb/poster/27d9ef63-4245-40d2-b465-3f16d0c87bf9.png","http://images.kandongman.com.cn/ximages/eb/poster/39a55f97-455d-4256-9d9e-b411ee633474.png"],"topicId":67,"createtime":"2016-01-18","subTitle":"培养孩子的生活好习惯！ ","author":"爱看","isOver":false,"startTime":"2015-12-28","endTime":"2018-03-25","shareurl":"http://m.ikan.cn/mobileAppAddress.action?from=14","title":"宝贝，要听话~","url":"http://webimg.ikan.cn/test/ximages/eb/poster/8240645a-7d4d-4b57-9c25-6ddcad7853f1.png","topicType":2}],"topicType":1}';
function init(json) {
    // try{
    // initTry(json);
    // }catch(e){
    //  document.write(e.name);
    //  document.write(e.number);
    //  document.write(e.description);
    //  document.write(e.message);
    //  document.write(json);
    // }
    setTimeout(function() {
        initTry(json);
    }, 100);
}
var topicType;
var flag;
function initTry(json) {
    var BOX = '<div class="callTopButton"><img src="img/top.png" class="callTopIcon"></div>';
    var HTML = '<div class="activity_lists"></div><div id="loadBottom"><div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span></div>';
    var obj = $(".scrollContent");
    var obj1 = $(".callBox");
    $("*", obj).add([obj]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $("*", obj1).add([obj1]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $.event.remove(window);
    obj.innerHTML = "";
    $(".callBox").append(BOX);
    $(".scrollContent").prepend(HTML);
    initParam();
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    console.log(json)
    // debug(json)
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    var backBut = true,
        cartBat = true,
        performanceBut = true;
    activityLoad(json);
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    }, 300);
    for(var i=0;i<$(".classification li").length;i++){
        if($(".classification li").eq(i).data("id") == json.topicType){
            $(".classification li").removeClass("classificationSelect");
            $(".classification li").eq(i).addClass("classificationSelect")
        }
    }
    var headerTitle = $(".classificationSelect").text();
    if (headerTitle !== "全部") {
         $("#headerTitle").html("精品文章-" + headerTitle);
    };
    if($(".classificationSelect").data("id"))
    function callPageLoad(pageIndex) {
        topicType = $(".classificationSelect").data("id");
        if (!topicType) {
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
        }else{
            var jsonString = '{"pageSize":12,"page":' + pageIndex + ',"topicType":'+topicType+'}';
        }
        console.log(jsonString)
        ikanWebInterface.command(5051, jsonString, "activityLoad",5);
    }
    loadImage("scrollContent", callPageLoad);
    // $(document).on("click","figure",function(){
    //      var bool=isIphone?"false":false;
    //      if(!clickUsed&&!lazyLoad.parentFixed(event))return;
    //  var schemeContent='http://172.16.218.42/Web_app/ikan_specialSubject.html#{"command":5060,"params":{"topicId":'+$(this).data("id")+'}}';
    //  ikanWebInterface.startIkanScheme(schemeContent,bool);
    // })
}
var flag = true;
// var iosScroll=true;
$(function() {
    // init(jsonString);
    ikanWebInterface.docReady('');
    $(".menuButton").touchdown(function() {
        $(this).css({
            "background": "url(img/index/manuButtona.png) center no-repeat",
            "background-size":"38px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/lists.png) center no-repeat",
            "background-size":"38px"
        });
    });
    $(".classification").on("touchmove",function(){
        eventPrevent = true;
    }).on("touchend",function(){
        eventPrevent = false;
    }).on("touchcancel",function(){
        eventPrevent = false;
    })
});
var loadBottomHtml = '<div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span>';
function activityLoad(data) {
    var productArr = [];
    // debug(data);
        // if(data.topiclist.length==0){
        //  $("#loadBottom").html("已经加载完成");
        //  return;
        // }
        // if (reloadPage>0) {
        //     $("#headerTitle").html("精品文章");
        // }
    loadIndex++;
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5051, jsonString, "activityLoad",5);
        });
        return;
    }
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    if (data.status && data.status == 9 || (data.topiclist && data.topiclist.length == 0 && pageIndex == 0)) {
        $('.activity_lists').html("对不起，没有数据");
    }
    if (typeof data.topiclist == "undefined") {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
        return;
    }
    data = data.topiclist;
    
    if (data.length) {
        if (data.length < pageSize) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imageGrayTest", function(v1, v2) {
            if (v1 == true) {
                if (v2 == "shadowBox" && isIphone) {
                    return "";
                }
                return v2;
            } else {
                return "";
            }
        });
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".590x368");
            var index = initSize+loadIndex * pageSize + index;
            if (loadIndex > 1) {
                index = "productDetail" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return index = initSize+loadIndex * pageSize + index;
        });
        if (pageIndex == 0) {
            backTop();
            $('.activity_lists').html(myTemplate(data));
            if (data.length<2) {
                eventPrevent = true;
            }else{
                eventPrevent = false;
            }
        } else {
            $('.activity_lists').append(myTemplate(data));
        }
        if (loadIndex > 1) {
            for (var i = 0; i < productArr.length; i++) {
                ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}
$(".backButton").touchdown(function() {
    $(this).css({
        "background": "url(img/returnButton1.png) no-repeat center",
        "background-size": 36
    });
}, function() {
    $(this).css({
        "background": "url(img/returnButton.png) no-repeat center",
        "background-size": 36
    });
});
var manuFunc=function() {
    getplaymuic();
    console.log("manuclick"+flag)
    if (flag) {
        $(".classification").removeClass("scaleAnimation").addClass("scaleAnimation");
        flag = false;
    } else {

        $(".classification").removeClass("scaleAnimation");
        flag = true;
    }
};
$(".scrollContent").click(function() {
    console.log(flag)
        getplaymuic();
        if (!flag) {
            $(".classification").removeClass("scaleAnimation");
            console.log(flag)
            setTimeout(function() {
                flag = true;
            }, 300);
        }
    })
$(".scrollContent")[0].addEventListener('touchmove', function(event) {
        $(".classification").removeClass("scaleAnimation");
        setTimeout(function() {
            flag = true;
        }, 100);
}, false); 
    // window.onscroll = function(event){
    //     debug(iosScroll)
    //     iosScroll=false;
        
    // }
$(".menuButton").on("click",function() {
    if(androidVersionNum==0||androidVersionNum>=440)manuFunc.apply(this);
});
$(document).fix("click", "figure", function() {
    if (!flag) return;
    if (!clickUsed && !lazyLoad.parentFixed(event)) return;
    var schemeContent = 'ikan://web/ikan_specialSubject.html#{"command":5060,"params":{"topicId":' + $(this).data("id") + '}}';
    ikanWebInterface.startIkanScheme(schemeContent,' ',5);
}, {
    "commOnce": true
});
var back=function(){
    getplaymuic();
    ikanWebInterface.back();
};
function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop = 0;
    }
    document.body.scrollTop = 0;
}
var classification=function(){
    getplaymuic();
    topDownComm();
    flag = true;
    $(".classification li").removeClass("classificationSelect");
    $(".classification").removeClass("scaleAnimation");
    $(this).addClass("classificationSelect");
    pageIndex = 0;
    var type = $(".classificationSelect").text();
    $("#headerTitle").html("精品文章-" + type);
    switch (type) {
        case '全部':
            $("#headerTitle").html("精品文章");
            topicType="";
            ikanWebInterface.command(5051, '{"page":0,"pageSize":12}', "activityLoad",5);
            break;
        case '商品评测':
            topicType=1;
            ikanWebInterface.command(5051, '{"page":0,"pageSize":12,"topicType":1}', "activityLoad",5);
            break;
        case '动漫推荐':
            topicType=2;
            ikanWebInterface.command(5051, '{"page":0,"pageSize":12,"topicType":2}', "activityLoad",5);
            break;
        case '亲子教育':
            topicType=3;
            ikanWebInterface.command(5051, '{"page":0,"pageSize":12,"topicType":3}', "activityLoad",5);
            break;
        case '育儿百科':
            topicType=4;
            ikanWebInterface.command(5051, '{"page":0,"pageSize":12,"topicType":4}', "activityLoad",5);
            break;
        case '精彩活动':
            topicType=5;
            ikanWebInterface.command(5051, '{"page":0,"pageSize":12,"topicType":5}', "activityLoad",5);
            break;
        default:
            break;
    }
};
function headerClickFunc(){
    var headerOptions={
        ".backButton":back,
        ".classification li":classification,
        ".callTopIcon":callTopFunc,
        ".menuButton":manuFunc,

    };
    return headerOptions;
}
$(".backButton").click(function() {
    if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
});
$(".activity_lists").bind("click", function() {
    getplaymuic();
    if ($(".classification").hasClass("scaleAnimation")) {
        $(".classification").removeClass("scaleAnimation").addClass("scaleOutAnimation");
    }
});
$(".classification li").unbind("click").bind("click", function() {
    if(androidVersionNum==0||androidVersionNum>=440)classification.apply(this);
});

