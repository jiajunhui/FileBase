$(function(){
    $(".btn").on("click",function(){
        ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"));
    })
    $(".logo").on("click", function() {
        var schemeContent = 'http://172.16.218.42/Web_app/ikan_toyList.html#{"command":"5075","params":{"filterInfo":{"brandId":'+$(this).data(id)+'},"sortId":1}}';
        ikanWebInterface.startIkanScheme(schemeContent);
    });
    $("figure").on("click", function() {
        ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"));
    });
    $(".footerImg").on("click",function(){
        var schemeContent = 'http://172.16.218.42/Web_app/ikan_categories.html#{"command":"5023","params":{"categoryId":' + $(this).data("id") + ',"sortId":1}}';
        ikanWebInterface.startIkanScheme(schemeContent);
    })

})