 var jsonString = '{"ageRange":[{"tagList":[{"tagId":53,"tagValue":"0-1岁","groupId":4,"tagName":"年龄"},{"tagId":54,"tagValue":"1-3岁","groupId":4,"tagName":"年龄"},{"tagId":55,"tagValue":"3-6岁","groupId":4,"tagName":"年龄"},{"tagId":56,"tagValue":"6-12岁","groupId":4,"tagName":"年龄"},{"tagId":57,"tagValue":"12岁+","groupId":4,"tagName":"年龄"}],"groupId":4,"cname":"年龄"}],"catagorys":[{"secondCatagoryVO":[{"cname":"摇铃床铃","catagoryId":10},{"cname":"学步健身","catagoryId":12},{"cname":"幼教启蒙","catagoryId":14},{"cname":"情景扮演","catagoryId":16},{"cname":"早教机","catagoryId":18}],"cname":"早教认知","isSelected":1,"catagoryId":1},{"secondCatagoryVO":[{"cname":"水杯水壶","catagoryId":19},{"cname":"餐具餐椅","catagoryId":20},{"cname":"浴室卫生","catagoryId":21}],"cname":"婴幼用品","isSelected":0,"catagoryId":2},{"secondCatagoryVO":[{"cname":"拼图","catagoryId":27},{"cname":"棋牌桌游","catagoryId":22},{"cname":"木制积木","catagoryId":23},{"cname":"立体拼插","catagoryId":24},{"cname":"彩泥粘土","catagoryId":26},{"cname":"拼图2","catagoryId":44},{"cname":"棋盘桌游2","catagoryId":45},{"cname":"木制积木","catagoryId":46}],"cname":"益智玩具","isSelected":0,"catagoryId":3},{"secondCatagoryVO":[{"cname":"靠垫抱枕","catagoryId":31},{"cname":"毛绒公仔","catagoryId":30},{"cname":"芭比卡通  ","catagoryId":28}],"cname":"毛绒人偶","isSelected":0,"catagoryId":4},{"secondCatagoryVO":[{"cname":"车船模型 ","catagoryId":32},{"cname":"动漫模型","catagoryId":33},{"cname":"遥控玩具","catagoryId":34},{"cname":"智能电动","catagoryId":35},{"cname":"轨道助力","catagoryId":36}],"cname":"模型电动","isSelected":0,"catagoryId":5},{"secondCatagoryVO":[{"cname":"绘画画笔","catagoryId":37},{"cname":"手工文具 ","catagoryId":38},{"cname":"书包箱包","catagoryId":39}],"cname":"文具绘画","isSelected":0,"catagoryId":6},{"secondCatagoryVO":[{"cname":"滑板单车","catagoryId":40},{"cname":"枪类玩具","catagoryId":42}],"cname":"户外运动","isSelected":0,"catagoryId":7}],"title":"早教认知","products":[{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/4f2023e0-33ab-4253-9f55-dedc833d4fa0.jpg","totalNumber":271,"productCode":6001008,"price":49,"vprice":31,"sortNum":0,"storageStatus":0,"productName":"费雪 益智玩具 新生儿缤纷动物之熊猫摇铃 ","svprice":31,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/3a095201-3bf6-4686-9228-0006cbf29453.jpg","totalNumber":271,"productCode":6001009,"price":49,"vprice":31,"sortNum":0,"storageStatus":1,"productName":"费雪 益智早教 缤纷动物之小猴子牙胶摇铃 3个月以上","svprice":31,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/e8fbd841-e1fc-4805-b334-ecd5ef8b5b13.jpg","totalNumber":271,"productCode":6315011,"price":158,"vprice":87,"sortNum":0,"storageStatus":0,"productName":"贝恩施 动感爵士鼓带炫酷麦克风 3岁以上","svprice":85,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/9af4dd04-362d-414b-949a-940aab7f3737.jpg","totalNumber":271,"productCode":6315034,"price":128,"vprice":62,"sortNum":0,"storageStatus":0,"productName":"贝恩施 欢乐购物车 粉色 3岁以上","svprice":62,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/1d4839c8-1ca8-4472-b3d4-1b1d36bf1fa8.jpg","totalNumber":271,"productCode":6315031,"price":99,"vprice":41,"sortNum":0,"storageStatus":0,"productName":"贝恩施 益智手拍鼓 琴鼓二合一 3岁以上","svprice":41,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/a79a9eae-7051-4019-872b-a846107a6fc5.jpg","totalNumber":271,"productCode":6315017,"price":99,"vprice":58,"sortNum":0,"storageStatus":1,"productName":"贝恩施 哆啦A梦 梦幻遥控赛车（Q版）  黄色 3岁以上","svprice":58,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/e03381b1-7307-466c-9c1c-192b052e7125.jpg","totalNumber":271,"productCode":6315015,"price":99,"vprice":56,"sortNum":0,"storageStatus":1,"productName":"贝恩施 电动快乐钓鱼玩具 蓝色 3岁以上","svprice":56,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/bfc7c9bf-5b3b-408d-8177-ee6e4f6926f8.jpg","totalNumber":271,"productCode":6315009,"price":99,"vprice":48,"sortNum":0,"storageStatus":1,"productName":"贝恩施 两层旋转式亲子钓鱼玩具 粉色 3岁以上","svprice":48,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/76e4628c-7d6b-4fab-8101-45104cc74ee6.jpg","totalNumber":271,"productCode":6315012,"price":99,"vprice":61,"sortNum":0,"storageStatus":0,"productName":"贝恩施 宝宝布书（蔬菜、天气、水果、形状、颜色、常见人物） A10B","svprice":61,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/ec2a43e2-3e62-4482-8cbd-152efb02c7f5.jpg","totalNumber":271,"productCode":6315016,"price":158,"vprice":65,"sortNum":0,"storageStatus":0,"productName":"贝恩施 益智启蒙多功能工具櫈 3岁以上","svprice":65,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/7412afb2-00f4-4070-8fcc-5185018e80ec.jpg","totalNumber":271,"productCode":6315033,"price":128,"vprice":62,"sortNum":0,"storageStatus":0,"productName":"贝恩施 欢乐购物车 蓝色 3岁以上","svprice":62,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/63d8e08a-b80a-4f29-beb6-5ef3c4d2e2f5.jpg","totalNumber":271,"productCode":6315040,"price":118,"vprice":65,"sortNum":0,"storageStatus":0,"productName":"贝恩施 趣味婴儿摇铃8件套 3个月以上","svprice":65,"status":1}],"sortVos":[{"sortName":"价格最高","sortId":0},{"sortName":"价格最低","sortId":1},{"sortName":"最新上架","sortId":2},{"sortName":"评价最佳","sortId":3},{"sortName":"销量最多","sortId":4},{"sortName":"折扣最高","sortId":5}],"filterInfo":{"brandInfo":{"selectBrandId":0,"brands":[{"brandName":"LEGO/乐高","brandId":14},{"brandName":"Fisher-Price/费雪","brandId":12},{"brandName":"Barbie/芭比娃娃","brandId":22},{"brandName":"THOMAS&FRIENDS/托马斯","brandId":21},{"brandName":"澳贝","brandId":39},{"brandName":"贝恩施","brandId":47},{"brandName":"Hape","brandId":50},{"brandName":"NERF/热火","brandId":45},{"brandName":"Silverlit/银辉","brandId":19},{"brandName":"Siku","brandId":23},{"brandName":"BRIO","brandId":29},{"brandName":"ubbie/优彼","brandId":43},{"brandName":"木玩世家","brandId":26},{"brandName":"培培乐","brandId":4},{"brandName":"SpongeBob/海绵宝宝","brandId":17},{"brandName":"Disney/迪士尼","brandId":10},{"brandName":"熊出没","brandId":15},{"brandName":"Zoobies/如比","brandId":6},{"brandName":"Masterkidz/贝思德","brandId":36},{"brandName":"爱可丽","brandId":31},{"brandName":"Pororo&Friends/啵乐乐","brandId":9},{"brandName":"HelloKitty/凯蒂猫","brandId":7},{"brandName":"凯佩珑","brandId":33},{"brandName":"英德","brandId":16},{"brandName":"Colorato/卡乐淘","brandId":5},{"brandName":"DreamWorks/梦工厂","brandId":18},{"brandName":"Transformers/变形金刚","brandId":25},{"brandName":"喜羊羊与灰太狼","brandId":41},{"brandName":"RobocarPoli","brandId":20},{"brandName":"Schleich/思乐","brandId":24},{"brandName":"索凡","brandId":32},{"brandName":"小马宝莉","brandId":44},{"brandName":"KOKADO/高佳多","brandId":30},{"brandName":"米米智玩","brandId":27},{"brandName":"富尔达","brandId":8}],"cname":"品牌","sortNum":0},"tags":[{"tagList":[{"tagId":60,"tagValue":"布艺","groupId":16,"tagName":"材质"},{"tagId":61,"tagValue":"塑料","groupId":16,"tagName":"材质"},{"tagId":62,"tagValue":"金属","groupId":16,"tagName":"材质"},{"tagId":63,"tagValue":"毛绒","groupId":16,"tagName":"材质"},{"tagId":64,"tagValue":"胶泥","groupId":16,"tagName":"材质"},{"tagId":65,"tagValue":"纸质","groupId":16,"tagName":"材质"},{"tagId":66,"tagValue":"木质","groupId":16,"tagName":"材质"},{"tagId":67,"tagValue":"玻璃","groupId":16,"tagName":"材质"},{"tagId":68,"tagValue":"其他","groupId":16,"tagName":"材质"}],"groupId":16,"cname":"材质","sortNum":2},{"tagList":[{"tagId":69,"tagValue":"红/粉/紫","groupId":17,"tagName":"颜色"},{"tagId":70,"tagValue":"??黄/橙/棕?","groupId":17,"tagName":"颜色"},{"tagId":71,"tagValue":"?蓝/绿/青?","groupId":17,"tagName":"颜色"},{"tagId":72,"tagValue":"?黑/白/灰","groupId":17,"tagName":"颜色"}],"groupId":17,"cname":"颜色","sortNum":3},{"tagList":[{"tagId":75,"tagValue":"变形金刚/Transformers","groupId":18,"tagName":"动漫周边"},{"tagId":76,"tagValue":"小马宝莉/My Little Pony","groupId":18,"tagName":"动漫周边"},{"tagId":77,"tagValue":"漫威/Marvel","groupId":18,"tagName":"动漫周边"},{"tagId":78,"tagValue":"托马斯&朋友/Thomas＆Friends","groupId":18,"tagName":"动漫周边"},{"tagId":79,"tagValue":"芭比/Barbie","groupId":18,"tagName":"动漫周边"},{"tagId":83,"tagValue":"喜羊羊与灰太狼","groupId":18,"tagName":"动漫周边"},{"tagId":84,"tagValue":"超能陆战队","groupId":18,"tagName":"动漫周边"},{"tagId":85,"tagValue":"冰雪奇缘","groupId":18,"tagName":"动漫周边"},{"tagId":86,"tagValue":"小公主苏菲亚","groupId":18,"tagName":"动漫周边"},{"tagId":87,"tagValue":"米老鼠和唐老鸭","groupId":18,"tagName":"动漫周边"},{"tagId":88,"tagValue":"变形警车珀利","groupId":18,"tagName":"动漫周边"},{"tagId":89,"tagValue":"铠甲勇士","groupId":18,"tagName":"动漫周边"},{"tagId":90,"tagValue":"巴啦啦小魔仙","groupId":18,"tagName":"动漫周边"},{"tagId":91,"tagValue":"火力少年王","groupId":18,"tagName":"动漫周边"},{"tagId":92,"tagValue":"超级飞侠","groupId":18,"tagName":"动漫周边"},{"tagId":93,"tagValue":"快乐酷宝","groupId":18,"tagName":"动漫周边"},{"tagId":94,"tagValue":"小企鹅啵乐乐","groupId":18,"tagName":"动漫周边"},{"tagId":176,"tagValue":"凯蒂猫/HelloKitty","groupId":18,"tagName":"动漫周边"},{"tagId":177,"tagValue":"海绵宝宝/SpongeBob","groupId":18,"tagName":"动漫周边"},{"tagId":178,"tagValue":"马达加斯加的企鹅","groupId":18,"tagName":"动漫周边"},{"tagId":179,"tagValue":"驯龙高手","groupId":18,"tagName":"动漫周边"},{"tagId":180,"tagValue":"熊出没","groupId":18,"tagName":"动漫周边"},{"tagId":189,"tagValue":"白雪公主和七个小矮人","groupId":18,"tagName":"动漫周边"},{"tagId":181,"tagValue":"愤怒的小鸟/Angry Birds","groupId":18,"tagName":"动漫周边"},{"tagId":190,"tagValue":"小美人鱼","groupId":18,"tagName":"动漫周边"},{"tagId":195,"tagValue":"海贼王","groupId":18,"tagName":"动漫周边"},{"tagId":230,"tagValue":"黑猫警长","groupId":18,"tagName":"动漫周边"},{"tagId":236,"tagValue":"小熊维尼","groupId":18,"tagName":"动漫周边"},{"tagId":237,"tagValue":"星际宝贝","groupId":18,"tagName":"动漫周边"},{"tagId":238,"tagValue":"灰姑娘","groupId":18,"tagName":"动漫周边"},{"tagId":239,"tagValue":"赛车总动员","groupId":18,"tagName":"动漫周边"}],"groupId":18,"cname":"动漫周边","sortNum":4},{"tagList":[{"tagId":182,"tagValue":"0-100","groupId":2,"tagName":"价格"},{"tagId":183,"tagValue":"100-300","groupId":2,"tagName":"价格"},{"tagId":184,"tagValue":"300-500","groupId":2,"tagName":"价格"},{"tagId":185,"tagValue":"500-800","groupId":2,"tagName":"价格"},{"tagId":186,"tagValue":"800+","groupId":2,"tagName":"价格"}],"groupId":2,"cname":"价格","sortNum":5},{"tagList":[{"tagId":58,"tagValue":"男孩","groupId":14,"tagName":"性别"},{"tagId":59,"tagValue":"女孩","groupId":14,"tagName":"性别"}],"groupId":14,"cname":"性别","sortNum":1}]},"rootCategoryId":1}'

 function init(json) {
     // try {
     //     initTest(json)
     // } catch (e) {
     //     document.write(e.name);
     //     document.write(e.number);
     //     document.write(e.description);
     //     document.write(e.message);
     //     document.write(json)
     // }
     setTimeout(function() {
         initTest(json);
     }, 100)
 }

 function initTest(json) { //初始化页面方法
     json = typeof(json) == "string" ? JSON.parse(json) : json;
     if (json.status && json.status == 10) {
         dead();
         $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
         });
         return;
     }
     if (json.title) {
        $(".heaerTitle").html(json.title);
        $(".categoryDetailButton").eq(2).find("span").html(json.title);
    }
    $(".scrollContent").show();
     if(json.rootCategoryId)jsonFilter.rootCategoryId = json.rootCategoryId;
     if (json.status && json.status == 9 || json.products.length == 0) {
         $("#searchImg").show();
         $(".box").hide();
         $(".scrollContent").hide();
         return;
     }
     dataManu = [{
         "imageUrl": "img/index/baby.png",
     }, {
         "imageUrl": "img/index/children.png",
     }, {
         "imageUrl": "img/index/bulidingblock.png",
     }, {
         "imageUrl": "img/index/plushtoys.png",
     }, {
         "imageUrl": "img/index/model.png",
     }, {
         "imageUrl": "img/index/handwork.png",
     }, {
         "imageUrl": "img/index/fitness.png",
     }];
     var backBut = true,
         cartBat = true,
         performanceBut = true;
     productLoad(json);
     $(".box").hide();
     $(".scrollContent").animate({
         opacity: 1
     }, 300);

     function callPageLoad(pageIndex) { //分页回掉函数
         jsonFilter.pageSize = 12;
         jsonFilter.page = pageIndex;
         ikanWebInterface.command(5069, JSON.stringify(jsonFilter), "productLoad",13);
     }
     loadImage("scrollContent", callPageLoad);
     var markPostionArr = ["1.8rem", "5.4rem", "9.3rem", "13.3rem"];
     var categoryContentObj = $("div[class^='categoryContent']");
     var categoryInterval = null;
     var preIndex = 0;
     $(".categoryDetailButton").unbind("click").bind("click", function(event) {
         getplaymuic();
         clearTimeout(categoryInterval);
         $(".callTopButton").hide();
         $(".bg").removeClass("translateHide").css("opacity", 1);
         eventPrevent = true;
         categoryIndex = $(this).index();
         if($(".translateShow").length==0){
             $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
         if (categoryContentObj.eq(categoryIndex).hasClass("translateShow")) {
             eventPrevent = false;
             $(".scrollContent").css({
                 "overflow": "auto"
             });
             $(".categoryMark").hide();
             categoryInterval=setTimeout(function(){$(".categoryContentArea").hide();},500)
             categoryContentObj.eq(categoryIndex).removeClass("translateShow").addClass("translateHide");
             $(".categoryIcon").attr("src", "img/640_16.png");
            $(".categoryIcon1").attr("src", "img/640_11.png");
             if (jsonFilter.filterInfo) {
                 $(".categoryIcon1").attr("src", "img/640_06.png");
             }
             $(".bgColor").hide();
             return;
         }
         $(".bgColor").show();
         $(".categoryMark").css({
             left: markPostionArr[categoryIndex]
         }).show();
         var categoryContentEval = "categoryContent" + categoryIndex + "()";
         $(".categoryIcon").attr("src", "img/640_16.png");
            $(".categoryIcon1").attr("src", "img/640_11.png");
         if (jsonFilter.filterInfo) {
             $(".categoryIcon1").attr("src", "img/640_06.png");
         }
         $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_14.png");
         eval(categoryContentEval);
         $(".manuArea").hide();
         if (categoryIndex == 3) {
             $(".categoryIcon1").attr("src", "img/640_06.png");
             setTimeout(function() {
                 $(".manuArea").css({
                     display: "-webkit-box"
                 }).removeClass("translateHide");
             }, 0);
         }
         if ($(".translateShow").length) {
             categoryContentObj.eq(preIndex).removeClass("translateShow");
         } else {
             $(".categoryContentArea").show().css({
                 opacity: 1
             });
         }
         categoryContentObj.removeClass("translateHide").removeClass("translateShow").addClass("translateHide").eq(categoryIndex).removeClass("translateHide").addClass("translateShow");
         preIndex = categoryIndex;
         if ($(".categoryContentArea").css("display") == "block") {
             $(".bg").unbind("click").click(function() {
                 getplaymuic();
                 $(".bgColor").hide();
                 $(".scrollContent").css({
                     overflow: "auto"
                 });
                 $(".categoryMark").hide();
                 // $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);")
                 eventPrevent = false;
                 $(".translateShow").removeClass("translateShow").addClass("translateHide");
                 setTimeout(function(){$(".categoryContentArea").hide()},500)
                 // $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_16.png");
                 $(".categoryIcon").attr("src", "img/640_16.png");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }else{
                    $(".categoryIcon1").attr("src", "img/640_11.png");
                }
              
             })
         }
     });
     //综合排序
     function categoryContent0() {
         if ($(".rankCategoryArea").length == 0) {
             data1 = json.sortVos;
             var categoryHtml = '<div class="rankCategoryArea noLimitedRank"><span class="selectCategory">综合排序</span><img src="img/index/categorySelect.png" alt="" style="display:block"></div>';
             for (var i = 0; i < data1.length; i++) {
                 categoryHtml += '<div class="rankCategoryArea" data-id=' + data1[i].sortId + ' data-group=' + data1[i].groupId + '><span>' + data1[i].sortName + '</span><img src="img/index/categorySelect.png" alt=""></div>'
             }
             $(".categoryContentDetail1").html(categoryHtml);
             $(".rankCategoryArea").click(function() {
                 getplaymuic();
                 $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
                 $(this).find("span").addClass("selectCategory").parent().find("img").show();
                 if ($(this).hasClass("noLimitedRank")) {
                     delete jsonFilter.sortId;
                     $(".categoryDetailButton span").eq(0).html("综合排序");
                 } else {
                     $(".categoryDetailButton span").eq(0).html($(this).find("span").html());
                     jsonFilter.sortId = $(this).data("id");
                 }
                 selectCategoryOut();
                 $(".box").css("display", "-webkit-box");
                 if (jsonFilter.filterInfo) {
                     $(".categoryIcon1").attr("src", "img/640_06.png");
                 }
                 jsonFilter.pageSize = 12;
                 jsonFilter.page = 0;
                 pageIndex = 0;
                 ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',13);
             });
         }
     };

     function categoryContent1() {
         if ($(".babyAgeSelectDetail").length == 0) {
             // var data2=jsonS.ageRange;//数据todo
             var dataGroup = json.ageRange[0].groupId;
             var data2 = json.ageRange[0].tagList;
             var categoryHtml = '<div class="babyAgeSelectDetail noLimitedAge">不限</div>';
             for (var i = 0; i < data2.length; i++) {
                 categoryHtml += '<div class="babyAgeSelectDetail" data-id=' + data2[i].tagId + '>' + data2[i].tagValue + '</div>';
             }
             $(".babyAgeSelect").html(categoryHtml);
             $(".babyAgeSelectDetail").click(function() {
                 getplaymuic();
                
                 $(".babyAgeSelectDetail").removeClass("selectCategory");
                 $(this).addClass("selectCategory");
                 if ($(this).hasClass("noLimitedAge")) {
                     delete jsonFilter.ageRange;
                     $(".categoryDetailButton span").eq(1).html("年龄");
                 } else {
                     $(".categoryDetailButton span").eq(1).html($(this).text());
                     var ageRange = {};
                     ageRange.groupId = dataGroup;
                     ageRange.tagId = $(this).data("id");
                     jsonFilter.ageRange = ageRange;
                 }
                 selectCategoryOut();
                 $(".box").css("display", "-webkit-box");
                 if (jsonFilter.filterInfo) {
                     $(".categoryIcon1").attr("src", "img/640_06.png");
                 }
                 jsonFilter.pageSize = 12;
                 jsonFilter.page = 0;
                 pageIndex = 0;
                 ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',13);
             });
         }
     };
     var cateMainNum=1;
     var selectedText;
     function categoryContent2() {
        if (isIphone) {
            eventPrevent = false;
            $(".categoryListBox").css("height","17.6rem");
            $(".scrollContent").css("overflow","hidden");
        } 
         if ($(".categoryMainListDetail").length == 0) {
             data3 = json.catagorys;
             var categoryHtml = "";
             var selectStyle = "";
             var categoryHtmls = "";
             var Selected = cateMainNum;
             for (var i = 0; i < data3.length; i++) {
                 selectStyle = "";
                 if (data3[i].isSelected == 1) {
                     selectStyle = " categoryMainListSelect";
                     Selected = i+1;
                 }
                 categoryHtml += '<div class="categoryMainListDetail' + selectStyle + '" data-id=' + data3[i].catagoryId + '><img src="' + dataManu[i].imageUrl + '" alt=""><span>' + data3[i].cname + '</span></div>';
                 
             }
             $(".categoryMainList").append(categoryHtml);
             addCategoryDetail(Selected);
             var selectedIndex = "";
             function addCategoryDetail(num) {
                num--;
                 categoryHtml = "";                 
                 var detailListObj = data3[num].secondCatagoryVO;
                 for (var i = 0; i < detailListObj.length; i++) {
                     categoryHtml += '<div class="categoryDetailListName" data-id=' + detailListObj[i].catagoryId + '><span>' + detailListObj[i].cname + '</span><img src="img/index/categorySelect.png" alt="" class="categoryDetailListNameImg"></div>';
                 }
                 $(".categoryDetailList").html(categoryHtml);
                $(".noLimitedCategory").find("img").hide();
                 if(selectedText!==""&&categoryHtml.indexOf(selectedText)>-1){
                    $(".categoryDetailListName span").eq(selectedIndex+1).siblings("img").show()
                 }else if(json.title&&json.title==$(".categoryMainListSelect span").text()&&(selectedText==undefined||selectedText=="不限")){
                    $(".noLimitedCategory").find("img").show();
                 }
                 $(".categoryDetailListName").click(function() {
                     getplaymuic();
                     if ($(this).hasClass("noLimitedCategory")) {
                        json.title=$(".categoryMainListSelect span").text();
                         $(".heaerTitle").html($(".categoryMainListSelect").text());
                         delete jsonFilter.categoryId;
                         jsonFilter.rootCategoryId=$(".categoryMainListSelect").data("id");
                         $(".categoryDetailButton span").eq(2).html("分类");
                     } else {
                         $(".categoryDetailButton span").eq(2).html($(this).text());
                         jsonFilter.categoryId = $(this).data("id");
                         delete jsonFilter.rootCategoryId;
                         $(".heaerTitle").html($(".categoryMainListSelect").text());
                     }
                     $(".categoryDetailListNameImg").hide()
                     $(this).find("img").show();
                     selectedText = $(this).find("span").text()
                     selectedIndex = $(this).index()
                     selectCategoryOut();
                     $(".box").css("display", "-webkit-box");
                     if (jsonFilter.filterInfo) {
                         $(".categoryIcon1").attr("src", "img/640_06.png");
                     }
                     if (isIphone) {
                        $(".scrollContent").css("overflow","auto");
                     } 
                     jsonFilter.pageSize = 12;
                     jsonFilter.page = 0;
                     pageIndex = 0;
                     ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',13);
                 })
             }
             $(".categoryMainLimite").click(function(){
                cateMainNum = 1;
                selectedText="";
                $(".heaerTitle").html("全部分类");
                $(this).addClass("categoryMainListSelect");
                $(".categoryDetailButton").eq(2).find("span").text("分类");
                $(".categoryDetailButton").eq(2).find("span").removeClass("greenFont")
                $(".categoryListBox").hide();
                $(".categoryMainListDetail").removeClass("categoryMainListSelect");
                selectCategoryOut();
                if(jsonFilter.rootCategoryId) delete jsonFilter.rootCategoryId;
                if(jsonFilter.categoryId) delete jsonFilter.categoryId;
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',13);
             })
             $(".categoryMainListDetail").click(function() {
                 getplaymuic();
                 $(".categoryListBox").show();
                 $(".categoryMainLimite").removeClass("categoryMainListSelect");
                 $(".categoryMainListDetail").removeClass("categoryMainListSelect");
                 $(this).addClass("categoryMainListSelect");
                 cateMainNum=$(this).index();
                 addCategoryDetail(cateMainNum);
             });
         }
     };

     function categoryContent3() {
         eventPrevent = false;
         if ($(".filterSelectContentDetail").length == 0) {
             var sortNumFiter = {};
             var categoryHtml = "";
             data4 = json.filterInfo;
             var data4Keys = Object.keys(data4); //获得品牌等的key；
             for (var i = 0; i < data4Keys.length; i++) { //对keys进行遍历
                 dataDetail = data4[data4Keys[i]]; //便利得到的品牌等的对象或数组
                 if (dataDetail instanceof Array) { //如果是数组就继续遍历获得对象
                     for (var k = 0; k < dataDetail.length; k++) { //继续遍历该数组
                         dataDetailCont = dataDetail[k]; //获取到颜色等对象，输入创建筛选内容函数
                         categoryHtmlAdd(dataDetailCont);
                     }
                 } else {
                     categoryHtmlAdd(dataDetail);
                 }

                 function categoryHtmlAdd(dataDetails) { //创建筛选内容函数，dataDetails为相应的颜色或者品牌对象
                         categoryHtml = "";
                         var selectId = false;
                         var groupIdHtml = "";
                         for (var detailkeys in dataDetails) { //统一变量
                             if (detailkeys.indexOf("select") > -1) {
                                 selectId = dataDetails[detailkeys];
                             }
                             if (detailkeys == "groupId") { //如果长度大于2，则是标签有groupId
                                 groupIdHtml = 'data-group=' + dataDetails.groupId;
                             }
                             if (dataDetails[detailkeys] instanceof Array) { //如果是数组，那么该keys就是列表
                                 taglist = detailkeys;
                             }
                         }
                         //在下面对获取到的特定变量进行同等操作
                         var dataDetailArr = dataDetails[taglist];
                         for (var keys in dataDetailArr[0]) { //统一变量
                             if ("groupId" in dataDetailArr[0]) {
                                 tagId = "tagId";
                                 tagValue = "tagValue";
                             } else {
                                 if (keys.indexOf("Id") > -1) {
                                     tagId = keys;
                                 } else {
                                     tagValue = keys;
                                 }
                             }
                         }
                         for (var categoryButtonHtml = "", j = 0; j < dataDetailArr.length; j++) {
                             var selectStyle = (selectId && dataDetailArr[j][tagId] == selectId) ? " filterSelectedButton" : "";
                             categoryButtonHtml += '<div class="filterSelectContentDetail' + selectStyle + '" data-id=' + dataDetailArr[j][tagId] + ' data-keys=' + tagId + '><span>' + dataDetailArr[j][tagValue] + '</span></div>'
                         }
                         categoryHtml += '<section class="filterArea"' + groupIdHtml + '><div class="filterSelectTitle"><span class="filterTitleName">' + dataDetails.cname + ':</span><p class="content-long-to-dotted">不限</p><img src="img/textButton1.png" alt=""></div><div class="filterSelectContent">' + categoryButtonHtml + '</div></section>'
                         sortNumFiter[dataDetails.sortNum] = categoryHtml;
                     }
                     //立即调用
             }
             for (var i = 0, categoryHtml = ""; i in sortNumFiter; i++) {
                 categoryHtml += sortNumFiter[i];
             }
             $(".categoryContentDetail4").html(categoryHtml);
             var buttonHeight = $(window).width() / 10;
             $.each($(".filterSelectContent"), function(index, item) {
                 ! function(_this) {
                     setTimeout(function() {
                         var thisHeight = $(_this).height();
                         $(_this).data("height", thisHeight);
                         $(_this).css({
                             height: buttonHeight
                         });
                         if (thisHeight < buttonHeight * 1.5) $(_this).parent().find("img").addClass("triggleHide").hide();
                     }, 10)
                 }(this)
             });
             $(".filterSelectTitle").click(function() {
                 $(".categoryContentDetail4").css({
                     "overflow": "hidden"
                 });
                 setTimeout(function() {
                     $(".categoryContentDetail4").css({
                         "overflow": "auto"
                     });
                 }, 600)
                 getplaymuic();
                 var dataHeight,
                     _this = $(this).parent().find(".filterSelectContent");
                 dataHeight = $(this).parent().find(".filterSelectContent").data("height");
                 dataHeight = dataHeight - 0;
                 _this.data("height", _this.height()).height(dataHeight);
                 if ($(this).find("img").hasClass("triggleHide")) return;
                 $(this).find("img").toggleClass("zhuan");
             });
             $(".filterSelectContentDetail").click(function() {
                 getplaymuic();
                 var contentLong = $(this).parent().parent().find(".content-long-to-dotted");
                 var contentLongHtml = contentLong.data("content"),
                     buttonContent = $(this).find("span").html(),
                     contentLongText;
                 if ($(this).hasClass("filterSelectedButton")) {
                     $(this).removeClass("filterSelectedButton");
                     contentLong.html(contentLong.data("define"));
                     return;
                 }
                 $(this).parent().find(".filterSelectContentDetail").removeClass("filterSelectedButton");
                 $(this).addClass("filterSelectedButton");
                 if (contentLong.html().indexOf("不限") > -1) {
                     contentLong.data("define", contentLong.html())
                 }
                 contentLong.html(buttonContent);
             })
         };
     };
     $(".manuArea div").eq(0).click(function() { //重置按钮
         getplaymuic();
         $(".filterSelectContentDetail").removeClass("filterSelectedButton");
         $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
         $.each($(".content-long-to-dotted"), function(index, item) {
             if ($(item).data("define")) {
                 var itemDefine = $(item).data("define");
                 $(item).html(itemDefine).data("content", itemDefine);
             }
         });
     });

     function selectCategoryOut() {
        // if (isIphone){
         //                 $(".scrollContent").removeClass("CategoryPg");
            //     }else{
         //                 $("body").removeClass("CategoryPg");
            //      }
        $(".bgColor").hide();
         eventPrevent = false;
         $(".scrollContent").css({
             "overflow": "auto"
         });
         categoryContentObj.removeClass("translateShow").addClass("translateHide");
         $(".categoryMark").hide();
         // $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);")
         $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
         setTimeout(function() {
             $(".categoryContentArea").hide();
         }, 500);
     }
     $(".manuArea div").eq(1).click(function() {
         getplaymuic();
         $(".manuArea").hide();
         selectCategoryOut();
         jsonInfo = {};
         var groupArr = [];
         if ($(".filterSelectedButton").length) {
             $.each($(".filterArea"), function(index, item) {
                 var filterSelectedDetail = $(item).find(".filterSelectedButton");
                 if (filterSelectedDetail.length > 0) {
                     var keys = filterSelectedDetail.eq(0).data("keys");
                     if (typeof $(item).data("group") !== "undefined") {
                         var groupElement = {};
                         groupElement.groupId = $(item).data("group");
                         groupElement[keys] = filterSelectedDetail.data("id");
                         groupArr.push(groupElement);
                     } else {
                         jsonInfo[keys] = filterSelectedDetail.data("id");
                     }
                 }
             })
             if (groupArr.length) {
                 jsonInfo.groupIds = groupArr;
             }
             jsonFilter.filterInfo = jsonInfo;
             jsonFilter.pageSize = 12;
             jsonFilter.page = 0;
             pageIndex = 0;
             if (typeof(jsonFilter.filterInfo) !== "undefined") {
                 $(".categoryIcon1").attr("src", "img/640_06.png");
             };
             console.log(jsonFilter)
             $(".box").css("display", "-webkit-box");
             ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',13);
         } else {
             delete jsonFilter.filterInfo;
             // jsonFilter.filterInfo = jsonInfo;
             jsonFilter.pageSize = 12;
             jsonFilter.page = 0;
             pageIndex = 0;
             ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad',13);
         }
     })
 }
 ikanWebInterface.isShoppingCartAdd();
 function returnShoppingCartAdd(isShoppingCart) {
     if (isShoppingCart === "true") return $(".J_shoppingCart").css({
         "background": "url(img/shopingcart1.png) no-repeat center",
         "background-size": "40px"
     });
     $(".J_shoppingCart").css({
         "background": "url(img/shopingcart.png) no-repeat center",
         "background-size": "40px"
     });
 }
 var jsonFilter = {};
 var back=function(){
        getplaymuic();
        ikanWebInterface.back();
 }
  var shoppingCart=function(){
        $(this).find("img").attr("src", "img/shopingcart1.png");
        ikanWebInterface.startIkanScheme('ikan://shoppingcart/',' ',13);
 }
 function headerClickFunc(){
        var headerOptions={
            ".J_backButton":back,
            ".J_shoppingCart":shoppingCart,
            ".callTopIcon":callTopFunc
        };
        return headerOptions;
    }
 $(function() {
     // init(jsonString);
     ikanWebInterface.docReady('');
     $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
     $(".J_backButton").touchdown(function() {
         $(this).css({
             "background": "url(img/returnButton1.png) no-repeat center",
             "background-size": 36
         });
     }, function() {
         $(this).css({
             "background": "url(img/returnButton.png) no-repeat center",
             "background-size": 36
         });
     });
     $(".J_shoppingCart").touchdown(function() {
        $(this).css({
            "background": "url(img/index/cart1a.png) no-repeat center",
            "background-size":"40px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/shopingcart.png) no-repeat center",
            "background-size":"40px"
        });
    });
     $(".J_backButton").click(function() {
         if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
     });
     $(".J_shoppingCart").fix("click", function() { //逻辑todo购物车
         if(androidVersionNum==0||androidVersionNum>=440)shoppingCart.apply(this);
     }, {
         "commOnce": true
     });
     $(document).fix("click", ".productDetail", function() {
         if (!clickUsed && !lazyLoad.parentFixed(event)) return;
         ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"),' ',13);
     }, {
         "commOnce": true
     });
 });

 function backTop() {
     if (isIphone) {
         return $(".scrollContent")[0].scrollTop = 0
     };
     document.body.scrollTop = 0;
 }
 var loadBottomHtml = $("#loadBottom").html();
 var searchNullFlag=false;
 function productLoad(data) {
     $("#searchImg").hide();
     loadIndex++;
     var productArr = [];
     data = typeof(data) == "string" ? JSON.parse(data) : data;
     if (data.status && data.status == 10) {
        if (pageIndex == 0) {
            dead();
            $(".dead").unbind("click").on("click",
                function() {
                    getplaymuic();
                    ikanWebInterface.reloadPage();
                    $(".bgShadow").hide();
                    // ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
                    $(".box").show();
                    $(".dead").hide();
                });
            return;
        }
         $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
         if(pageIndex>0)pageIndex--;
         pageLoadFinish = true;
         $(".loadBottom").unbind("click").on("click", function() {
             getplaymuic();
             pageIndex++;
             var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
             ikanWebInterface.command(5069, jsonString, "productLoad",13);
         });
         return;
     }else{
        $(".dead").hide();
        $(".scrollContent").show();
     }
     $(".box").hide();
     $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
     if (data.status && data.status == 9 || (data.products.length == 0 && pageIndex == 0)) {
         $("#searchImg").show();
         $(".scrollContent").hide();
         return;
     }
     if (data.searchNullFlag||searchNullFlag) { //相似搜索结果添加部分
         backTop();
         $(".sampleSearchArea").show();
         $(".cartoonArea").css({
             "margin-top": 0
         });
         searchNullFlag=true;
     } else {
         $(".sampleSearchArea").hide();
         $(".cartoonArea").css({
             "margin-top": "1.9rem"
         })
     }
     $(".scrollContent").show();
     data = data.products;
     if (data.length) {
         if (data.length < pageSize) {
             $("#loadBottom").html("已经加载完成");
             pageBottomFinish = false;
         }
         var myTemplate = Handlebars.compile($("#table-template").html());
         Handlebars.registerHelper("imgUrlRechange", function(value, index) {
             var imgUrls = ImageUrl(value, ".300x300");
             var index = initSize+loadIndex * pageSize + index;
             if (loadIndex > 0) {
                 index = "productDetail" + index;
                 productArr.push([imgUrls, index]);
             }
             return imgUrls;
         });
         Handlebars.registerHelper("indexChange", function(index) {
             return index = initSize+loadIndex * pageSize + index;
         });
         Handlebars.registerHelper("priceChange", function(price) {
             return parseFloat(price).toFixed(2);
         });
         Handlebars.registerHelper("stockoutTest", function(storageStatus, stockoutImageShow) {
                if (storageStatus == 0) {
                    return stockoutImageShow;
                } else {
                    return "";
                }
        });
         Handlebars.registerHelper("grayTest", function(storageStatus, gray) {
                // if (storageStatus == 0) {
                //     return gray;
                // } else {
                //     return "";
                // }
        });
        Handlebars.registerHelper("fontChange", function(storageStatus, stockoutFont) {
                if (storageStatus == 0) {
                    return stockoutFont;
                } else {
                    return "";
                }
        });
         if (pageIndex == 0) {
             backTop()
             $('.productArea').html(myTemplate(data));
         } else {
             $('.productArea').append(myTemplate(data));
         }
         if (typeof(vertical) !== "undefined") {
             vertical.refresh();
         }
         if (loadIndex > 1) {
             for (var i = 0; i < productArr.length; i++) {
                 if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                     ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
                 }
             }
         }
     } else {
         $("#loadBottom").html("已经加载完成");
         pageBottomFinish = false;
     }
     pageLoadFinish = true;
     $(".loader").addClass("bottomImageRotate");
 }