$(function(){
	loadImage("scrollContent");
	$(".backButton").click(function(){
		getplaymuic();
		$(this).css({"background-image":"url(img/returnButtonSelect.png)"});
		ikanWebInterface.back();//安卓
	});
})

