var jsonString = '{"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"albums":[],"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"albumCount":0,"knowledgeCount":2,"hotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"searchKey":"乐高","productCount":323,"productHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"knowledgeVideos":[{"totalNumber":2,"nowCount":0,"specialType":0,"name":"蓝猫小学音乐","typeName":"音乐儿歌","id":484,"vip":false,"totalCount":16,"snapshot":"http://webimg.ikan.cn/test/ximages/album/634edfca-5cd3-4d1e-919c-a4e1c97d0d12.jpg","age":"3~8岁"},{"totalNumber":2,"nowCount":0,"specialType":0,"name":"开心儿歌\u2014字母乐园","typeName":"音乐儿歌","id":612,"vip":false,"totalCount":27,"snapshot":"http://webimg.ikan.cn/test/ximages/album/0fb29088-b4f7-4bf5-a555-05a76a2693a2.jpg","age":"1~5岁"}],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉"],"products":[{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/d88625c7-04e2-49ce-a53b-69b2944bf9f9.jpg","totalNumber":323,"productCode":3001188,"price":139,"vprice":106,"sortNum":0,"storageStatus":0,"productName":"乐高 得宝系列 创意拼砌底板（2-5岁）","svprice":103,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/cde6366c-0a83-4bb3-9c8a-13c8f75f2955.jpg","totalNumber":323,"productCode":3001110,"price":799,"vprice":607,"sortNum":0,"storageStatus":1,"productName":"乐高 创意百变系列 单车店与咖啡厅 (9-14岁）","svprice":532,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/aa56af50-a9ef-4f6a-a897-28f7910a7430.jpg","totalNumber":323,"productCode":3001068,"price":199,"vprice":151,"sortNum":0,"storageStatus":1,"productName":"乐高 得宝系列 多合一礼品套装 （1.5-5岁）","svprice":142,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/ba794943-76c0-43f7-91f4-802dd155f6e6.jpg","totalNumber":323,"productCode":3001088,"price":699,"vprice":531,"sortNum":0,"storageStatus":1,"productName":"乐高 城市系列 警用巡查直升机 (5-12岁)","svprice":467,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/fdc79e8b-2ced-4c43-a91b-066b21126e28.jpg","totalNumber":323,"productCode":3001215,"price":299,"vprice":227,"sortNum":0,"storageStatus":1,"productName":"乐高 得宝创意系列  基础大盒装大颗粒","svprice":207,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/f1e1c2d4-9410-4484-a665-638491088cfa.jpg","totalNumber":323,"productCode":3001118,"price":599,"vprice":455,"sortNum":0,"storageStatus":1,"productName":"乐高 女孩系列 丛林救援基地(7-12岁)","svprice":402,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/f7cc4244-131c-4912-b880-990034916cd8.jpg","totalNumber":323,"productCode":3001107,"price":249,"vprice":189,"sortNum":0,"storageStatus":1,"productName":"乐高 创意系列 四轮越野摩托 (7-12岁）","svprice":175,"status":1},{"imgUrl":"http://webimg.ikan.cn/test/ximages/eb/product/8e13a54e-24ad-4a1b-a8b3-49d82c642a67.jpg","totalNumber":323,"productCode":3001035,"price":799,"vprice":607,"sortNum":0,"storageStatus":0,"productName":"乐高 得宝创意拼砌系列 娃娃屋 （2-5岁）","svprice":532,"status":1}]}';
function init(json) {
    setTimeout(function() {
        initTest(json);
    },100);
}
var hotKeysBox = [];
var hotKeysJson={};
var  noService=false;
function initTest(json) {
    var search = '<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
    search.innerHTML = "";
    $(".bgShadow").html(search);
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    debug(json)
    jsonFilter.page=0;
    jsonFilter.pageSize=8;
     jsonFilter.searchKey = json.searchKey;
       $("#search").val(inputSlice(json.searchKey));
       if(json.albumHotKeys)hotKeysJson.albumHotKeys=json.albumHotKeys;
       if(json.productHotKeys)hotKeysJson.productHotKeys=json.productHotKeys;
       if(json.knowledgeHotKeys)hotKeysJson.knowledgeHotKeys=json.knowledgeHotKeys;
       if(json.recommendHotKeys)hotKeysJson.recommendHotKeys=json.recommendHotKeys;
       $(".emptyHistory").click(function() {
        confirm("确认清空搜索历史记录？", ["确认", "取消"],
        function() {
            $(".searchVagaa").hide();
            hotKeysBox = [];
            window.localStorage.clear();
        }),
        function() {};
    });
    if (json.status && json.status == 10) {
        dead();
        var localhotKeys = window.localStorage;
        $("#search").html(localhotKeys[0])
        $(".dead").unbind("click").on("click",
        function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".bgShadow").hide();
            // ikanWebInterface.command(5115, JSON.stringify(jsonFilter), 'cartonLoad');
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    if (json.status && json.status == 9) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        noService=true;
        return;
    }
    data9 = json.hotKeys;
    if (data9) {
        for (var htmls = "",
        i = 0; i < data9.length; i++) {
            htmls += '<span id="hotKeys' + i + '">' + data9[i] + '</span>';
        }
        $(".hotKeys").html(htmls);
    }
    if(data9 == null){
        $(".hotKeys").hide()
        $(".hotText").hide()
    }
    cartonLoad(json);
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    },200);
    // function callPageLoad(pageIndex) {}
    loadImage("scrollContent");
    $(document).on("click",".recommendListVideo .moreRecommend",function() {
        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' + $("#search").val() + '","page":0,"pageSize":12}}',' ',47);
    });
    $(document).on("click",".recommendListToy .moreRecommend",function() {
        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + $("#search").val() + '","page":0,"pageSize":12}}',' ',47);
    });
    $(document).on("click",".recommendListKnowledge .moreRecommend",function() {
        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + $("#search").val() + '","page":0,"pageSize":12}}',' ',47);
    });
  
    
}
var jsonFilter = {};
$(function() {
    // init(jsonString);
    ikanWebInterface.docReady('');
    $(document).on("click",".hotKeys span",function(){
            var hotKeys = $(this).text();
            hotKeys = hotKeys.replace(/\"/ig, "").replace(/\\/ig, "");
            $("#search").val(inputSlice(hotKeys));
            if ($(this).val() !== "") {
                var newHotKeys = [];
                for (var j = 0; j < hotKeysBox.length; j++) {
                    if (hotKeysBox[j] !== hotKeys) {
                        newHotKeys.push(hotKeysBox[j]);
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox = newHotKeys;
                setItem();
            }
            switch ($(".selectArea span").text()) {
                case '全部':
                    jsonFilter.page = 0;
                    jsonFilter.pageSize = 8;
                    pageIndex = 0;
                    jsonFilter.searchKey = $("#search").val();
                    ikanWebInterface.command(5115, JSON.stringify(jsonFilter), 'cartonLoad',47);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',bool,47);
                    break;
                case '玩具':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,47);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,47);
                    break;
                default:
                    break;
            }
            // ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
            searchCancel();
        });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(document).fix("click", ".searchBox", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        if ($(this).hasClass("toy")) {
            ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("product"),' ',47);
        } else {
            ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("product"),' ',47);
        }
    },{"commOnce": true});
});
function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop = 0;
    }
    document.body.scrollTop = 0;
}
var loadBottomHtml = $("#loadBottom").html();
function cartonLoad(json) {
    $("#searchImg").hide();
    loadIndex++;
    var productArr = [];
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click",
        function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".bgShadow").hide();
            // ikanWebInterface.command(5115, JSON.stringify(jsonFilter), 'cartonLoad');
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    $("#search").val(inputSlice(json.searchKey));
    $(".box").hide();
    if (json.status && json.status == 9 || (json.albums.length == 0 && json.knowledgeVideos.length == 0 && json.products.length == 0 && pageIndex == 0)) {
        noService = true;
        $("#searchImg").show();
        $(".scrollContent").hide();
        return;
    }
    $(".toyTotal").html("(" + json.productCount + ")");
    $(".cartonTotal").html("(" + json.albumCount + ")");
    $(".knowledgeTotal").html("(" + json.knowledgeCount + ")");
    if (json.productCount) {
        $(".recommendListToy").show();
    } else {
        $(".recommendListToy").hide();
    }
    if (json.albumCount) {
        $(".recommendListVideo").show();
    } else {
        $(".recommendListVideo").hide();
    }
    if (json.knowledgeCount) {
        $(".recommendListKnowledge").show();
    } else {
        $(".recommendListKnowledge").hide();
    }
    if (json.products.length) {
        $(".recommendListToy").show();
    } else {
        $(".recommendListToy").hide();
    }
    if (json.albums.length) {
        $(".recommendListVideo").show();
    } else {
        $(".recommendListVideo").hide();
    }
    if (json.knowledgeVideos.length) {
        $(".recommendListKnowledge").show();
    } else {
        $(".recommendListKnowledge").hide();
    }
    $(".scrollContent").show();
    data0 = json.albums.splice(0, 6);
    data1 = json.knowledgeVideos.splice(0, 6);
    data2 = json.products.splice(0, 8);
    var imageArr = [];
    $(".scrollContent .recommendBox").html("");
    for (var htmls = "", i = 0; i < data1.length; i++) {
        htmls = '';
        htmls += '<figure class="searchBox video" data-product="' + data1[i].id + '"><div class="searchImage">';
        if (data1[i].vip == true) {
            htmls += '<div class="VIPImg"><img src="img/vip.png"></div>';
        }
        htmls += '<div class="defaultImage"><img class="result unload" data-image="' + ImageUrl(data1[i].snapshot, ".220x300") + '"id="knowledgeVideo' + loadIndex * i + '"></div></div><div class="searchText"><article><p class="content-long-to-dotted">' + data1[i].name + '</p><p>';
        if (data1[i].nowCount === 0 || typeof(data1[i].nowCount) === "undefined") {
            htmls += data1[i].totalCount + "集全";
        } else {
            htmls += "更新至" + data1[i].nowCount + "集";
        }
        htmls += '</p></article></div></figure>';
        $(".recommendListKnowledge .recommendBox").append(htmls);
    }
    if (json.knowledgeCount>6) {
            $(".recommendListKnowledge .recommendBox").append('<p class="textBottom moreRecommend">查看更多相关知识</p>');
            $(".recommendListKnowledge .textBottom").css("border-top","1px solid #d4d5d5");
            $(".recommendListKnowledge .recommendBox").css("border-bottom","0.275rem solid #f5f5f5");
        }else{
            if(json.knowledgeCount==0){
            $(".recommendListKnowledge recommendBox").css("display","none");
            }else{
            $(".recommendListKnowledge .recommendBox").append('<p class="textBottom">已经加载完成</p>');
            }           
            // $(".recommendListKnowledge .textBottom").css("border","none");
            // $(".recommendListKnowledge .recommendBox").css("border","none");
    }
    for (var htmls = "", i = 0; i < data2.length; i++) {
        htmls = '';
        htmls += '<figure class="searchBox toy" data-product="' + data2[i].productCode + '">';
        if (data2[i].storageStatus == 0) {
            htmls += '<div class="searchImage"><div class="defaultImage"><div class="stockout stockoutImageShow"><span>暂时缺货</span></div><img class="result unload" data-image="' + ImageUrl(data2[i].imgUrl, ".300x300") + '" id="toyList' + loadIndex * i + '"></div></div></div><div class="searchText"><p>' + data2[i].productName + '</p><div class="priceText"><span class="price">¥' + data2[i].vprice.toFixed(2) + '</span><span class="vip-price">VIP¥' + data2[i].svprice.toFixed(2) + '</span></div></figure>';
        } else {
            htmls += '<div class="searchImage"><div class="defaultImage"><img class="result unload" data-image="' + ImageUrl(data2[i].imgUrl, ".300x300") + '" id="toyList' + loadIndex * i + '"></div></div></div><div class="searchText"><p>' + data2[i].productName + '</p><div class="priceText"><span class="price">¥' + data2[i].vprice.toFixed(2) + '</span><span class="vip-price">VIP¥' + data2[i].svprice.toFixed(2) + '</span></div></figure>';
        }
        $(".recommendListToy .recommendBox").append(htmls);
    }
    if (json.productCount>8) {
        $(".toy").eq(6).css("border-bottom","none");
        $(".toy").eq(7).css("border-bottom","none");
        $(".recommendListToy .recommendBox").css("border-bottom","0.275rem solid #f5f5f5");
        $(".recommendListToy .textBottom").css("border-top","1px solid #d4d5d5");
        $(".recommendListToy .recommendBox").append('<p class="textBottom moreRecommend">查看更多相关玩具</p>');
    }else{
        if(json.productCount==0){
            $(".recommendListToy .recommendBox").hide();
        }else{
            $(".recommendListToy .recommendBox").append('<p class="textBottom">已经加载完成</p>');
        }
        // $(".recommendListToy .textBottom").css("border-top","none");
        // $(".recommendListToy .recommendBox").css("border-bottom","none");
    }
    for (var htmls = "", i = 0; i < data0.length; i++) {
        htmls = '';
        htmls += '<figure class="searchBox video" data-product="' + data0[i].id + '"><div class="searchImage">';
        if (data0[i].vip == true) {
            htmls += '<div class="VIPImg"><img src="img/vip.png"></div>';
        }
        htmls += '<div class="defaultImage"><img class="result unload" data-image="' + ImageUrl(data0[i].snapshot, ".220x300") + '"id="cartonVideo' + loadIndex * i + '"></div></div><div class="searchText"><article><p class="content-long-to-dotted">' + data0[i].name + '</p><p>';
        if (data0[i].nowCount === 0 || typeof(data0[i].nowCount) === "undefined") {
            htmls += data0[i].totalCount + "集全";
        } else {
            htmls += "更新至" + data0[i].nowCount + "集";
        }
        htmls += '</p></article></div></figure>';
        $(".recommendListVideo .recommendBox").append(htmls);
    }
    if (json.albumCount>6) {
        $(".recommendListVideo .recommendBox").append('<p class="textBottom moreRecommend">查看更多相关动漫</p>');
        $(".recommendListVideo .textBottom").css("border-top","1px solid #d4d5d5");
        $(".recommendListVideo .recommendBox").css("border-bottom","0.275rem solid #f5f5f5");        
    }else{
        if(json.albumCount==0){
            $(".recommendListVideo recommendBox").css("display","none");                
        }else{
            $(".recommendListVideo .recommendBox").append('<p class="textBottom">已经加载完成</p>');
        }
    }
    if (loadIndex > 1) {
        $.each($(".unload"),
        function(index) {
            var imgUrls = $(".unload").eq(index).data("image"),
            id = $(".unload")[index].id;
            if (dataTest(imgUrls) && dataTest(id)) {
                lazyLoad.asyncLoadImg(imgUrls, id);
            }
        })
    }
    pageLoadFinish = false;
}
function setItem() {
    var newHotKeysBox = hotKeysBox;
    newHotKeysBox = newHotKeysBox.join("&quot");
    localStorage.setItem("keys", newHotKeysBox);
}
var searchFunc = function() {
    getplaymuic();
        $("#search").focus();
        // $(this).attr("placeholder", "");
        $(".ManuButton").addClass("ManuLeave");
        $(".cartButton").addClass("cart_cancel");
        $(".searchIcon").hide();
        $(".alertArea").hide();
        $(".selectArea").css({
            display: "-webkit-box"
        });
        $(".bgShadow").addClass("shadowSlide");
        $(".callBox").hide();
        if ($(".scrollContent").hide()) {
            // $(".scrollContent").show();
            $("#searchImg").hide();
        };
        $(".scrollContent").hide();
        var localhotKeys = window.localStorage;
        if (localhotKeys.length == 0) {
            $(".searchVagaa").hide();
        } else {
            $(".searchVagaa").show();
            localhotKeys = localhotKeys.getItem("keys");
            localhotKeys = localhotKeys.split("&quot").splice(0,10);
            hotKeysBox = localhotKeys;
            for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
                htmls += '<span id="hotKeys' + i + '">' + localhotKeys[i] + '</span>';
            }
            $(".vagaa").html(htmls);
            // $(".scrollContent").css("background","#efefef");
            if (isIphone) {
                $(".scrollContent")[0].scrollTop = 0;
            }
        };
        $(".vagaa span").click(function() {
            var hotKeys = $(this).text();
            $("#search").val(inputSlice(hotKeys));
            var newHotKeys = [];
            hotKeysBox = localhotKeys;
            for (var j = 0; j < hotKeysBox.length; j++) {
                if (hotKeysBox[j] !== hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
            }
            newHotKeys.unshift(hotKeys);
            hotKeysBox = newHotKeys;
            setItem();
            switch ($(".selectArea span").text()) {
                case '全部':
                    jsonFilter.page = 0;
                    jsonFilter.pageSize = 8;
                    pageIndex = 0;
                    jsonFilter.searchKey = hotKeys;
                    ikanWebInterface.command(5115, JSON.stringify(jsonFilter), 'cartonLoad',47);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',bool,47);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,47);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',bool,47);
                    break;
                default:
                    break;
            }
            searchCancel();
        });
        $(".vagaa span").click(function() {
            var hotKeys = $(this).text();
            var newHotKeys = [];
            hotKeysBox = localhotKeys;
            for (var j = 0; j < hotKeysBox.length; j++) {
                if (hotKeysBox[j] !== hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
            }
            newHotKeys.unshift(hotKeys);
            hotKeysBox = newHotKeys;
            setItem();
            jsonFilter.page = 0;
            jsonFilter.pageSize = 8;
            pageIndex = 0;
            jsonFilter.searchKey = hotKeys;
            ikanWebInterface.command(5115, JSON.stringify(jsonFilter), 'cartonLoad',47);
            searchCancel();
        });
        if ($(".manuSlide").hasClass("translateInAnimation")) {
            $(".ManuButton").css({
                backgroundImage: "img/index/manu1.png"
            });
            $(".manuSlide").removeClass("translateInAnimation").addClass("translateOutAnimation");
        }
        $("body").on("touchmove", function(){$("#search").blur()});
};
var shopcartFunc = function() {
    getplaymuic();
    if($(".bgShadow").hasClass("shadowSlide")){
        searchCancel();
        if (noService) {
            console.log(noService)
            $(".scrollContent").hide();
            $("#searchImg").show();
        }
    }else{
        ikanWebInterface.back();
    }
 };
var hotKeyFunc=function  (hotType) {
    if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
        $(".hotText,.hotKeys").show();
        var hotJson=hotKeysJson[hotType];
        for (var htmls = "", i = 0; i < hotJson.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    else{
        $(".hotText,.hotKeys").hide();
    }
}
var alertDetailFunc=function(){
    getplaymuic();
    $(".alertDetail").removeClass("alertDetailSelect");
    $(this).addClass("alertDetailSelect");
    var type = $(".selectArea span").text($(".alertDetailSelect").text());
    switch (type.text()) {
        case '全部':
            $("#search").attr("placeholder","搜索动漫/玩具/知识");
            hotKeyFunc("recommendHotKeys");
            break;
        case '动漫':
            $("#search").attr("placeholder","搜索动漫");
            hotKeyFunc("albumHotKeys");
            break;
        case '玩具':
            $("#search").attr("placeholder","搜索玩具");
            hotKeyFunc("productHotKeys");
             break;
        case '知识':
            $("#search").attr("placeholder","搜索知识");
            hotKeyFunc("knowledgeHotKeys");
            break;
        default:
            break;
    }
    alertAreaOut();
};
var selectAreaFunc = function() {
    getplaymuic();
    if(!$(".bgShadow").hasClass("shadowSlide"))searchFunc();
    if ($(".alertArea").css("display") == "block") {
        $(".alertArea").css("display", "none");
        return;
    }
    $(".alertArea").show();
};
function headerClickFunc() {
    var headerOptions = {
        "#search": searchFunc,
        ".cart_cancel": shopcartFunc,
        ".alertDetail": alertDetailFunc,
        ".selectArea": selectAreaFunc,
        ".callTopIcon": callTopFunc,
        ".deleteIcon":searchFunc
    };
    return headerOptions;
}
function searchCancel() {
    $(".alertDetail").removeClass("alertDetailSelect").eq(0).addClass("alertDetailSelect");
    $(".selectArea span").text("全部");
    $("#search").attr("placeholder","搜索动漫/玩具/知识");
    $(".ManuButton").removeClass("ManuLeave");
    $(".cartButton").removeClass("cart_cancel");
    $(".searchIcon").show();
    $(".bgShadow").removeClass("shadowSlide");
    if(noService){
        $("#searchImg").show();
    }else{
        $(".scrollContent").show();
    }
    hotKeyFunc("recommendHotKeys");
    alertAreaOut();
}
function alertAreaOut() {
    $(".alertArea").hide();
} 
//判断输入框是否为空格
    var BlankSpace=true;
    function checkBlankSpace(str){
        while(str.lastIndexOf(" ")>=0){
            str = str.replace(" ","");
        }
        if(str.length == 0){
            BlankSpace=false;
        }else{
            BlankSpace=true;
        }
    }
! (function() {
    $("#search,.deleteIcon").click(function() {
        if($(this).hasClass("deleteIcon"))$("#search").val("");
        if (androidVersionNum == 0 || androidVersionNum >= 440) searchFunc.apply(this);
    })
    $("#search").blur(function() {
        // $(this).attr("placeholder", "搜索动漫/玩具/知识");
    });
    $(".cart_cancel").click(function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) shopcartFunc.apply(this);
    });
    // if (hotKeys) {
    //     $("#search").html(inputSlice(hotKeys));
    // }else{
    //     var localhotKeys = window.localStorage;
    //     $("#search").html(localhotKeys[0])
    // }
    if(isIphone){
        $("#search").on("search", function(event) {
           onSearch();     
        });
    }
    else{
        $("#search").on("keydown", function(event) {
            if(event.keyCode==13){
                onSearch();     
            }
        });
    }
   function onSearch() {
            $("input").blur();
            // $(".box").css("display", "-webkit-box");
            var hotKeys = $("#search").val();
            hotKeys=hotKeys.replace(/\"/ig,"").replace(/\\/ig,"").replace(/\//ig,"");
            $("#search").html(inputSlice(hotKeys));
            checkBlankSpace(hotKeys);
            if (hotKeys!==" "&&BlankSpace==true) {
                var newHotKeys = [];
                for (var j = 0; j < hotKeysBox.length; j++) {
                    if (hotKeysBox[j] !== hotKeys) {
                        newHotKeys.push(hotKeysBox[j]);
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox = newHotKeys;
                setItem();
            }
            console.log($(".selectArea span").text())
            switch ($(".selectArea span").text()) {
                case '全部':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}', bool,47);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}', bool,47);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,47);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}', bool,47);
                    break;
                default:
                    break;
            };
            searchCancel();
    };
    $(document).on("click", ".selectArea",function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) selectAreaFunc.apply(this);
    });
    $(window).swipe(function() {
        if ($(".alertArea").show()) {
            $(".alertArea").hide();
        }
    });
    $(document).on("click", ".alertDetail",function() {
        if (androidVersionNum == 0 || androidVersionNum >= 440) alertDetailFunc.apply(this);
    });
})()