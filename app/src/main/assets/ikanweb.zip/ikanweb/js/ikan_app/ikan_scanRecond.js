function init(json) {
    // try {
    setTimeout(function() {
            initTest(json)
        }, 100)
        // } catch (e) {
        //     document.write(e.name);
        //     document.write(e.number);
        //     document.write(e.description);
        //     document.write(e.message);
        //     document.write(json);
        // }
}
var productClear=false;
function initTest(json) {
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if (json.status && json.status == 10) {
        dead();
        $(".box").hide();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        })
        return;
    }
    if (json.status && json.status == 9 || json.trackList.length == 0) {
        $(".box").hide();
        $(".scanDateBoxFix").hide();
        $(".editButton").css({visibility:"hidden"});
        $("#scanRecondImg").css("display", "-webkit-box");
        return;
    }
    if (isIphone) {
        $(".scanDateBoxFix").addClass('scanNone');
    };
    $(".editButton").css({visibility:"visible"});
    if (!isIphone) $(".recommendListArea").css({
        minHeight: $(window).height() - 44
    })
    var data1 = json.trackList;
    $(".editButton").css({
        opacity: 1
    });
    var manuTest = true;
    recondLoad(json);
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    }, 300);
    setTimeout(function(){if(!isIphone)$(".scanDateBoxFix").show()},500);
    function callPageLoad(pageIndex) { //分页回掉函数
        var jsonString = '{"pageSize":12,"trackId":' + dataTrack + '}';
        ikanWebInterface.command(5030, jsonString, "recondLoad",44);
    }
    loadImage("scrollContent", callPageLoad); //分页函数调用
    //足迹相关逻辑
    $(".editButton").on("click", function() {
          if(androidVersionNum==0||androidVersionNum>=440)editButtonFunc.apply(this);
    });
    $(".scanDateBoxFix .watchIconBox").unbind("click").on("click",function(){
        if($(this).hasClass("watchIconBoxEdit")){
            if (!$(this).hasClass("watchIconBoxSelect")) {
                $(this).addClass("watchIconBoxSelect");
                $(".scanDatePart").eq(fixIndex).find(".watchIconBoxEdit").addClass("watchIconBoxSelect");
                $(".scanDatePart").eq(fixIndex).find(".classify").removeClass("modifyIcon").removeClass("modifySelectIcon").addClass("modifySelectIcon");
                $(".deleteButton").addClass("deleteSelect");
            } else {
                $(this).removeClass("watchIconBoxSelect");
                $(".scanDatePart").eq(fixIndex).find(".watchIconBoxEdit").removeClass("watchIconBoxSelect");
                $(".scanDatePart").eq(fixIndex).find(".classify").removeClass("modifySelectIcon").addClass("modifyIcon");
                if($(".recommendList .modifySelectIcon").length==0) $(".deleteButton").removeClass("deleteSelect");
            }
        }
    })
    $(document).on("click", ".scanSelectBox", function() {
        getplaymuic();
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var parentNode = $(this).parent();
        var watchIconBox = parentNode.find(".watchIconBox");
        if ($(this).find(".classify").hasClass("modifySelectIcon")) {
            if (watchIconBox.hasClass("watchIconBoxSelect")) {
                watchIconBox.removeClass("watchIconBoxSelect");
            }
            if(parentNode.index()==fixIndex&&$(".scanDateBoxFix .watchIconBoxEdit").hasClass("watchIconBoxSelect"))$(".scanDateBoxFix .watchIconBoxEdit").removeClass("watchIconBoxSelect");
            $(this).find(".classify").removeClass("modifySelectIcon").addClass("modifyIcon");
        }
        else{
            $(this).find(".classify").removeClass("modifyIcon").addClass("modifySelectIcon");
            if (parentNode.find(".modifyIcon").length == 0) {
                watchIconBox.addClass("watchIconBoxSelect");
                if(parentNode.index()==fixIndex)$(".scanDateBoxFix .watchIconBoxEdit").addClass("watchIconBoxSelect");
            }
        }
        console.log($(".recommendList .modifySelectIcon").length)
        if($(".recommendList .modifySelectIcon").length){
            $(".deleteButton").addClass("deleteSelect");
        }
        else{
            $(".deleteButton").removeClass("deleteSelect");
        } 
    });
    $(document).on("click", ".deleteButton", function() { //删除事件
        getplaymuic();       
        if ($(".modifySelectIcon").length == 0){
            $(".editButton").addClass("unbindClick");
            $(".J_backButton").addClass("unbindClick");
            return confirm("请选择删除", ["确定"],function(){
                 $(".editButton").removeClass("unbindClick");
                $(".J_backButton").removeClass("unbindClick");
            });
        } 
        confirm("是否确认删除",["确认","取消"],function(){
            $(this).addClass("deleteSelect");
            window.jsonArr = [];
            !(function() {
                for (var i = 0; i < $(".modifySelectIcon").length; i++) {
                    jsonArr.push($(".modifySelectIcon").eq(i).parent().data("track"));
                }
            })()
            var jsonString = {};
            jsonString.trackIds = jsonArr;
            jsonString = JSON.stringify(jsonString);
            ikanWebInterface.command(5055, jsonString, 'deleteProduct',44);
        },function(){})
        // deleteProduct('{"status":1}');
    });
    fixIndex=0;
    var preDateText="";
    $(".scanDateBoxFix span").html($(".scanDatePart").eq(0).find("span").text());
    function scanDateFixTest(){//滚动过程检测时间条状态
        if($(".scanDatePart").eq(fixIndex).find(".watchIconBoxEdit").hasClass("watchIconBoxSelect")){
            $(".scanDateBoxFix .watchIconBoxEdit").removeClass("watchIconBoxSelect").addClass("watchIconBoxSelect");
        }else{
            $(".scanDateBoxFix .watchIconBoxEdit").removeClass("watchIconBoxSelect");
        }
    }
    $(window).on("scroll",function(){
        var currentScrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        if(currentScrollTop>=0&&!productClear){
            $(".scanDateBoxFix").show();
        }else{
            $(".scanDateBoxFix").hide();
        }
        console.log(currentScrollTop+"$"+lazyLoad.pageY($(".scanDatePart .scanDate")[fixIndex+1],"scrollContent"))
        if(fixIndex+1<=$(".scanDatePart .scanDate").length-1&&currentScrollTop+44>=lazyLoad.pageY($(".scanDatePart .scanDate")[fixIndex+1])){
                if(fixIndex<=$(".scanDatePart .scanDate").length-1)
                fixIndex++;
                $(".scanDateBoxFix span").html($(".scanDatePart").eq(fixIndex).find("span").text());
                scanDateFixTest();
        }
        if(currentScrollTop+44<=lazyLoad.pageY($(".scanDatePart .scanDate")[fixIndex])){
                if(fixIndex>0)
                fixIndex--;
                $(".scanDateBoxFix span").html($(".scanDatePart").eq(fixIndex).find("span").text());
                scanDateFixTest();
        }
    })
    $(".scrollContent").on("scroll",function(){
        if($(".scrollContent")[0].scrollTop>0&&!productClear){
            $(".scanDateBoxFix").show();
        }else{
            $(".scanDateBoxFix").hide();
        }
        if(swipeType){
            if(fixIndex+1<=$(".scanDatePart .scanDate").length-1&&$(".scrollContent")[0].scrollTop>=lazyLoad.pageY($(".scanDatePart .scanDate")[fixIndex+1],"scrollContent")){
                if(fixIndex<=$(".scanDatePart .scanDate").length-1)
                fixIndex++;
                $(".scanDateBoxFix span").html($(".scanDatePart").eq(fixIndex).find("span").text());
                scanDateFixTest();
            }
        }else{
            if($(".scrollContent")[0].scrollTop<=lazyLoad.pageY($(".scanDatePart .scanDate")[fixIndex],"scrollContent")){
                if(fixIndex>0)
                fixIndex--;
                $(".scanDateBoxFix span").html($(".scanDatePart").eq(fixIndex).find("span").text());
                scanDateFixTest();
            }
        }
    })
    $(document).on("click", ".clearButton", function() { //清空事件
        getplaymuic();
        confirm("确认清空您的足迹？", ["确认", "取消"], function() {
                window.jsonArr = "clear";
                // $(".clearButton").addClass("clearSelect");
                // $(".clearButton").parent().hide();
                // $(".clearButton").removeClass("clearSelect");
                // $(".box").show();     
                ikanWebInterface.command(5058, "", 'deleteProduct',44);
                $(".topUp").removeClass("topUp").addClass("topDown");
                $(".editButton").removeClass("unbindClick");
                $(".J_backButton").removeClass("unbindClick");
            },function() {
                $(".editButton").removeClass("unbindClick");
                $(".J_backButton").removeClass("unbindClick");
            })
            $(".editButton").addClass("unbindClick");
            $(".J_backButton").addClass("unbindClick");
    })
    // $(document).on("click", ".confirmButtonArea", function() {
   
    // })
    $(document).on("click", ".scanDatePart .watchIcon", function() {
        getplaymuic();
        var classifyNode = $(this).find(".watchIconBoxEdit").parent().parent().parent().find(".classify");
        if (!$(this).find(".watchIconBoxEdit").hasClass("watchIconBoxSelect")) {
            $(".deleteButton").addClass("deleteSelect");
            $(this).find(".watchIconBoxEdit").addClass("watchIconBoxSelect");
            classifyNode.removeClass("modifyIcon").removeClass("modifySelectIcon").addClass("modifySelectIcon");
        } else {
            $(this).find(".watchIconBoxEdit").removeClass("watchIconBoxSelect");
            classifyNode.removeClass("modifySelectIcon").addClass("modifyIcon");
            if($(".recommendList .modifySelectIcon").length==0) $(".deleteButton").removeClass("deleteSelect");
        }
    });
}
function returnEdit() {
    $(".clearButton,.deleteButton").hide();
    $(".J_backButton").show();
    $(".modifyIcon").removeClass("modifyIcon");
    $(".searchBox").removeClass("scanSelectBox").addClass("track");
    $(".recommendListEdit").removeClass("recommendListEdit");
    $(".watchIconBoxEdit").removeClass("watchIconBoxEdit");
    $("footer").hide();
    $(".editButton").html("编辑");
    $(".modifySelectIcon").removeClass("modifySelectIcon");
    $(".watchIconBoxSelect").removeClass("watchIconBoxSelect");
    $(".scanDate").css({
        background: "#7FC225"
    });
}
var vipRedMarkText, redMarkText;
var creditPolicy = 0;
function returnCreditPolicy(json, id) { //积分回掉函数
    creditPolicy++;
    var num = Math.abs(JSON.parse(json).credits);
    if (id == "true") {
        vipRedMarkText = "积分：非VIP每集消耗" + num + "积分";
    } else {
        redMarkText = "积分：观看每集奖励" + num + "积分";
    }
    if (creditPolicy == 2) {
         // var jsonString = '{"pageSize":12,"page":0}';
            ikanWebInterface.docReady("");
    }
}
var jsonString = '{"trackList":[{"trackDate":"2015年11月20日","sortNum":1,"tracks":[{"albumCount":36,"trackType":2,"trackId":29599,"ikanPrice":0,"vprice":0,"albumId":3,"imageSrc":"http://webimg.ikan.cn/test/ximages/album/f1f5e39b-6eaa-4ca3-8c75-2be02742a380.png","videoId":2797,"trackName":"巴啦啦小魔仙之彩虹心石","userId":10081948,"nowCount":0,"creatTime":"2015年11月20日","prodTypeName":"科幻魔法","vip":false,"age":"5~12岁以上"},{"productCode":1002025,"nowCount":0,"creatTime":"2015年11月20日","trackType":1,"trackId":29363,"ikanPrice":7575,"vprice":7575,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/695ee9f4-3ea3-4d31-b3a9-c6a8eeaa0ebb.jpg","trackName":"奥迪双钻 可动玩偶系列 雅塔莱斯召唤腰带（电影版）","vip":false,"userId":10081948},{"productCode":1002026,"nowCount":0,"creatTime":"2015年11月20日","trackType":1,"trackId":29158,"ikanPrice":227,"vprice":217,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/10af508b-0dd2-4d2d-a0c2-e275803d3836.jpg","trackName":"奥迪双钻 可动玩偶系列 超级天地雷霆剑（电影版）","vip":false,"userId":10081948},{"productCode":1002027,"nowCount":0,"creatTime":"2015年11月20日","trackType":1,"trackId":29141,"ikanPrice":113,"vprice":113,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/cf69f56d-6171-47fe-93d6-100de3f2d6a3.jpg","trackName":"奥迪双钻 可动玩偶系列 电光雷霆剑（电影版）","vip":false,"userId":10081948},{"productCode":1002035,"nowCount":0,"creatTime":"2015年11月20日","trackType":1,"trackId":29131,"ikanPrice":56,"vprice":39,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/54209358-4577-45ef-82e7-2f8753d176aa.jpg","trackName":"AULDEY 奥迪双钻 铠甲勇士拿瓦vs青山欧克瑟搪胶套装 ","vip":false,"userId":10081948}]},{"trackDate":"2015年11月19日","sortNum":1,"tracks":[{"productCode":2002062,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29066,"ikanPrice":344,"vprice":249,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/21372bb2-270e-474f-aeb1-d4e360be06e4.jpg","trackName":"芭比 珍藏版 假日芭比 3岁以上","vip":false,"userId":10081948},{"productCode":2002004,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29065,"ikanPrice":103,"vprice":92,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/ead010e8-f007-40dd-b6a5-51dd3d49f797.jpg","trackName":"芭比 幸福婚礼 芭比新郎肯 3岁以上","vip":false,"userId":10081948},{"productCode":1004014,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29064,"ikanPrice":47,"vprice":47,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/46d842c9-1d75-46cf-ab51-02515c39cfbe.jpg","trackName":"奥迪双钻 火力少年王5悠悠球 赤焰战虎V","vip":false,"userId":10081948},{"productCode":1003025,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29063,"ikanPrice":113,"vprice":94,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/bdd78844-9989-4df9-a625-dd7836037d2a.jpg","trackName":"奥迪双钻 巴啦啦小魔仙4 音符之谜 美雪高级弦音魔法提琴 3岁以上","vip":false,"userId":10081948},{"productCode":1002042,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29062,"ikanPrice":77,"vprice":64,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/6931d2c2-a8e1-493b-b4ea-439103573fcb.jpg","trackName":"AULDEY 奥迪双钻 铠甲勇士拿瓦 武器系列 狂鸢烈弓 ","vip":false,"userId":10081948},{"albumCount":91,"trackType":2,"trackId":29061,"ikanPrice":0,"vprice":0,"albumId":467,"imageSrc":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","videoId":22468,"trackName":"小马宝莉","userId":10081948,"nowCount":0,"creatTime":"2015年11月19日","prodTypeName":"科幻魔法","vip":false,"age":"3~12岁以上"},{"productCode":1002035,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29060,"ikanPrice":56,"vprice":39,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/54209358-4577-45ef-82e7-2f8753d176aa.jpg","trackName":"AULDEY 奥迪双钻 铠甲勇士拿瓦vs青山欧克瑟搪胶套装 ","vip":false,"userId":10081948},{"productCode":2003025,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29049,"ikanPrice":275,"vprice":193,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/97a4fed3-c77f-4118-bb65-d22b786093be.jpg","trackName":"风火轮 赛车轨道玩具 电动都市汽车广场","vip":false,"userId":10081948},{"albumCount":120,"trackType":2,"trackId":29048,"ikanPrice":0,"vprice":0,"albumId":164,"imageSrc":"http://webimg.ikan.cn/test/ximages/album/9365aec8-acfc-404d-aac4-c9c066a68632.png","videoId":3481,"trackName":"海绵宝宝","userId":10081948,"nowCount":120,"creatTime":"2015年11月19日","prodTypeName":"亲情友谊","vip":false,"age":"3~12岁以上"},{"productCode":1002027,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29044,"ikanPrice":113,"vprice":113,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/cf69f56d-6171-47fe-93d6-100de3f2d6a3.jpg","trackName":"奥迪双钻 可动玩偶系列 电光雷霆剑（电影版）","vip":false,"userId":10081948},{"productCode":1002026,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29043,"ikanPrice":227,"vprice":217,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/10af508b-0dd2-4d2d-a0c2-e275803d3836.jpg","trackName":"奥迪双钻 可动玩偶系列 超级天地雷霆剑（电影版）","vip":false,"userId":10081948},{"productCode":1002025,"nowCount":0,"creatTime":"2015年11月19日","trackType":1,"trackId":29035,"ikanPrice":7575,"vprice":7575,"imageSrc":"http://webimg.ikan.cn/test/ximages/eb/product/695ee9f4-3ea3-4d31-b3a9-c6a8eeaa0ebb.jpg","trackName":"奥迪双钻 可动玩偶系列 雅塔莱斯召唤腰带（电影版）","vip":false,"userId":10081948},{"albumCount":46,"trackType":2,"trackId":29011,"ikanPrice":0,"vprice":0,"albumId":454,"imageSrc":"http://webimg.ikan.cn/test/ximages/album/bf7601a7-4691-4182-a0e9-f7a1008defca.png","videoId":21744,"trackName":"云彩面包2","userId":10081948,"nowCount":0,"creatTime":"2015年11月19日","prodTypeName":"亲情友谊","vip":false,"age":"3~12岁"}]}]}';
var preDate = "",
    dataTrack = "";
var back=function(){
    if($(this).hasClass("unbindClick")) return
    getplaymuic();
    ikanWebInterface.back();
};
var editButtonFunc=function(){
    getplaymuic();
    if($(this).hasClass("unbindClick")) return;
    if ($(".modifyIcon").length === 0) {
        if ($(".classify").length == 0) return false;
        $(".classify").addClass("modifyIcon");
        $(".deleteButton").removeClass("deleteSelect")
        $(".recommendListArea").addClass("recommendListEdit");
        $(".watchIconBox").addClass("watchIconBoxEdit");
        $(".searchBox").addClass("scanSelectBox").removeClass("track");
        $("footer").css({
            display: "-webkit-box"
        });
        $(".scanDate").css({
            background: "#ff4747"
        });
        $(this).html("完成");
        $(".deleteButton,.clearButton").show();
        return;
    }
    returnEdit();
}
$(".deleteButton").touchdown(function(){
    if($(this).hasClass("deleteSelect")) $(this).addClass("deleteTouch")
},function(){
    if($(this).hasClass("deleteSelect")) $(this).removeClass("deleteTouch")
})
function headerClickFunc(){
        var headerOptions={
            ".J_backButton":back,
            ".editButton":editButtonFunc,
            ".callTopIcon":callTopFunc
        };
        return headerOptions;
}
$(function() {
    ikanWebInterface.getCreditPolicy("PLAYVIPVIDEO", "true");
    ikanWebInterface.getCreditPolicy("PLAYVIDEO", "false");
     // init(jsonString);
    $(".editButton").touchdown(function() {
        $(this).css({
            "color": "#7FC225"
        })
    }, function() {
        $(this).css({
            "color": "#595758"
        })
    })
    $(document).fix("click", ".track", function() { //卡通动漫列表去的点击事件
        if ($(this).hasClass("toy")) {
            ikanWebInterface.startIkanScheme('ikan://product/' + $(this).data("id"),' ',44);
            return;
        }
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',44);
    }, {
        "commOnce": true
    });
    $(".J_backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".J_backButton").click(function() {
            
            if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);      
    });

});

function deleteProduct(data) {
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if(data.status !== 10){
        if (data.status !== 9) {
            $(".deleteSelect").removeClass("deleteSelect");
            if (jsonArr !== "clear" && jsonArr.length > 0) {
                confirm("删除成功");
                if ($(".watchIconBoxSelect").length){
                    $(".scanDatePart .watchIconBoxSelect").parent().parent().parent().remove();
                    $(".scanDateBoxFix .watchIconBox").removeClass("watchIconBoxSelect");
                } 
                $(".modifySelectIcon").parent().remove();
                $(".scanDateBoxFix span").html($(".recommendList .scanDate span").eq(fixIndex).text());
            } else if (jsonArr == "clear") {
                confirm("清空成功");
                $("#scanRecondImg").css("display", "-webkit-box");
                $(".scanDateBoxFix").hide();
                $(".clearButton").parent().hide();
                $(".scrollContent").html("");
            }
            if ($(".recommendList .classify").length == 0) {
                window.productClear=true;
                $("#scanRecondImg").css("display", "-webkit-box");
                $(".scanDateBoxFix").hide();
                $(".scrollContent").hide();
                $(".clearButton").parent().hide();
                $(".editButton").css({visibility:"hidden"});
            }
        } else {
            confirm("删除失败");
        }
    }else{
        confirm("内容加载失败，请检查网络...");
    }
}
var loadBottomHtml = $("#loadBottom").html();

function recondLoad(data) { //分页回掉函数
    var productArr = [];
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5030, jsonString, "recondLoad",44);
        });
        return;
    }
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    if (data.status && data.status == 9 || (data.trackList.length == 0 && pageIndex == 0)) {
        $("#scanRecondImg").css("display", "-webkit-box");
        $(".editButton").css({visibility:"hidden"});
        $(".scanDateBoxFix").hide();
        return;
    };
    $(".editButton").css({visibility:"visible"});
    data = data.trackList;
    var dataLength = 0;
    !(function() {
        for (var i = 0; i < data.length; i++) {
            for (var j = 0; j < data[i].tracks.length; j++) {
                dataLength++;
            }
        }
    })()
    if (dataLength > 0) {
        if (!isIphone) {
            setTimeout(function(){$(".scanDateBoxFix").show();},500)
        };
        if (dataLength < 12) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var productArr = [];

        function cartonsInformation(now, total) {
            var numInfo = (now == 0) || (typeof(now) == "undefined") ? total + "集全" : "更新至" + now + "集";
            return numInfo;
        }



        function imgContent(type) {
            if (type == 2) {
                return '<img src="img/search-video.png">';
            }
            return '<img src="img/search-book.png">';
        }

        function undefinedTest() {
            return
        }
        var appendHtmlToy = $(".toyContent").html();
        var appendHtmlVideo = $(".videoContent").html();
        var appendHtmlDate = $(".scanDateBox").html();

        function scanHtml() {
            var appendHtml;
            if (this.trackType == 1) { //玩具
                var imgageSrc = ImageUrl(this.imageSrc, ".292x292");
                var indexSize = this.size ? "型号" + this.size : "";
                appendHtml = appendHtmlToy.replace('{{imageSrc}}', imgageSrc)
                    .replace('{{index}}', this.index)
                    .replace('{{unloadProxy}}', "unload")
                    .replace('{{dataId}}', this.productCode)
                    .replace('{{trackName}}', this.trackName)
                    .replace('{{size}}', indexSize)
                    .replace('{{trackId}}', this.trackId)
                    .replace('{{ikanPrice}}', parseFloat(this.ikanPrice))
                    .replace('{{vprice}}', parseFloat(this.vprice));
            } else {
                var imgageSrc = ImageUrl(this.imageSrc, ".292x398");
                if (this.vip) {
                    var vipText = vipRedMarkText,
                        vipMarkText = "vipMarkShow";
                } else {
                    var vipText = redMarkText,
                        vipMarkText = "";
                }
                appendHtml = appendHtmlVideo.replace('{{imageSrc}}', imgageSrc)
                    .replace('{{index}}', this.index)
                    .replace('{{unloadProxy}}', "unload")
                    .replace('{{trackName}}', this.trackName)
                    .replace('{{dataId}}', this.albumId)
                    .replace('{{age}}', this.age)
                    .replace('{{trackId}}', this.trackId)
                    .replace('{{imgContent}}', imgContent(this.trackType))
                    .replace('{{prodTypeName}}', this.prodTypeName)
                    .replace('{{creditContent}}', vipText)
                    .replace('{{vipMarkShow}}', vipMarkText)
                    .replace('{{ablumContent}}', cartonsInformation(this.nowCount, this.albumCount));
            }
            dataTrack = this.trackId;
            productArr.push([imgageSrc, "scanRecond" + this.index]);
            return appendHtml;
        }
        var index = 0;
        for (var i = 0; i < data.length; i++) {
            if (data[i].trackDate !== preDate) {
                preDate = data[i].trackDate;
                var appendHtml = appendHtmlDate.replace('{{trackDate}}', preDate);
                var preDataContainer = '<section class="scanDatePart">' + appendHtml + '</section>';
                $(".recommendList").append(preDataContainer);
            }
            var preDataContainer = $(".scanDatePart").eq(-1);
            for (var j = 0; j < data[i].tracks.length; j++) {
                index++;
                data[i].tracks[j].index = pageIndex * 12 + index;
                var appendHtml = scanHtml.call(data[i].tracks[j]);
                preDataContainer.append(appendHtml);
                if($(".scanDateLast").length&&$(".scanDateLast").find(".watchIconBoxEdit").hasClass("watchIconBoxSelect")){//
                    $(".scanDateLast").find(".classify").removeClass("modifySelectIcon").removeClass("modifyIcon").addClass("modifySelectIcon");
                }
                $(".scanDateLast").removeClass("scanDateLast");
                $(".scanDatePart").eq(-1).addClass("scanDateLast");
            }
        }
        if (typeof(verticle) !== "undefined") {
            vertical.refresh();
        }
        if (pageIndex > 0) {
            // debug(productArr.length)
            for (var i = 0; i < productArr.length; i++) {
                if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                    lazyLoad.asyncLoadImg(productArr[i][0], productArr[i][1]);
                }
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}