var jsonString='{"ageRange":{"tagList":[{"tagId":1,"tagValue":"0-3岁","groupId":13,"tagName":"年龄"},{"tagId":2,"tagValue":"3-6岁","groupId":13,"tagName":"年龄"},{"tagId":3,"tagValue":"6岁+","groupId":13,"tagName":"年龄"}],"groupId":13,"cname":"年龄"},"recommendHotKeys":["乐高"," 樱桃小丸子","巴拉拉小魔仙","乐高","樱桃小丸子","变形金刚"],"categorys":[{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/c6c9d5ce-6f69-4857-9537-119ec1929efc.png","categoryName":"亲情友谊","albumCategoryId":2},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/fc14905a-9f12-47c8-ae4c-861b26f9aca0.png","categoryName":"冒险励志","albumCategoryId":3},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/a0d0f440-4f0b-4a8c-8851-83ea218ce920.png","categoryName":"科幻魔法","albumCategoryId":4},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/806d382c-b164-448f-82b6-6e756f329734.png","categoryName":"运动竞技","albumCategoryId":7},{"isSelected":"0","imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/7b76e693-ac30-4f97-89ac-02d095e5968d.png","categoryName":"宝贝综艺","albumCategoryId":9}],"albums":[{"totalNumber":202,"nowCount":0,"specialType":0,"name":"战斗王之飓风战魂Ⅱ发干的人个个梵蒂冈梵蒂冈地方干豆腐的风格大方认个梵蒂冈电饭锅电饭锅","typeName":"运动竞技","id":376,"vip":false,"totalCount":40,"snapshot":"http://webimg.ikan.cn/test/ximages/album/ab9c6014-eb23-4642-8abb-e333e3309c62.png","age":"6~12岁"},{"totalNumber":202,"nowCount":120,"specialType":0,"name":"海绵宝宝","typeName":"亲情友谊","id":164,"vip":false,"totalCount":120,"snapshot":"http://webimg.ikan.cn/test/ximages/album/9365aec8-acfc-404d-aac4-c9c066a68632.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"小马宝莉","typeName":"科幻魔法","id":467,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png","age":"3岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"铠甲勇士","typeName":"科幻魔法","id":8,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/c5dfca0d-2711-4aaa-886d-1e051ea57d59.png","age":"6岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"草原豆思之夺宝奇兵","typeName":"亲情友谊","id":404,"vip":false,"totalCount":30,"snapshot":"http://webimg.ikan.cn/test/ximages/album/4caa5551-6393-4a5a-bc1f-482e4a2969b4.png","age":"3~8岁"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"电击小子","typeName":"冒险励志","id":5,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/cb650e2c-0c7b-4460-abc8-471ddb10d847.png","age":"5~12岁"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"巴啦啦小魔仙之彩虹心石","typeName":"知识","id":3,"vip":false,"totalCount":36,"snapshot":"http://webimg.ikan.cn/test/ximages/album/f1f5e39b-6eaa-4ca3-8c75-2be02742a380.png","age":"5岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"巴啦啦小魔仙之奇迹舞步","typeName":"科幻魔法","id":262,"vip":true,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/86380b73-c15b-4e8f-9d6f-6cbea272f752.png","age":"5岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"铁甲威虫","typeName":"冒险励志","id":279,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/95880362-4385-4623-a930-e24e12678120.png","age":"6~12岁"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"果宝特攻","typeName":"冒险励志","id":6,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/3074904d-5db5-4ca8-99ca-c7e20e29086b.png","age":"6岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"超兽武装之仁者无敌","typeName":"科幻魔法","id":4,"vip":false,"totalCount":33,"snapshot":"http://webimg.ikan.cn/test/ximages/album/00b714a4-24da-4132-abb4-909e4ee8165b.png","age":"6岁以上"},{"totalNumber":202,"nowCount":0,"specialType":0,"name":"钢铁飞龙","typeName":"科幻魔法","id":278,"vip":false,"totalCount":50,"snapshot":"http://webimg.ikan.cn/test/ximages/album/14bb2269-93f2-45fa-815f-87f009510154.png","age":"6~12岁"}],"searchKey":"","productHotKeys":["火力少年","乐高","喜羊羊","乐高","乐高","乐高","乐高","如比","费雪","托马斯"],"title":"热播动漫","sortVos":[{"sortName":"综合","sortId":0},{"sortName":"热播","sortId":1},{"sortName":"最新","sortId":2}],"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生","炮炮向前冲之荒岛求生"],"sortId":1,"hotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生","炮炮向前冲之荒岛求生"],"filterTags":[{"tagList":[{"tagId":6,"tagValue":"大陆","groupId":24,"tagName":"地域"},{"tagId":7,"tagValue":"港台","groupId":24,"tagName":"地域"},{"tagId":8,"tagValue":"日韩","groupId":24,"tagName":"地域"},{"tagId":9,"tagValue":"欧美","groupId":24,"tagName":"地域"}],"groupId":24,"cname":"地域","sortNum":1},{"tagList":[{"tagId":10,"tagValue":"儿歌","groupId":25,"tagName":"主题"},{"tagId":12,"tagValue":"拼音","groupId":25,"tagName":"主题"},{"tagId":13,"tagValue":"数学","groupId":25,"tagName":"主题"},{"tagId":14,"tagValue":"英语","groupId":25,"tagName":"主题"},{"tagId":15,"tagValue":"美术","groupId":25,"tagName":"主题"},{"tagId":16,"tagValue":"双语","groupId":25,"tagName":"主题"},{"tagId":11,"tagValue":"国学","groupId":25,"tagName":"主题"},{"tagId":17,"tagValue":"习惯","groupId":25,"tagName":"主题"},{"tagId":18,"tagValue":" 安全","groupId":25,"tagName":"主题"},{"tagId":19,"tagValue":"亲子","groupId":25,"tagName":"主题"},{"tagId":20,"tagValue":"冒险","groupId":25,"tagName":"主题"},{"tagId":21,"tagValue":"童话","groupId":25,"tagName":"主题"},{"tagId":22,"tagValue":"励志","groupId":25,"tagName":"主题"},{"tagId":23,"tagValue":"校园","groupId":25,"tagName":"主题"},{"tagId":24,"tagValue":"真人","groupId":25,"tagName":"主题"},{"tagId":25,"tagValue":"运动","groupId":25,"tagName":"主题"},{"tagId":26,"tagValue":"竞技","groupId":25,"tagName":"主题"},{"tagId":27,"tagValue":"魔法","groupId":25,"tagName":"主题"},{"tagId":28,"tagValue":"搞笑","groupId":25,"tagName":"主题"},{"tagId":29,"tagValue":"智慧","groupId":25,"tagName":"主题"},{"tagId":30,"tagValue":"早教","groupId":25,"tagName":"主题"},{"tagId":31,"tagValue":"友谊","groupId":25,"tagName":"主题"},{"tagId":32,"tagValue":"百科","groupId":25,"tagName":"主题"},{"tagId":33,"tagValue":"勇气","groupId":25,"tagName":"主题"},{"tagId":34,"tagValue":"梦想","groupId":25,"tagName":"主题"}],"groupId":25,"cname":"主题","sortNum":2},{"tagList":[{"tagId":4,"tagValue":"男孩","groupId":15,"tagName":"性别"},{"tagId":5,"tagValue":"女孩","groupId":15,"tagName":"性别"}],"groupId":15,"cname":"性别","sortNum":0}],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉","朵拉","朵拉","朵拉","朵拉","朵拉","朵拉","朵拉","朵拉"]}';
function init(json) {
    // try {
    // initTest(json)
    // } catch (e) {
    //     document.write(e.name);
    //     document.write(e.number);
    //     document.write(e.description);
    //     document.write(e.message);
    //     document.write(json)
    // }
    setTimeout(function() {
        initTest(json);
    }, 100);
}
function initTest(json) { //初始化页面方法
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    if (json.title) {
        $(".heaerTitle").html(json.title);
        if(json.title!="热播动漫") $(".categoryDetailButton").eq(2).find("span").html(json.title);
    }
    if (json.status && json.status == 9) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        $(".box").hide();
        return;
    }
    debug(json);
    $(".scrollContent").show();
    jsonFilter.searchKey = json.searchKey;
    if (json.sortId) jsonFilter.sortId = json.sortId;
    if (json.categoryId) jsonFilter.categoryId = json.categoryId;
    if (jsonFilter.sortId == 1) {
        $(".categoryDetailButton").eq(0).find("span").html("热播");
    }
    $("#search").val(json.searchKey);
    var backBut = true,
        cartBat = true,
        performanceBut = true;
    productLoad(json);
    $(".box").hide();
    $(".scrollContent").animate({
        opacity: 1
    }, 300);
    function callPageLoad(pageIndex) { //分页回掉函数
        jsonFilter.pageSize = 12;
        jsonFilter.page = pageIndex;
        ikanWebInterface.command(5073, JSON.stringify(jsonFilter), "productLoad",11);
    }
    loadImage("scrollContent", callPageLoad);
    var markPostionArr = ["1.5rem", "5.34rem", "9.3rem", "13.4rem"];
    var categoryContentObj = $("div[class^='categoryContent']");
    var categoryInterval = null;
    var preIndex = 0;
    $(".categoryDetailButton").unbind("click").bind("click", function(event) {
        clearTimeout(categoryInterval);
        getplaymuic();
        $(".callTopButton").hide();
        $(".bg").removeClass("translateHide").css("opacity", 1);
        // $(".categoryArea").css("border-bottom", "1px solid #f8f8f8");
        eventPrevent = true;
        var categoryIndex = $(this).index();
        if($(".translateShow").length==0){
             $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
        if (categoryIndex == 2 && $(".categoryMainListSelect").hasClass("unlimitedCategories")) {
            $(".categoryMark").attr("src","img/categoryMarkHs.png")
        }else{
            $(".categoryMark").attr("src","img/categoryMark.png")
        }
        if (categoryContentObj.eq(categoryIndex).hasClass("translateShow")) {
            eventPrevent = false;
            $(".bgColor").hide();
            $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
            $(".categoryMark").hide();
            categoryInterval=setTimeout(function(){$(".categoryContentArea").hide();},500)
            categoryContentObj.eq(categoryIndex).removeClass("translateShow").addClass("translateHide");
            $(".categoryIcon").attr("src", "img/640_16.png");
            $(".categoryIcon1").attr("src", "img/640_11.png");
            if (jsonFilter.filterInfo) {
                $(".categoryIcon1").attr("src", "img/640_06.png");
            }
            return;
        }
        $(".bgColor").show();
        $(".categoryMark").css({
            left: markPostionArr[categoryIndex]
        }).show();
        var categoryContentEval = "categoryContent" + categoryIndex + "()";
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        if (jsonFilter.filterInfo) {
            $(".categoryIcon1").attr("src", "img/640_06.png");
        }
        $(".categoryIcon").eq(categoryIndex).attr("src", "img/640_14.png");
        eval(categoryContentEval);
        $(".manuArea").hide();
        if (categoryIndex == 3) {
            $(".categoryIcon1").attr("src", "img/640_06.png");
            setTimeout(function() {
                $(".manuArea").css({
                    display: "-webkit-box"
                }).removeClass("translateHide");
            }, 0);
        }
        if ($(".translateShow").length) {
            categoryContentObj.eq(preIndex).removeClass("translateShow");
        } else {
            $(".categoryContentArea").show().css({
                opacity: 1
            });
        }
        categoryContentObj.removeClass("translateHide").removeClass("translateShow").addClass("translateHide").eq(categoryIndex).removeClass("translateHide").addClass("translateShow");
        preIndex = categoryIndex;
        if ($(".categoryContentArea").css("display") == "block") {
            $(".bg").unbind("click").click(function() {
                getplaymuic();
                $(".categoryMark").hide();
                $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
                eventPrevent = false;
                $(".bgColor").hide();
                $(".translateShow").removeClass("translateShow").addClass("translateHide");
                setTimeout(function(){$(".categoryContentArea").hide()},300)
                $(".categoryIcon").attr("src", "img/640_16.png");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }else{
                    $(".categoryIcon1").attr("src", "img/640_11.png");
                }
            });
        }
    });
    $(".manuArea div").eq(0).click(function() { //重置按钮
        getplaymuic();
        $(".filterSelectContentDetail").removeClass("filterSelectedButton");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        $.each($(".content-long-to-dotted"), function(index, item) {
            if ($(item).data("define")) {
                var itemDefine = $(item).data("define");
                $(item).html(itemDefine).data("content", itemDefine);
            }
        });
    });
    $(".manuArea div").eq(1).click(function() {
            getplaymuic();
            $(".manuArea").hide();
            selectCategoryOut();
            jsonInfo = {};
            var groupArr = [];
            if ($(".filterSelectedButton").length) {
                $.each($(".filterArea"), function(index, item) {
                    var filterSelectedDetail = $(item).find(".filterSelectedButton");
                    if (filterSelectedDetail.length > 0) {
                        var keys = filterSelectedDetail.eq(0).data("keys");
                        if (typeof $(item).data("group") !== "undefined") {
                            var groupElement = {};
                            groupElement.groupId = $(item).data("group");
                            groupElement[keys] = filterSelectedDetail.data("id");
                            groupArr.push(groupElement);
                        } else {
                            $.each(filterSelectedDetail, function(indexs, items) {
                                jsonInfo[keys] = $(items).data("id");
                            });
                        }
                    }
                });
                if (groupArr.length) {
                    jsonInfo.groupIds = groupArr;
                }
                jsonFilter.filterInfo = jsonInfo;
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                if (typeof(jsonFilter.filterInfo) !== "undefined") {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                $(".box").css("display", "-webkit-box");
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',11);
            } else {
                delete jsonFilter.filterInfo;
                // jsonFilter.filterInfo = jsonInfo;
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',11);
            }
        });
        //综合排序
    function categoryContent0() {
        if ($(".rankCategoryArea").length == 0) {
            data1 = json.sortVos;
            var categoryHtml = "";
            for (var i = 0; i < data1.length; i++) {
                categoryHtml += '<div class="rankCategoryArea" data-id=' + data1[i].sortId + ' data-group=' + data1[i].groupId + '><span>' + data1[i].sortName + '</span><img src="img/index/categorySelect.png" alt=""></div>';
            }
            $(".categoryContentDetail1").html(categoryHtml);
            if($(".categoryDetailButton").eq(0).find("span").text()=="热播"){  
                $(".rankCategoryArea span").eq(1).addClass("selectCategory").parent().find("img").show();
            }else{
                $(".rankCategoryArea span").eq(0).addClass("selectCategory").parent().find("img").show();
            }
            $(".rankCategoryArea").click(function() {
                getplaymuic();
                $(".rankCategoryArea span").removeClass("selectCategory").parent().find("img").hide();
                $(this).find("span").addClass("selectCategory").parent().find("img").show();
                $(".categoryDetailButton span").eq(0).html($(this).find("span").html());
                selectCategoryOut();
                jsonFilter.sortId = $(this).data("id");
                $(".box").css("display", "-webkit-box");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',11);
            });
        }
    }
    function categoryContent1() {
        if ($(".babyAgeSelectDetail").length == 0) {
            var dataGroup = json.ageRange.groupId;
            var data2 = json.ageRange.tagList;
            var categoryHtml = '<div class="babyAgeSelectDetail noLimitedAge">不限</div>';
            for (var i = 0; i < data2.length; i++) {
                categoryHtml += '<div class="babyAgeSelectDetail" data-id=' + data2[i].tagId + '>' + data2[i].tagValue + '</div>';
            }
            $(".babyAgeSelect").html(categoryHtml);
            $(".babyAgeSelectDetail").click(function() {
                getplaymuic();
                $(".babyAgeSelectDetail").removeClass("selectCategory");
                $(this).addClass("selectCategory");
                if ($(this).hasClass("noLimitedAge")) {
                    delete jsonFilter.ageRange;
                    $(".categoryDetailButton span").eq(1).html("年龄");
                } else {
                    $(".categoryDetailButton span").eq(1).html($(this).text());
                    var ageRange = {};
                    ageRange.groupId = dataGroup;
                    ageRange.tagId = $(this).data("id");
                    jsonFilter.ageRange = ageRange;
                }
                selectCategoryOut();
                var ageRange = {};
                ageRange.groupId = dataGroup;
                ageRange.tagId = $(this).data("id");
                jsonFilter.ageRange = ageRange;
                $(".box").css("display", "-webkit-box");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',11);
            });
        }
    }
    function categoryContent2() {
        if ($(".categoryMainListDetail").length == 0) {
            data3 = json.categorys;
            var categoryHtml = '<div class="categoryMainListDetail unlimitedCategory"><img src="img/more.png" alt=""><span>不限</span></div>';
            var selectStyle = "";
            for (var i = 0; i < data3.length; i++) {
                selectStyle = "";
                if (data3[i].isSelected == 1) {
                    selectStyle = " categoryMainListSelect";
                }
                categoryHtml += '<div class="categoryMainListDetail' + selectStyle + '" data-id=' + data3[i].albumCategoryId + '><img src=' + data3[i].imageSrc + ' alt=""><span>' + data3[i].categoryName + '</span></div>';
            }
            $(".categoryMainList").html(categoryHtml);
            $(".categoryMainListDetail").click(function() {
                getplaymuic();
                if ($(this).hasClass("unlimitedCategory")) {
                    $(".categoryMark").attr("src","img/categoryMarkHs.png")
                    $(".categoryDetailButton span").eq(2).html("分类");
                    $(".heaerTitle").html("全部分类");
                    delete jsonFilter.categoryId;
                } else {
                    $(".categoryMark").attr("src","img/categoryMark.png")
                    $(".categoryDetailButton span").eq(2).html($(this).text());
                    jsonFilter.categoryId = $(this).data("id");
                    $(".heaerTitle").html($(this).text());
                }
                $(".categoryMainListDetail").removeClass("categoryMainListSelect");
                $(this).addClass("categoryMainListSelect");
                selectCategoryOut();
                var categorys = {};
                $(".box").css("display", "-webkit-box");
                if (jsonFilter.filterInfo) {
                    $(".categoryIcon1").attr("src", "img/640_06.png");
                }
                jsonFilter.pageSize = 12;
                jsonFilter.page = 0;
                pageIndex = 0;
                ikanWebInterface.command(5073, JSON.stringify(jsonFilter), 'productLoad',11);
            });
        }
    }
    function categoryContent3() {
        eventPrevent = false;
        if ($(".filterSelectContentDetail").length == 0) {
            var categoryHtml = "";
            var sortNumFiter = {};
            data4 = json.filterTags;
            var data4Keys = Object.keys(data4); //获得品牌等的key；
            for (var i = 0; i < data4Keys.length; i++) { //对keys进行遍历
                categoryButtonHtml = "",
                    dataDetail = data4[data4Keys[i]]; //便利得到的品牌等的对象或数组
                if (dataDetail instanceof Array) { //如果是数组就继续遍历获得对象
                    for (var k = 0; k < dataDetail.length; k++) { //继续遍历该数组
                        dataDetailCont = dataDetail[k]; //获取到颜色等对象，输入创建筛选内容函数
                        categoryHtmlAdd(dataDetailCont);
                    }
                } else {
                    categoryHtmlAdd(dataDetail);
                }
                function categoryHtmlAdd(dataDetails) { //创建筛选内容函数，dataDetails为相应的颜色或者品牌对象
                        categoryHtml = "";
                        var selectId = false;
                        var groupIdHtml = "";
                        for (var detailkeys in dataDetails) { //统一变量
                            if (detailkeys.indexOf("select") > -1) {
                                selectId = dataDetails[detailkeys];
                            }
                            if (detailkeys == "groupId") { //如果长度大于2，则是标签有groupId
                                groupIdHtml = 'data-group=' + dataDetails.groupId;
                            }
                            if (dataDetails[detailkeys] instanceof Array) { //如果是数组，那么该keys就是列表
                                taglist = detailkeys;
                            }
                        }
                        //在下面对获取到的特定变量进行同等操作
                        var dataDetailArr = dataDetails[taglist];
                        for (var keys in dataDetailArr[0]) { //统一变量
                            if ("groupId" in dataDetailArr[0]) {
                                tagId = "tagId";
                                tagValue = "tagValue";
                            } else {
                                if (keys.indexOf("Id") > -1) {
                                    tagId = keys;
                                } else {
                                    tagValue = keys;
                                }
                            }
                        }
                        for (var categoryButtonHtml = "", j = 0; j < dataDetailArr.length; j++) {
                            var selectStyle = (selectId && dataDetailArr[j][tagId] == selectId) ? " filterSelectedButton" : "";
                            categoryButtonHtml += '<div class="filterSelectContentDetail' + selectStyle + '" data-id=' + dataDetailArr[j][tagId] + ' data-keys=' + tagId + '><span>' + dataDetailArr[j][tagValue] + '</span></div>'
                        }
                        categoryHtml += '<section class="filterArea"' + groupIdHtml + '><div class="filterSelectTitle"><span class="filterTitleName">' + dataDetails.cname + ':</span><p class="content-long-to-dotted">不限</p><img src="img/textButton1.png" alt=""></div><div class="filterSelectContent">' + categoryButtonHtml + '</div></section>'
                        sortNumFiter[dataDetails.sortNum] = categoryHtml;
                    }
                    //立即调用
            }
            for (var i = 0, categoryHtml = ""; i in sortNumFiter; i++) {
                categoryHtml += sortNumFiter[i];
            }
            $(".categoryContentDetail4").html(categoryHtml);
            var buttonHeight = $(window).width() / 10;
            $.each($(".filterSelectContent"), function(index, item) {
                ! function(_this) {
                    setTimeout(function() {
                        var thisHeight = $(_this).height();
                        $(_this).data("height", thisHeight);
                        $(_this).css({
                            height: buttonHeight
                        });
                        if (thisHeight < buttonHeight * 1.5) $(_this).parent().find("img").addClass("triggleHide").hide();
                    }, 10);
                }(this);
            });
            $(".filterSelectTitle").click(function() {
                $(".categoryContentDetail4").css({
                    "overflow": "hidden"
                });
                setTimeout(function() {
                    $(".categoryContentDetail4").css({
                        "overflow": "auto"
                    });
                }, 600);
                getplaymuic();
                if ($(this).find("img").hasClass("triggleHide")) return;
                $(this).find("img").toggleClass("zhuan");
                var dataHeight,
                    _this = $(this).parent().find(".filterSelectContent");
                dataHeight = $(this).parent().find(".filterSelectContent").data("height");
                dataHeight = dataHeight - 0;
                _this.data("height", Math.ceil(_this.height())).height(dataHeight);
            });
            $(".filterSelectContentDetail").click(function() {
                getplaymuic();
                var contentLong = $(this).parent().parent().find(".content-long-to-dotted");
                var contentLongHtml = contentLong.data("content"),
                    buttonContent = $(this).find("span").html(),
                    contentLongText;
                    debug(buttonContent)
                if ($(this).hasClass("filterSelectedButton")) {
                    $(this).removeClass("filterSelectedButton");
                    var buttonContentPlace = contentLongHtml.indexOf(buttonContent);
                    if (buttonContentPlace > -1) {
                        if (buttonContentPlace > 0) {
                            buttonContent = "&nbsp;" + buttonContent;
                        }
                        if (contentLongHtml == buttonContent) {
                            contentLongHtml = contentLong.data("define");
                            contentLong.html(contentLongHtml).data("content", contentLongHtml);
                            return;
                        }
                        contentLongHtml = contentLongHtml.split(buttonContent);
                        contentLongHtml = contentLongHtml.join("");
                        contentLong.html(contentLongHtml).data("content", contentLongHtml);
                    }
                    contentLong.html(contentLong.data("define"));
                    return;
                }
                $(this).parent().find(".filterSelectContentDetail").removeClass("filterSelectedButton");
                $(this).addClass("filterSelectedButton");
                if (contentLong.html().indexOf("不限") > -1) {
                    contentLong.data("define", contentLong.html()).html($(this).find("span").html()).data("content", $(this).find("span").html());
                    return;
                }
                // contentLongText = contentLongHtml + "&nbsp;" + buttonContent;
                // if (contentLong.html() !== contentLong.data("content")) {
                //     return;
                // }
                // if (contentLong.html().indexOf("不限") > -1) {
                //     contentLong.data("define", contentLong.html());
                // }
                debug(buttonContent);
                contentLong.html(buttonContent);
            });
        }
    }
    function selectCategoryOut() {
        eventPrevent = false;
        $(".bgColor").hide();
        $(".translateShow").removeClass("translateShow").addClass("translateHide");
        $(".categoryMark").hide();
        $(".categoryArea").css("border-bottom", "1px solid rgba(217,217,217,0.7);");
        $(".categoryIcon").attr("src", "img/640_16.png");
        $(".categoryIcon1").attr("src", "img/640_11.png");
        setTimeout(function() {
            $(".categoryContentArea").hide();
        }, 500);
    }
}
var jsonFilter = {};
var back=function(){
    getplaymuic();
    ikanWebInterface.back(); 
};
var shoppingCart=function(){
    getplaymuic();
    ikanWebInterface.startIkanScheme('ikan://download/',' ',11);
};
function headerClickFunc(){
    var headerOptions={
        ".J_backButton":back,
        ".J_shoppingCart":shoppingCart,
        ".callTopIcon":callTopFunc
    };
    return headerOptions;
}
$(function() {
    // init(jsonString);
    $(".J_backButton").touchdown(function() {
        $(this).css({
            "background": "url(img/returnButton1.png) no-repeat center",
            "background-size": 36
        });
    }, function() {
        $(this).css({
            "background": "url(img/returnButton.png) no-repeat center",
            "background-size": 36
        });
    });
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".J_shoppingCart").touchdown(function() {
        $(this).css({
            "background": "url(img/index/downloada.png) no-repeat center",
            "background-size":"36px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/index/download1.png) no-repeat center",
            "background-size":"36px"
        });
    });
    $(".J_backButton").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)back.apply(this);
    });
    //逻辑todo购物车
    $(".J_shoppingCart").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)shoppingCart.apply(this);
    });
    $(document).fix("click", ".mangaAreaDetail", function() {
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',11);
    }, {
        "commOnce": true
    });
});
var vipRedMarkText;
var redMarkText;
var creditPolicy = 0;
ikanWebInterface.getCreditPolicy("PLAYVIPVIDEO", "true");
ikanWebInterface.getCreditPolicy("PLAYVIDEO", "false");
function returnCreditPolicy(json, id) { //积分回掉函数
    creditPolicy++;
    var num = Math.abs(JSON.parse(json).credits);
    if (id == "true") {
        vipRedMarkText = "积分：非VIP每集消耗" + num + "积分";
    } else {
        redMarkText = "积分：观看每集奖励" + num + "积分";
    }
    if (creditPolicy == 2) {
        ikanWebInterface.docReady("");
    }
}
function backTop() {
    if (isIphone) {
        return $(".scrollContent")[0].scrollTop = 0;
    }
    document.body.scrollTop = 0;
}
var loadBottomHtml = $("#loadBottom").html();
var searchNullFlag=false;
function productLoad(data) {
    loadIndex++;
    data = typeof(data) == "string" ? JSON.parse(data) : data;
    if (data.status && data.status == 10) {
        if (pageIndex == 0) {
            dead();
            $(".dead").unbind("click").on("click",
                function() {
                    getplaymuic();
                    ikanWebInterface.reloadPage();
                    $(".bgShadow").hide();
                    // ikanWebInterface.command(5069, JSON.stringify(jsonFilter), 'productLoad');
                    $(".box").show();
                    $(".dead").hide();
                });
            return;
        }
        $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
        if(pageIndex>0)pageIndex--;
        pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click", function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5073, jsonString, "productLoad",11);
        });
        return;
    }else{
        $(".dead").hide();
        $(".scrollContent").show();
     }
    $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
    $(".box").hide();
    if (data.status && data.status == 9 || (data.albums.length == 0 && pageIndex == 0)) {
        $("#searchImg").show();
        $(".scrollContent").hide();
        return;
    }
    if (data.searchNullFlag||searchNullFlag) { //相似搜索结果添加部分
        backTop();
        $(".sampleSearchArea").show();
        $(".cartoonArea").css({
            "margin-top": 0
        });
        searchNullFlag=true;
    } else {
        $(".sampleSearchArea").hide();
        $(".cartoonArea").css({
            "margin-top": "1.9rem"
        });
    }
    data = data.albums;
    $("#searchImg").hide();
    $(".scrollContent").show();
    var productArr = [];
    if (data.length) {
        if (data.length < pageSize) {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        var myTemplate = Handlebars.compile($("#table-template").html());
        Handlebars.registerHelper("imageGrayTest", function(v1, v2) {
            if (v1 == true) {
                return v2;
            } else {
                return "";
            }
        });
        Handlebars.registerHelper("imgUrlRechange", function(value, index) {
            var imgUrls = ImageUrl(value, ".220x300");
            var index = initSize+loadIndex * pageSize + index;
            if (loadIndex > 0) {
                index = "cartoon" + index;
                productArr.push([imgUrls, index]);
            }
            return imgUrls;
        });
        Handlebars.registerHelper("indexChange", function(index) {
            return index = initSize+loadIndex * pageSize + index;
        });
        Handlebars.registerHelper("getAlbumCredits", function(isVip) { //积分函数
            var isVipText = isVip ? vipRedMarkText : redMarkText;
            return isVipText;
        });
        Handlebars.registerHelper("cartonsInformation", function(nowCount, totalCount) {
            var numInfo = (nowCount == 0) || (typeof(nowCount) == "undefined") ? totalCount + "集全" : "更新至" + nowCount + "集";
            return numInfo;
        });
        if (pageIndex == 0) {
            backTop();
            $('.cartoonArea').html(myTemplate(data));
        } else {
            $('.cartoonArea').append(myTemplate(data));
        }
        if (typeof(vertical) !== "undefined") {
            vertical.refresh();
        }
        if (loadIndex > 1) {
            for (var i = 0; i < productArr.length; i++) {
                if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                    ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
                }
            }
        }
    } else {
        $("#loadBottom").html("已经加载完成");
        pageBottomFinish = false;
    }
    pageLoadFinish = true;
    $(".loader").addClass("bottomImageRotate");
}
    