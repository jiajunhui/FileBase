function init(json) {
    // try{
    setTimeout(function() {
            initTry(json);

        }, 100);
        // }catch(e){
        //  document.write(e.name);
        //  document.write(e.number);
        //  document.write(e.description);
        //  document.write(e.message);
        //  document.write(json);
        // }

}
var hotKeysBox=[];
var indexmark="cart";
function initTry(json) {
    hotKeysJson={};
    var BOX = '<div class="refreshBox"><div class="refreshImageBox"><img src="img/loading.png" alt="" class="refreshImage"></div><p class="refreshText">下拉刷新</p></div><div class="callTopButton"><img src="img/top.png" class="callTopIcon"></div>';
    var HTML = '<div class="bannerArea"><div class="swiper-container"><div class="swiper-wrapper bannerWrapper"></div><div class="swiper-pagination"></div></div></div><section class="cartonsArticleArea"><img src="img/cartonnews.png" alt="" class="cartonsArticleTitle"><div class="cartonsArticleContent"><div class="swiper-wrapper"></div></div></section><div class="marginTop1"></div><section class="cartonsPostArea"><div class="cartonsBigPost"><img  alt="" data-image={{largeCartonImage}} class="unload" id="largePost"><div class="gradient"></div>{{cartonTextBig}}</div><div class="cartonsleftListbox"><div class="cartonsMiddlePost"><img  alt="" data-image={{middleCartonImage}} class="unload" id="middlePost"><div class="gradient"></div>{{cartonTextMiddle}}</div><div class="cartonsSmallPost smallBanner"><img  alt="" data-image={{smallCartonImage}} class="unload" id="smallPost"><div class="gradient"></div>{{cartonTextSmall}}</div><div class="cartonsSmallPost videoContent" data-id={{idData}}><img  alt="" data-image={{lastCartonImage}} class="unload" id="lastWatchPost"><div class="continueWatch">立即观看</div></div></div></section><div class="marginTop"></div><section class="cartonsArea"><div class="cartonsTitle">热播动漫</div><div class="cartonsContent"></div></section><div id="loadBottom"><div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span></div>';
    var search='<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
    search.innerHTML = "";
    $(".bgShadow").html(search);
    var obj = $(".scrollContent");
    var obj1 = $(".callBox");
    $("*", obj).add([obj]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $("*", obj1).add([obj1]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $("*", search).add([obj1]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $.event.remove(window);
    obj.innerHTML = "";
    $(".callBox").append(BOX);
    $(".scrollContent").prepend(HTML).show();
    initParam();
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    if(json.albumHotKeys)hotKeysJson.albumHotKeys=json.albumHotKeys;
    if(json.productHotKeys)hotKeysJson.productHotKeys=json.productHotKeys;
    if(json.knowledgeHotKeys)hotKeysJson.knowledgeHotKeys=json.knowledgeHotKeys;
    if(json.recommendHotKeys)hotKeysJson.recommendHotKeys=json.recommendHotKeys;
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    if (json.status && json.status == 9) {
        $(".box").hide();
        return confirm(json.err, ["确定"]);
    }
    if (json.hotAlbums.length % 3 !== 0) {
        json.hotAlbums.pop();
        if (json.hotAlbums.length % 3 !== 0) {
            json.hotAlbums.pop();
        }
    }
    data1 = json.categorys;
    data2 = json.recommends;
    data5 = json.hotAlbums;
    data9 = json.albumHotKeys;
    for (var htmls = "", i = 0; i < data1.length; i++) { //header菜单点击下拉的活动区域
        htmls += '<div class="activeManu" data-category=' + data1[i].albumCategoryId + '><img src="' + data1[i].imageSrc + '" alt=""><span>' + data1[i].categoryName + '</span></div>';
    }
    $(".manuSlide").html(htmls);
    try {
        for (var htmls = "", i = 0; i < data2.length; i++) {
            htmls += '<div class="swiper-slide" data-id="' + data2[i].id + '" data-url="' + data2[i].redirect + '"><img class="unload" data-image="' + ImageUrl(data2[i].img, ".640x240") + '" alt="" id="bannerCart' + i + '"></div>';
        }
        jsonString=htmls;
        $(".bannerWrapper").html(htmls);
    } catch (e) {
        $(".bannerArea").css({
            overflow: "hidden",
            height: 0
        });
    }
    var data3 = json.animeInfos;
    for (var htmls = "", i = 0; i < data3.length; i++) { //上下自动滚动的文字区域
        htmls += '<p class="swiper-slide cartonsSwipeText" data-url=' + data3[i].infoUrl + ' data-id=' + data3[i].infoId + '>' + data3[i].content + '</p>';
    }
    cartoonSwipe=htmls;
    $(".cartonsArticleContent .swiper-wrapper").html(htmls);
    if (data9) {
        for (var htmls = "", i = 0; i < data9.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+data9[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    if(data9 == null){
        $(".hotKeys").hide()
        $(".hotText").hide()
    }
    if(json.pushAlbum)data8=json.pushAlbum;
    try {
        htmls = $(".cartonsPostArea").html();
        htmls = htmls.replace("{{cartonTextBig}}", getCartonText.call(json.largePoster))
            .replace("{{largeCartonImage}}", ImageUrl(json.largePoster.img, ".290x360"))
            .replace("{{cartonTextMiddle}}", getCartonText1.call(json.seconedPosters[0]))
            .replace("{{middleCartonImage}}", ImageUrl(json.seconedPosters[0].img, ".340x180"))
            .replace("{{cartonTextSmall}}", getCartonText2.call(json.thirdPosters[0]))
            .replace("{{smallCartonImage}}", ImageUrl(json.thirdPosters[0].img, ".166x170"))
            .replace("{{lastCartonImage}}", ImageUrl(json.pushAlbum.snapshot, ".220x300"))
            .replace("{{idData}}", json.pushAlbum.id);
        $(".cartonsPostArea").html(htmls); //大中小卡通海报区域
    } catch (e) {
        $(".cartonsPostArea").css({
            "height": 0,
            "overflow": "hidden"
        });
    }
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".activeManu").touchdown(function() {
        $(this).css({
            "background": "#f5f5f5"
        });
    }, function() {
        $(this).css({
            "background": "#ffffff"
        });
    });
    $(".ManuButton").touchdown(function() {
        $(this).css({
            "background": "url(img/index/manuButtona.png) no-repeat center",
            "backgroundSize":"32px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/index/manuButton.png) no-repeat center",
            "backgroundSize":"32px"
        });
    });
    $(".cartButton").touchdown(function() {
        $(this).addClass("cartButtonGreen");
    }, function() {
        $(this).removeClass("cartButtonGreen");
    });
    $(".activeManu").unbind("click").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)activeManuFunc.apply(this);
    });

    swiperInit();

    function getCartonText() { //获取海报区域的文字
        return '<div class="cartonsInformation" data-url="' + this.url + '" data-id=' + this.id + '><p>' + slices(this.postertitle, 8) + '</p><p>' + slices(this.postersubtitle, 10) + '</p></div>';
    }

    function getCartonText1() { //获取海报区域的文字
        return '<div class="cartonsInformation" data-url="' + this.url + '" data-id=' + this.id + '><p>' + slices(this.postertitle, 9) + '</p><p>' + slices(this.postersubtitle, 12) + '</p></div>';
    }

    function getCartonText2() { //获取海报区域的文字
        return '<div class="cartonsInformation" data-url="' + this.url + '" data-id=' + this.id + '><p>' + slices(this.postertitle, 5) + '</p><p>' + slices(this.postersubtitle, 7) + '</p></div>';
    }
    cartonLoad(json);
    $(".scrollContent").animate({
        opacity: 1
    }, 200);
    setTimeout(function() {
        $(".box").hide();
    }, 300);

    function callPageLoad(pageIndex) { //分页回掉函数
        var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
        ikanWebInterface.command(5035, jsonString, "cartonLoad",10);
    }
    loadImage("scrollContent", callPageLoad);
    //分页函数调用
    // $(".videoContent img").css("min-height","1rem")
        ikanWebInterface.getLastPlayRecord("0");
    lastPlayed = false;
    $(".bannerArea .swiper-slide").unbind("click").fix("click", function() {
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = parseInt($(this).data("swiper-slide-index"))+1;
         var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "",10,'ANIME_IMAGE_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',10,'ANIME_IMAGE_'+num);
    }, {
        "commOnce": true
    });
    // function commScheme() { //大小海报的公共点击函数

    //     var _this = $(this).find(".cartonsInformation");
    //     if (!_this.length) {
    //         var thisId = typeof($(this).data("id")) == "undefined" ? "" : "/" + $(this).data("id");
    //         ikanWebInterface.startIkanScheme('ikan://video/' + videoId + thisId);
    //         return;
    //     }
    //     var schemeUrl = _this.data("url");
    //     if (schemeUrl.indexOf("{") > -1) {
    //         schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
    //             return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
    //         });
    //         schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
    //     }
    //     // console.log(jsonString)
    //     ikanWebInterface.command(5125,jsonString, "cartonLoad",10,locations);
    //     ikanWebInterface.startIkanScheme(schemeUrl,' ',10,locations);
    // }


    $(document).fix("click",".cartonsBigPost,.cartonsMiddlePost,.smallBanner", function() {
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this).find(".cartonsInformation");
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
            if ($(this).hasClass("cartonsBigPost")) {
                var jsonString = '{"statisticsId":' + $(".cartonsBigPost .cartonsInformation").data("id") + '}';
                var locations = "ANIME_POSTER_FIRST";
                ikanWebInterface.command(5125,jsonString, "",10,locations);
                ikanWebInterface.startIkanScheme(schemeUrl,' ',10,locations);
            }
            if ($(this).hasClass("cartonsMiddlePost")) {
                var jsonString = '{"statisticsId":' + $(".cartonsMiddlePost .cartonsInformation").data("id") + '}';
                var locations = "ANIME_POSTER_SECOND_1";
                ikanWebInterface.command(5125,jsonString, "",10,locations);
                ikanWebInterface.startIkanScheme(schemeUrl,' ',10,locations);
            }
            if ($(this).hasClass("smallBanner")) {
                var jsonString = '{"statisticsId":' + $(".smallBanner .cartonsInformation").data("id") + '}';
                var locations = "ANIME_POSTER_THIRD_1";
                ikanWebInterface.command(5125,jsonString, "",10,locations);
                ikanWebInterface.startIkanScheme(schemeUrl,' ',10,locations);
            }
    }, {
        "commOnce": true
    });


    // $(".cartonsBigPost").unbind("click").fix("click", function() {
    //     if (swiper&&swiper.animating) return;
    //     if (!clickUsed && !lazyLoad.parentFixed(event)) return;
    //     locations = "ANIME_POSTER_FIRST";
    //     jsonString = '{"statisticsId":' + $(".cartonsBigPost .cartonsInformation").data("id") + '}';
    //     commScheme.call(this);
    // }, {
    //     "commOnce": true
    // });
    // $(".cartonsMiddlePost").unbind("click").fix("click", function() {  
    //     if (swiper&&swiper.animating) return;
    //     if (!clickUsed && !lazyLoad.parentFixed(event)) return;
    //     locations = 'ANIME_POSTER_SECOND_1';
    //     jsonString = '{"statisticsId":' + $(".cartonsMiddlePost .cartonsInformation").data("id") + '}';
    //     commScheme.call(this);
    // }, {
    //     "commOnce": true
    // });
    // $(".smallBanner").unbind("click").fix("click", function() {
    //     if (swiper&&swiper.animating) return;
    //     if (!clickUsed && !lazyLoad.parentFixed(event)) return;
    //     locations = 'ANIME_POSTER_THIRD_1';
    //     jsonString = '{"statisticsId":' + $(".smallBanner .cartonsInformation").data("id") + '}';
    //     commScheme.call(this);
    // }, {
    //     "commOnce": true
    // });
    if (!isIphone) {
        ikanWebInterface.updateSearchState("1",false);
    }
    
}
var hotKeysJson={};
var jsonString = '{"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"categorys":[{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/c6c9d5ce-6f69-4857-9537-119ec1929efc.png","categoryName":"亲情友谊","albumCategoryId":2},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/fc14905a-9f12-47c8-ae4c-861b26f9aca0.png","categoryName":"冒险励志","albumCategoryId":3},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/a0d0f440-4f0b-4a8c-8851-83ea218ce920.png","categoryName":"科幻魔法","albumCategoryId":4},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/806d382c-b164-448f-82b6-6e756f329734.png","categoryName":"运动竞技","albumCategoryId":7},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/7b76e693-ac30-4f97-89ac-02d095e5968d.png","categoryName":"宝贝综艺","albumCategoryId":9}],"thirdPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/a7ff3384-af7c-431e-b86f-9ec381ddef34.png","postertitle":"智慧岛","description":"","sortNum":57,"id":146,"type":0,"postersubtitle":"一起动动脑","url":"ikan://album/298"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/b6f35fa1-2fee-4402-901b-f4a82db9058d.png","postertitle":"巴啦啦动漫","description":"","sortNum":61,"id":190,"type":0,"postersubtitle":"巴拉拉小魔仙","url":"ikan://web/ikan_activityList.html#{command:5049,params:{page:0,pageSize:15}}"}],"largePoster":{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/d00f1107-42cf-42a8-93bc-fc9820a035ac.png","postertitle":"啊！雾霾来啦","description":"","sortNum":82,"id":131,"type":0,"postersubtitle":"防火 防盗 防雾霾！","url":"ikan://web/ikan_specialSubject.html#{command:5060,params:{topicId:40}}"},"productHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"seconedPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/2af3bd0f-91c3-43ba-9628-1de3244ac820.png","postertitle":"经济学园","description":"","sortNum":64,"id":141,"type":0,"postersubtitle":"一起去学习~","url":"ikan://album/444"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/c4d719e8-9cdf-4803-852e-b581c2af5962.png","postertitle":"情商养成","description":"","sortNum":68,"id":189,"type":0,"postersubtitle":"十大幼儿情商养成动画","url":"ikan://album/3"}],"pushAlbum":{"totalNumber":0,"nowCount":0,"specialType":0,"name":"超兽武装之仁者无敌","id":4,"type":0,"vip":false,"totalCount":33,"snapshot":"http://webimg.ikan.cn/test/ximages/album/00b714a4-24da-4132-abb4-909e4ee8165b.png"},"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"hotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"recommends":[{"redirect":"ikan://album/376","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/83b16b36-40ba-48c5-acf7-837cc4ff0bc7.png","id":1299,"sort":1},{"redirect":"ikan://album/18","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/1209c291-5e1a-4423-8ad4-bc95cd781fbf.png","id":1298,"sort":2},{"redirect":"ikan://album/430","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/45c9930e-0080-488d-83a7-0eed11ebd1b7.png","id":1294,"sort":3},{"redirect":"ikan://album/222","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/32f5402b-2a78-474a-ab6d-f8b49087e06c.png","id":1293,"sort":4}],"hotAlbums":[{"totalNumber":0,"nowCount":0,"specialType":0,"name":"巴啦啦小魔仙之奇迹舞步","id":262,"type":0,"vip":true,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/86380b73-c15b-4e8f-9d6f-6cbea272f752.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"巴啦啦小魔仙之彩虹心石","id":3,"type":0,"vip":false,"totalCount":36,"snapshot":"http://webimg.ikan.cn/test/ximages/album/f1f5e39b-6eaa-4ca3-8c75-2be02742a380.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"七巧板","id":261,"type":3,"vip":false,"totalCount":134,"snapshot":"http://webimg.ikan.cn/test/ximages/album/b84950e3-b751-4313-8827-2a5ccd94f3f3.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"蓝猫淘气3000问 星际大战","id":402,"type":0,"vip":false,"totalCount":384,"snapshot":"http://webimg.ikan.cn/test/ximages/album/3fe7337f-77d2-44f7-b928-5695febcae44.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"战斗王之飓风战魂Ⅱ发干的人个个梵蒂冈梵蒂冈地方干豆腐的风格大方认个梵蒂冈电饭锅电饭锅","id":376,"type":0,"vip":false,"totalCount":40,"snapshot":"http://webimg.ikan.cn/test/ximages/album/ab9c6014-eb23-4642-8abb-e333e3309c62.png"},{"totalNumber":0,"nowCount":120,"specialType":0,"name":"海绵宝宝","id":164,"type":0,"vip":false,"totalCount":120,"snapshot":"http://webimg.ikan.cn/test/ximages/album/9365aec8-acfc-404d-aac4-c9c066a68632.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"小马宝莉","id":467,"type":0,"vip":false,"totalCount":91,"snapshot":"http://webimg.ikan.cn/test/ximages/album/463891f5-563a-4ecc-ba39-ae7fc0b2be7e.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"铠甲勇士","id":8,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/c5dfca0d-2711-4aaa-886d-1e051ea57d59.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"草原豆思之夺宝奇兵","id":404,"type":0,"vip":false,"totalCount":30,"snapshot":"http://webimg.ikan.cn/test/ximages/album/4caa5551-6393-4a5a-bc1f-482e4a2969b4.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"电击小子","id":5,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/cb650e2c-0c7b-4460-abc8-471ddb10d847.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"铁甲威虫","id":279,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/95880362-4385-4623-a930-e24e12678120.png"},{"totalNumber":0,"nowCount":0,"specialType":0,"name":"果宝特攻","id":6,"type":0,"vip":false,"totalCount":52,"snapshot":"http://webimg.ikan.cn/test/ximages/album/3074904d-5db5-4ca8-99ca-c7e20e29086b.png"}],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉"],"animeInfos":[{"infoId":11,"infoUrl":"ikan://album/604","content":"《森林好伙伴之快乐生活》"},{"infoId":8,"infoUrl":"ikan://album/606","content":"《魔力课堂之踢踢和奇奇》上线啦"}]}';
var LastPlayUrl = false,
    lastPlayed = true,
    lastRunTime = 0;

function returnLastPlayRecord(LastPlay) {
    // debug(LastPlay);
    if(!isIphone)swiperInit();
    touchClick=false;
    lastRunTime++;
    if (LastPlay === "null") {
        if(data8){
            LastPlay={};
            LastPlay.albumCover=data8.snapshot;
            LastPlay.albumId=data8.id;
            $(".continueWatch").html("立即观看");
        }else{
            return;
        }
    }else{
        LastPlay = JSON.parse(LastPlay);
        $(".continueWatch").html("继续观看");
    }
    var imgurl = ImageUrl(LastPlay.albumCover, ".220x300");
    $("#lastWatchPost").removeClass("opacityAnimationLoad").data("image", imgurl);
    ikanWebInterface.asyncLoadImg(imgurl, "lastWatchPost");
    $(".videoContent").data("id", LastPlay.albumId);
}
$(function() {
    // init(jsonString);
    ikanWebInterface.docReady('');
    $(document).on("click",".emptyHistory",function(){
        confirm("确认清空搜索历史记录？", ["确认", "取消"], function() {
                $(".searchVagaa").hide();
                hotKeysBox=[];
                localStorage.clear();
            }),
            function() {

            }
    })
    $(document).on("click",".hotKeys span",function(){
        var hotKeys=$(this).text();
        $("#search").val(hotKeys);
        if ($(this).val()!==" ") {
            var newHotKeys=[];
            for(var j=0;j<hotKeysBox.length;j++){
                if (hotKeysBox[j]!==hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
            }
            newHotKeys.unshift(hotKeys);
            hotKeysBox=newHotKeys;
            setItem();
        }
        switch ($(".selectArea span").text()) {
            case '全部':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',10);
                break;
            case '动漫':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',10);
                break;
            case '玩具':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',10);
                 break;
            case '知识':
                ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',10);
                break;
            default:
                break;
        }
        searchCancel();
    })
    $(document).on("click",".cartonsArticleContent .swiper-slide",function() {
        getplaymuic();
        if (swiper&&swiper.animating) return;
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = $(this).data("id");
        var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "",10,'ANIME_INFO_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',10,'ANIME_INFO_'+num);
    });
    $(document).fix("click", ".bannerArea .swiper-slide", function() {
        var _this = $(this);
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
        var num = parseInt($(this).data("swiper-slide-index"))+1;
         var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
        ikanWebInterface.command(5125, jsonString, "",10,'ANIME_IMAGE_'+num);
        ikanWebInterface.startIkanScheme(schemeUrl,' ',10,'ANIME_IMAGE_'+num);
    }, {
        "commOnce": true
    });
    $(document).fix("click", ".videoContent", function() {
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
        ikanWebInterface.command(5125, jsonString, "",10);
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',10);
    }, {
        "commOnce": true
    });
    $(document).fix("click", ".cartonsContentDetail", function() { //卡通动漫列表去的点击事件
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',10);
    }, {
        "commOnce": true
    });
    
});
var loadBottomHtml = '<div class="load-container load8"><div class="loader"></div></div><span>爱看儿童乐园加载中</span>';

function cartonLoad(data) { //分页回掉函数
        var productArr = [];
        data = typeof(data) == "string" ? JSON.parse(data) : data;
        if (data.status && data.status == 10) {
            $("#loadBottom").html("网络出现状况，点击重新加载").addClass("loadBottom");
            if(pageIndex>0)pageIndex--;
            pageLoadFinish = true;
        $(".loadBottom").unbind("click").on("click",function() {
            getplaymuic();
            pageIndex++;
            var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
            ikanWebInterface.command(5035, jsonString, "cartonLoad",10)
        });
            return
        }
        $("#loadBottom").html(loadBottomHtml).removeClass("loadBottom");
        if (data.status && data.status == 9) {
            $("#searchImg").show();
            return;
        }
        data = data.hotAlbums;
        if (data.length % 3 !== 0) {
            data.pop();
            if (data.length % 3 !== 0) {
                data.pop();
            }
        }
        if (data.length) {
            if (data.length < pageSize) {
                $("#loadBottom").html("已经加载完成");
                pageBottomFinish = false;
            }
            var myTemplate = Handlebars.compile($("#table-template").html());
            Handlebars.registerHelper("cartonsInformation", function(nowCount, totalCount) {
                var numInfo = (nowCount == 0) || (typeof(nowCount) == "undefined") ? totalCount + "集全" : "更新至" + nowCount + "集";
                return numInfo;
            });
            Handlebars.registerHelper("imageGrayTest", function(v1, v2) {
                if (v1 == true) {
                    return v2;
                } else {
                    return "";
                }
            });
            Handlebars.registerHelper("imgUrlRechange", function(value, index) {
                var imgUrls = ImageUrl(value, ".196x267");
                // var imgUrls = ImageUrl(value, ".204x280");
                var index = initSize+pageIndex * pageSize + index;
                if (pageIndex > 0) {
                    index = "cartonVideo" + index;
                    productArr.push([imgUrls, index]);
                }
                return imgUrls;
            });
            Handlebars.registerHelper("indexChange", function(index) {
                return index = initSize+pageIndex * pageSize + index;
            });
            if (pageIndex == 0) {
                $('.cartonsContent').html(myTemplate(data));
            } else {
                $('.cartonsContent').append(myTemplate(data));
            }
            if (typeof(vertical) !== "undefined") {
                vertical.refresh();
            }
            if (pageIndex > 0) {
                for (var i = 0; i < productArr.length; i++) {
                    if (dataTest(productArr[i][0]) && dataTest(productArr[i][1])) {
                        ikanWebInterface.asyncLoadImg(productArr[i][0], productArr[i][1]);
                    }
                }
            }
        } else {
            $("#loadBottom").html("已经加载完成");
            pageBottomFinish = false;
        }
        pageLoadFinish = true;
        $(".loader").addClass("bottomImageRotate");
    }
    /*返回顶部*/
    // 搜索部分js逻辑
    var manuFunc=function(){
        getplaymuic();
        if (!$(".manuSlide").hasClass("block")) {
            eventPrevent = true;
            $(".activeManu").css({
                "background": "#ffffff"
            });
            $(".bgShadowBOX").show();
            $(".manuSlide").addClass("block").show();
            return;
        }
        eventPrevent = false;
        $(".bgShadowBOX").hide();
        $(".manuSlide").removeClass("block").hide();
    };
    function setItem(){
        var newHotKeysBox=hotKeysBox;
        newHotKeysBox=newHotKeysBox.join("&quot");
        localStorage.setItem("keys",newHotKeysBox);
    }
    var currentScroll=0;
    var searchFunc=function(){
        currentScroll=$("body")[0].scrollTop;
        var _this=this;
        setTimeout(function(){
        getplaymuic();
        if (!isIphone) {
            ikanWebInterface.updateSearchState("1",true);
        }
        if(!$(".bgShadow").hasClass("shadowSlide")) setTimeout(function(){$(".bgShadow")[0].scrollTop = 0},100);
        $(".bgShadow").addClass("shadowSlide");
        $(".callBox").hide();
        var localhotKeys= window.localStorage;
        if (localhotKeys.length==0) {
            $(".searchVagaa").hide();
            hotKeysBox=[];
        }else{
            $(".searchVagaa").show();
            localhotKeys=localhotKeys.getItem("keys");
            localhotKeys=localhotKeys.split("&quot").splice(0,10);
            hotKeysBox=localhotKeys;
            for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
                htmls += '<span id="hotKeys'+i+'">'+localhotKeys[i]+'</span>';
            }
            $(".vagaa").html(htmls);
            // $(".scrollContent").css("background","#efefef");
        } 
        $(".vagaa span").click(function(){
            var hotKeys=$(this).text();
            var newHotKeys=[];
            for(var j=0;j<hotKeysBox.length;j++){
                if (hotKeysBox[j]!==hotKeys) {
                    newHotKeys.push(hotKeysBox[j]);
                }
            }
            newHotKeys.unshift(hotKeys);
            hotKeysBox=newHotKeys;
            setItem();
            switch ($(".selectArea span").text()) {
                case '全部':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',10);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',10);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',10);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',10);
                    break;
                default:
                    break;
            }
            // ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
            searchCancel();
        });
        // $(_this).attr("placeholder","");
        $(".alertArea").removeClass("block").hide();
        if (!$(".ManuButton").hasClass("ManuLeave")) {
            $(".ManuButton").addClass("ManuLeave");
            $(".label").css("margin-left", "10px");
            $(".cartButton").addClass("cart_cancel");
            $(".searchIcon").hide();
            $(".selectArea").css({
                display: "-webkit-box"
            }).show();
            if ($(".manuSlide").hasClass("block")) {
                $(".manuSlide").removeClass("block").hide();
            }
            $(".bgShadowBOX").hide();
        } 
    },200);
        // $("#search").focus();
        $("body").on("touchmove", function(){$("#search").blur()});  
    }
    var activeManuFunc=function(){
        getplaymuic();
        $(this).css({
            "background": "#f5f5f5"
        });
        $(".manuSlide").removeClass("block").hide().children().css("background", "#fff");
        $(".bgShadowBOX").hide();
        eventPrevent = false;
        var schemeContent = 'ikan://web/ikan_cartoonList.html#{"command":5059,"params":{"page":0,"pageSize":12,"categoryId":' + $(this).data("category") + ',"title":"' + $(this).find("span").html() + '"}}';
        ikanWebInterface.startIkanScheme(schemeContent,' ',10);
    }
    var downFunc=function(){
        if ($(this).hasClass("cart_cancel")) {
            return;
        }
        if($(".manuSlide").hasClass("block")){
                $(".manuSlide").removeClass("block").hide();
                $(".bgShadowBOX").hide()
                eventPrevent = false;
        }
        ikanWebInterface.startIkanScheme('ikan://download/',' ',10);
    };
    var hotKeyFunc=function  (hotType) {
        if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
            $(".hotText,.hotKeys").show();
            var hotJson=hotKeysJson[hotType];
            for (var htmls = "", i = 0; i < hotJson.length; i++) {
                htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
            }
            $(".hotKeys").html(htmls);
        }
        else{
            $(".hotText,.hotKeys").hide();
        }
    }
    var alertDetailFunc=function(){
        getplaymuic();
        $(".alertDetail").removeClass("alertDetailSelect");
        $(this).addClass("alertDetailSelect");
        var type = $(".selectArea span").text($(".alertDetailSelect").text());
       switch (type.text()) {
           case '全部':
               $("#search").attr("placeholder","搜索动漫/玩具/知识");
               hotKeyFunc("recommendHotKeys");
               break;
           case '动漫':
               $("#search").attr("placeholder","搜索动漫");
               hotKeyFunc("albumHotKeys");
               break;
           case '玩具':
               $("#search").attr("placeholder","搜索玩具");
               hotKeyFunc("productHotKeys");
                break;
           case '知识':
               $("#search").attr("placeholder","搜索知识");
               hotKeyFunc("knowledgeHotKeys");
               break;
           default:
               break;
       }
        alertAreaOut();
    };
    var selectAreaFunc=function(){
        getplaymuic();
        if (!$(".alertArea").hasClass("block")) {
            $(".alertArea").addClass("block").show();
            return;
        }
        $(".alertArea").removeClass("block").hide();
    };
    var bgShadowFunc=function(){
        getplaymuic();
        eventPrevent = false;
        $(".manuSlide").removeClass("block").hide();
        $(this).hide();
        $(".activeManu").css("background", "#fff");
        $(".ManuButton").css({
            backgroundImage: "img/index/manu1.png"
        });
    }
    function headerClickFunc(){
        var headerOptions={
            ".ManuButton":manuFunc,
            ".activeManu":activeManuFunc,
            "#search":searchFunc,
            ".alertDetail":alertDetailFunc,
            ".selectArea":selectAreaFunc,
            ".callTopIcon":callTopFunc,
            ".cartButton":downFunc,
            ".bgShadowBOX":bgShadowFunc,
            ".deleteIcon":searchFunc
        }
        return headerOptions;
    }
    //判断输入框是否为空格
    var BlankSpace=true;
    function checkBlankSpace(str){
        while(str.lastIndexOf(" ")>=0){
            str = str.replace(" ","");
        }
        if(str.length == 0){
            BlankSpace=false;
        }else{
            BlankSpace=true;
        }
    }
    function searchRuning(){
        return $(".cartButton").hasClass("cart_cancel");
    }
    function searchCancel() { //搜索完成或取消
        $(".bgShadow")[0].scrollTop = 0;
        $("body")[0].scrollTop=currentScroll;
        $(".scrollContent").hide();
        eventPrevent = false;
        if (!isIphone) {
            ikanWebInterface.updateSearchState("1",false);
        }
        $(".alertDetail").removeClass("alertDetailSelect").eq(1).addClass("alertDetailSelect");
        $(".selectArea span").text("动漫");
        $("#search").attr("placeholder","搜索动漫");
        $(".bgShadow").removeClass("shadowSlide");
        $(".ManuButton").removeClass("ManuLeave");
        $(".ManuButton").removeClass("ManuLeave");
        $(".label").css("margin-left", "0px");
        $(".scrollContent").show();
        $(".cartButton").removeClass("cart_cancel");
        $(".selectArea").hide();
        $(".manuSlide").hide();
        $(".searchIcon").show();
        $("#search").val("");
        $(".callBox").show();
        if (!$(".callTopIcon").hasClass("topUp")) {
            $(".callTopButton").hide();
        }else{
            $(".callTopButton").show();
        };
        hotKeyFunc("albumHotKeys");
        alertAreaOut();
    };
    function alertAreaOut() {
        $(".alertArea").removeClass("block").hide();
        swiper.animating=false;
        onceClick = false;
    }
    function backTop() {
        if (isIphone) {
            return $(".bgShadow")[0].scrollTop = 0;
        }
        document.body.scrollTop = 0;
    }
    !(function() {
        $("#search").click(function() { //搜索框点击事件动画
            if(androidVersionNum==0||androidVersionNum>=440)searchFunc.apply(this);
        }).blur(function(){
            // $(this).attr("placeholder","搜索动漫");
        });
        $(".ManuButton").on("click", function() {
            if(androidVersionNum==0||androidVersionNum>=440)manuFunc.apply(this);
        });
        $(".bgShadowBOX").click(function() {
            if(androidVersionNum==0||androidVersionNum>=440)bgShadowFunc.apply(this);
        });

       
        $(document).on("click", ".cart_cancel", function() { //取消按钮点击事件
            getplaymuic();
            reloadPage = false;
            // $(".bgShadow")[0].scrollTop = 0;
            setTimeout(function(){
                searchCancel();
            },60)
        });
        $(".cartButton").fix("click", function() { //逻辑todo购物车
            if(androidVersionNum==0||androidVersionNum>=440)
                downFunc.apply(this);
        }, {
            "commOnce": true
        });
        $(document).on("click", ".deleteIcon", function() { 
            getplaymuic();
            $("#search").val("");
            if(androidVersionNum==0||androidVersionNum>=440)searchFunc.apply(this);
        });
        if(isIphone){
            $("#search").on("search", function(event) {
               onSearch();     
            });
        }
        else{
            $("#search").on("keydown", function(event) {
                if(event.keyCode==13){
                    onSearch();     
                }
            });
        }
        function onSearch() {
                $("input").blur();
                var hotKeys=$("#search").val();
                hotKeys=hotKeys.replace(/\"/ig,"").replace(/\\/ig,"").replace(/\//ig,"");
                $("#search").val(hotKeys);
                checkBlankSpace(hotKeys);
                if (hotKeys!==" "&&BlankSpace==true) {
                    var newHotKeys=[];
                    for(var j=0;j<hotKeysBox.length;j++){
                        if (hotKeysBox[j]!==hotKeys) {
                            newHotKeys.push(hotKeysBox[j]);
                        }
                    }
                    newHotKeys.unshift(hotKeys);
                    hotKeysBox=newHotKeys;
                    setItem();
                }
                switch ($(".selectArea span").text()) {
                    case '全部':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',10);
                        break;
                    case '动漫':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',10);
                        break;
                    case '玩具':
                            ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',10);
                         break;
                    case '知识':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',10);
                        break;
                    default:
                        break;
                }
                // ikanWebInterface.startIkanScheme('http://172.16.218.42/Web_app/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
                // ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
                searchCancel();
        };
        $(".selectArea").click(function() { //弹出菜单事件
            if(androidVersionNum==0||androidVersionNum>=440)selectAreaFunc.apply(this);
        });

        
        $(document).on("click", ".alertDetail", function() { //弹出菜单的点击事件
            if(androidVersionNum==0||androidVersionNum>=440)alertDetailFunc.apply(this);
        });
    })()