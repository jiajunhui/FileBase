// $(function(){
// 	// init(jsonString);	
//  	ikanWebInterface.docReady('');
// })

