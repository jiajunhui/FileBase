// var jsonString = '{"recommendHotKeys":["巴啦啦小魔仙之秋地方"," 小魔仙地方地方","乐高"],"categorys":[{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/85f85197-df66-4cd7-bef8-c2217b7539ac.png","categoryName":"英语","albumCategoryId":14},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/81fe8529-b71f-4c1c-bbdc-a2d7e9dd5dd9.png","categoryName":"数学逻辑","albumCategoryId":10},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/0ac60dee-8574-4de4-8f07-53a2fc39e917.png","categoryName":"国学语文","albumCategoryId":11},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/f848e1cf-c0ec-4bc6-b7d4-6adbad01bf3a.png","categoryName":"音乐儿歌","albumCategoryId":12},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/bb9b0d9d-9810-4adf-ac0e-8a42c3c8d909.png","categoryName":"科学科普","albumCategoryId":13},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/63ae5aec-8ded-4ed2-a02b-ed48dbaa7615.png","categoryName":"生活常识","albumCategoryId":15}],"thirdPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/c771a93b-2938-4033-8618-05584e8bc08d.png","postertitle":"蓝猫学院","description":"","sortNum":58,"id":145,"type":0,"postersubtitle":"为了梦想奋斗","url":"ikan://album/499"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/66d7fc12-6a1c-44f3-8041-bfa7a06e87d8.png","postertitle":"交通安全篇","description":"","sortNum":58,"id":187,"type":0,"postersubtitle":"变形警车珀利","url":"ikan://album/449"}],"categoryKnowledge":[{"sortNum":0,"categoryName":"英语","knowledgeList":[{"knowledgeId":1,"redirect":"ikan://album/534","img":"http://webimg.ikan.cn/test/ximages/eb/special/d2fe1550-e860-4680-9392-d083cf575c71.jpg","subTitle":"跟洪恩一起学英语","albumId":534,"title":"洪恩三只小猪进阶英语","vip":false,"categoryId":14},{"knowledgeId":2,"redirect":"ikan://album/488","img":"http://webimg.ikan.cn/test/ximages/eb/special/fb9bb2f2-b628-4240-ab30-5b6629481a15.jpg","subTitle":"轻松快乐说英语","albumId":488,"title":"蓝猫幼儿英语300句","vip":false,"categoryId":14}],"categoryId":14},{"sortNum":1,"categoryName":"数学逻辑","knowledgeList":[{"knowledgeId":6,"redirect":"ikan://album/493","img":"http://webimg.ikan.cn/test/ximages/eb/special/2ff710f2-3159-4f93-8daa-6cf10b772f90.jpg","subTitle":"促进幼儿思维发展","albumId":493,"title":"蓝猫幼儿数学","vip":false,"categoryId":10},{"knowledgeId":5,"redirect":"ikan://album/536","img":"http://webimg.ikan.cn/test/ximages/eb/special/cd77cf4d-f505-4058-880b-2681386adb87.png","subTitle":"幼教专家特别推荐","albumId":536,"title":"洪恩幼儿数学","vip":false,"categoryId":10}],"categoryId":10},{"sortNum":2,"categoryName":"国学语文","knowledgeList":[{"knowledgeId":3,"redirect":"ikan://album/559","img":"http://webimg.ikan.cn/test/ximages/eb/special/12996e4e-ffeb-450e-87d0-18db8636c213.jpg","subTitle":"一起听孝孝龙的传奇故事","albumId":559,"title":"孝孝龙奇幻记","vip":false,"categoryId":11},{"knowledgeId":4,"redirect":"ikan://album/564","img":"http://webimg.ikan.cn/test/ximages/eb/special/02791369-005e-4297-9792-71499d74dc98.jpg","subTitle":"一起来学汉字","albumId":564,"title":"开心汉字","vip":false,"categoryId":11}],"categoryId":11},{"sortNum":3,"categoryName":"音乐儿歌","knowledgeList":[{"knowledgeId":7,"redirect":"ikan://album/633","img":"http://webimg.ikan.cn/test/ximages/eb/special/35f32875-c315-42ea-bee4-d9f676085018.jpg","subTitle":"一起学巴塔木儿歌","albumId":633,"title":"巴塔木儿歌","vip":false,"categoryId":12},{"knowledgeId":8,"redirect":"ikan://album/433","img":"http://webimg.ikan.cn/test/ximages/eb/special/5bab418f-0926-49c8-bc00-182fbd475c16.jpg","subTitle":"一起来学儿歌","albumId":433,"title":"功夫龙儿歌","vip":false,"categoryId":12}],"categoryId":12},{"sortNum":4,"categoryName":"科学科普","knowledgeList":[{"knowledgeId":9,"redirect":"ikan://album/563","img":"http://webimg.ikan.cn/test/ximages/eb/special/684af4d4-5e7f-4a38-ba3d-db63234432b2.jpg","subTitle":"哈哈熊带你一起去漫游世界","albumId":563,"title":"哈哈熊漫游世界","vip":false,"categoryId":13},{"knowledgeId":10,"redirect":"ikan://album/460","img":"http://webimg.ikan.cn/test/ximages/eb/special/9e6664d9-1e77-4775-bd78-bd5f144fd773.jpg","subTitle":"一起学科学","albumId":460,"title":"梦幻布布星","vip":false,"categoryId":13}],"categoryId":13},{"sortNum":5,"categoryName":"生活常识","knowledgeList":[{"knowledgeId":11,"redirect":"ikan://album/561","img":"http://webimg.ikan.cn/test/ximages/eb/special/41083f7b-d687-4a65-90f9-981c49f58f3d.jpg","subTitle":"一起学习生活常识","albumId":561,"title":"哈哈咪咪秀","vip":false,"categoryId":15},{"knowledgeId":12,"redirect":"ikan://album/581","img":"http://webimg.ikan.cn/test/ximages/eb/special/21c1d6f4-463c-4cdf-81a0-4ea1d1f8ee03.jpg","subTitle":"一起听故事~","albumId":581,"title":"让想象飞","vip":false,"categoryId":15}],"categoryId":15}],"largePoster":{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/7c11faf7-e169-4395-8510-414c62435f28.png","postertitle":"萌哒哒的数学","description":"","sortNum":81,"id":132,"type":0,"postersubtitle":"变学霸 动霸tua！","url":"ikan://web/ikan_specialSubject.html#{command:5060,params:{topicId:41}}"},"productHotKeys":["火力少年","乐高","喜羊羊","如比","费雪","托马斯"],"seconedPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/d6761afb-21b8-4bf5-9202-067063fe2eb9.png","postertitle":"洪恩宝宝","description":"","sortNum":63,"id":142,"type":0,"postersubtitle":"洪恩宝宝带你看世界","url":"ikan://album/538"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/c49ab42c-6d92-436a-87e4-cf251d25109c.png","postertitle":"科普专区","description":"","sortNum":66,"id":186,"type":0,"postersubtitle":"蓝猫科普专区","url":"ikan://album/401"}],"pushAlbum":{"totalNumber":0,"nowCount":0,"specialType":0,"name":"洪恩三只小猪进阶英语","id":534,"type":0,"vip":false,"totalCount":18,"snapshot":"http://webimg.ikan.cn/test/ximages/album/28a1d6e3-9c0f-4877-9d06-fc0e266bec94.jpg"},"albumHotKeys":["火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生"],"hotKeys":["蓝猫淘气3000问","朵拉"],"recommends":[{"redirect":"www.ikan.cn","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/f169ef19-0fe7-42a1-b4fc-1f66b70f7227.png","id":1301,"sort":1},{"redirect":"ikan://album/541","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/841ccc9f-01d1-4966-8404-d81b40d63090.png","id":1300,"sort":2},{"redirect":"ikan://album/593","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/7313ff86-67a4-4206-8f02-80d7c51ca37f.png","id":1296,"sort":3},{"redirect":"ikan://album/536","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/e07db02c-2bdc-420d-bd4f-d9c0395e58a8.PNG","id":1295,"sort":4}],"knowledgeInfos":[{"infoId":10,"infoUrl":"ikan://album/297","content":"《蓝弧儿歌》开播了"},{"infoId":9,"infoUrl":"ikan://album/276","content":"《兔小贝儿歌系列》更新啦"}],"knowledgeHotKeys":["蓝猫淘气3000问","朵拉"]}';
var jsonString = '{"pushAlbum":{"totalNumber":0,"nowCount":0,"specialType":0,"name":"洪恩三只小猪进阶英语","id":534,"type":0,"vip":false,"totalCount":18,"snapshot":"http://webimg.ikan.cn/test/ximages/album/28a1d6e3-9c0f-4877-9d06-fc0e266bec94.jpg"},"recommendHotKeys":["乐高","樱桃小丸子","巴拉拉小魔仙","乐高"],"categorys":[{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/85f85197-df66-4cd7-bef8-c2217b7539ac.png","categoryName":"英语","albumCategoryId":14},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/81fe8529-b71f-4c1c-bbdc-a2d7e9dd5dd9.png","categoryName":"数学逻辑","albumCategoryId":10},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/0ac60dee-8574-4de4-8f07-53a2fc39e917.png","categoryName":"国学语文","albumCategoryId":11},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/f848e1cf-c0ec-4bc6-b7d4-6adbad01bf3a.png","categoryName":"音乐儿歌","albumCategoryId":12},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/bb9b0d9d-9810-4adf-ac0e-8a42c3c8d909.png","categoryName":"科学科普","albumCategoryId":13},{"imageSrc":"http://webimg.ikan.cn/test/ximages/video/albumCategory/63ae5aec-8ded-4ed2-a02b-ed48dbaa7615.png","categoryName":"生活常识","albumCategoryId":15}],"thirdPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/66d7fc12-6a1c-44f3-8041-bfa7a06e87d8.png","postertitle":"交通安全篇","description":"","sortNum":62,"id":187,"type":0,"postersubtitle":"变形警车珀利","url":"ikan://album/449"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/66d7fc12-6a1c-44f3-8041-bfa7a06e87d8.png","postertitle":"交通安全篇","description":"","sortNum":63,"id":188,"type":0,"postersubtitle":"变形警车珀利","url":"ikan://album/449"}],"categoryKnowledge":[{"sortNum":0,"categoryName":"英语","knowledgeList":[{"knowledgeId":1,"redirect":"ikan://album/534","img":"http://webimg.ikan.cn/test/ximages/eb/special/d2fe1550-e860-4680-9392-d083cf575c71.jpg","subTitle":"跟洪恩一起学英语","albumId":534,"title":"洪恩三只小猪进阶英语","vip":false,"categoryId":14},{"knowledgeId":2,"redirect":"ikan://album/488","img":"http://webimg.ikan.cn/test/ximages/eb/special/fb9bb2f2-b628-4240-ab30-5b6629481a15.jpg","subTitle":"轻松快乐说英语","albumId":488,"title":"蓝猫幼儿英语300句","vip":false,"categoryId":14}],"categoryId":14},{"sortNum":1,"categoryName":"数学逻辑","knowledgeList":[{"knowledgeId":6,"redirect":"ikan://album/493","img":"http://webimg.ikan.cn/test/ximages/eb/special/2ff710f2-3159-4f93-8daa-6cf10b772f90.jpg","subTitle":"促进幼儿思维发展","albumId":493,"title":"蓝猫幼儿数学","vip":false,"categoryId":10},{"knowledgeId":5,"redirect":"ikan://album/536","img":"http://webimg.ikan.cn/test/ximages/eb/special/cd77cf4d-f505-4058-880b-2681386adb87.png","subTitle":"幼教专家特别推荐","albumId":536,"title":"洪恩幼儿数学","vip":false,"categoryId":10}],"categoryId":10},{"sortNum":2,"categoryName":"国学语文","knowledgeList":[{"knowledgeId":3,"redirect":"ikan://album/559","img":"http://webimg.ikan.cn/test/ximages/eb/special/12996e4e-ffeb-450e-87d0-18db8636c213.jpg","subTitle":"一起听孝孝龙的传奇故事","albumId":559,"title":"孝孝龙奇幻记","vip":false,"categoryId":11},{"knowledgeId":4,"redirect":"ikan://album/564","img":"http://webimg.ikan.cn/test/ximages/eb/special/02791369-005e-4297-9792-71499d74dc98.jpg","subTitle":"一起来学汉字","albumId":564,"title":"开心汉字","vip":false,"categoryId":11}],"categoryId":11},{"sortNum":3,"categoryName":"音乐儿歌","knowledgeList":[{"knowledgeId":7,"redirect":"ikan://album/633","img":"http://webimg.ikan.cn/test/ximages/eb/special/35f32875-c315-42ea-bee4-d9f676085018.jpg","subTitle":"一起学巴塔木儿歌","albumId":633,"title":"巴塔木儿歌","vip":false,"categoryId":12},{"knowledgeId":8,"redirect":"ikan://album/433","img":"http://webimg.ikan.cn/test/ximages/eb/special/5bab418f-0926-49c8-bc00-182fbd475c16.jpg","subTitle":"一起来学儿歌","albumId":433,"title":"功夫龙儿歌","vip":false,"categoryId":12}],"categoryId":12},{"sortNum":4,"categoryName":"科学科普","knowledgeList":[{"knowledgeId":9,"redirect":"ikan://album/563","img":"http://webimg.ikan.cn/test/ximages/eb/special/684af4d4-5e7f-4a38-ba3d-db63234432b2.jpg","subTitle":"哈哈熊带你一起去漫游世界","albumId":563,"title":"哈哈熊漫游世界","vip":false,"categoryId":13},{"knowledgeId":10,"redirect":"ikan://album/460","img":"http://webimg.ikan.cn/test/ximages/eb/special/9e6664d9-1e77-4775-bd78-bd5f144fd773.jpg","subTitle":"一起学科学","albumId":460,"title":"梦幻布布星","vip":false,"categoryId":13}],"categoryId":13},{"sortNum":5,"categoryName":"生活常识","knowledgeList":[{"knowledgeId":11,"redirect":"ikan://album/561","img":"http://webimg.ikan.cn/test/ximages/eb/special/41083f7b-d687-4a65-90f9-981c49f58f3d.jpg","subTitle":"一起学习生活常识","albumId":561,"title":"哈哈咪咪秀","vip":false,"categoryId":15},{"knowledgeId":12,"redirect":"ikan://album/581","img":"http://webimg.ikan.cn/test/ximages/eb/special/21c1d6f4-463c-4cdf-81a0-4ea1d1f8ee03.jpg","subTitle":"一起听故事~","albumId":581,"title":"让想象飞","vip":false,"categoryId":15}],"categoryId":15}],"albumHotKeys":["火力","少年王5之","传奇再现发个","火力少年王5之传奇再现","火力少年王5之传奇再现","炮炮向前冲之荒岛求生","炮炮向前冲之荒岛求生"],"largePoster":{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/7c11faf7-e169-4395-8510-414c62435f28.png","postertitle":"萌哒哒的数学","description":"","sortNum":88,"id":132,"type":0,"postersubtitle":"变学霸 动霸tua！","url":"ikan://web/ikan_specialSubject.html#{command:5060,params:{topicId:41}}"},"recommends":[{"redirect":"ikan://album/6","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/f169ef19-0fe7-42a1-b4fc-1f66b70f7227.png","id":1301,"sort":1},{"redirect":"ikan://album/541","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/841ccc9f-01d1-4966-8404-d81b40d63090.png","id":1300,"sort":2},{"redirect":"ikan://album/593","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/7313ff86-67a4-4206-8f02-80d7c51ca37f.png","id":1296,"sort":3},{"redirect":"ikan://album/536","summary":"","img":"http://webimg.ikan.cn/test/ximages/recommend/250faf6e-9a3f-42f0-82b1-44d8970c092e.png","id":1295,"sort":4}],"productHotKeys":["火力","少年乐高喜","羊羊","乐高","乐高","乐高","乐高","如比","费雪","托马斯"],"seconedPosters":[{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/d6761afb-21b8-4bf5-9202-067063fe2eb9.png","postertitle":"洪恩宝宝","description":"","sortNum":70,"id":142,"type":0,"postersubtitle":"洪恩宝宝带你看世界","url":"ikan://album/538"},{"img":"http://webimg.ikan.cn/test/ximages/eb/poster/c49ab42c-6d92-436a-87e4-cf251d25109c.png","postertitle":"科普专区","description":"","sortNum":73,"id":186,"type":0,"postersubtitle":"蓝猫科普专区","url":"ikan://album/401"}],"knowledgeInfos":[{"infoId":10,"infoUrl":"ikan://album/297","content":"《蓝弧儿歌》开播了"},{"infoId":9,"infoUrl":"ikan://album/276","content":"《兔小贝儿歌系列》更新啦"}]}';
var cartoonSwipe="";
function init(json) {
    // try{
    //  initTry(json);
    // }catch(e){
    //  document.write(e.name);
    //  document.write(e.number);
    //  document.write(e.description);
    //  document.write(e.message);
    //  document.write(json);
    // }
    setTimeout(function() {
        initTry(json);
    }, 100);
}
var hotKeysBox=[];
var indexmark="know";
function initTry(json) {
    hotKeysJson={};
    var BOX = '<div class="refreshBox"><div class="refreshImageBox"><img src="img/loading.png" alt="" class="refreshImage"></div><p class="refreshText">下拉刷新</p></div><div class="callTopButton"><img src="img/top.png" class="callTopIcon"></div>';
    var HTML = '<div class="bannerArea"><div class="swiper-container"><div class="swiper-wrapper bannerWrapper"></div><div class="swiper-pagination"></div></div></div><section class="cartonsArticleArea"><img src="img/knowledge.png" alt="" class="cartonsArticleTitle"><div class="cartonsArticleContent"><div class="swiper-wrapper"></div></div></section><div class="marginTop1"></div><section class="cartonsPostArea"><div class="cartonsBigPost"><img  alt=""  data-image={{largeCartonImage}} class="unload" id="largePost"><div class="gradient"></div>{{cartonTextBig}}</div><div class="cartonsleftListbox"><div class="cartonsMiddlePost"><img  alt="" data-image={{middleCartonImage}} class="unload" id="middlePost"><div class="gradient"></div>{{cartonTextMiddle}}</div><div class="cartonsSmallPost smallBanner"><img  alt="" data-image={{smallCartonImage}} class="unload" id="smallPost"><div class="gradient"></div>{{cartonTextSmall}}</div><div class="cartonsSmallPost videoContent" data-id={{idData}}><img  alt="" data-image={{lastCartonImage}} class="unload" id="lastWatchPost"><div class="continueWatch">立即观看</div></div></div></section><section class="knowledgeModelBox"></section>';
    var search='<div class="hotText">热门推荐</div><div class="hotKeys"></div><div class="searchVagaa"><div class="hotVagaa">搜索记录</div><div class="vagaa"></div><div class="graybox"></div><div class="emptyHistory">清空搜索历史记录</div></div>';
    search.innerHTML = "";
    $(".bgShadow").html(search);
    var obj = $(".scrollContent");
    var obj1 = $(".callBox");
    $("*", obj).add([obj]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $("*", obj1).add([obj1]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $("*", search).add([obj1]).each(function() {
        $.event.remove(this);
        $(this).empty();
    });
    $.event.remove(window);
    obj.innerHTML = "";
    $(".callBox").append(BOX);
    $(".scrollContent").prepend(HTML).show();
    initParam();
    json = typeof(json) == "string" ? JSON.parse(json) : json;
    debug(json)
    if(json.albumHotKeys)hotKeysJson.albumHotKeys=json.albumHotKeys;
    if(json.productHotKeys)hotKeysJson.productHotKeys=json.productHotKeys;
    if(json.knowledgeHotKeys)hotKeysJson.knowledgeHotKeys=json.knowledgeHotKeys;
    if(json.recommendHotKeys)hotKeysJson.recommendHotKeys=json.recommendHotKeys;
    // debug(json)
    if (json.status && json.status == 10) {
        dead();
        $(".dead").unbind("click").on("click", function() {
            getplaymuic();
            ikanWebInterface.reloadPage();
            $(".box").show();
            $(".dead").hide();
        });
        return;
    }
    var backBut = true,
        cartBat = true,
        performanceBut = true;
    if (json.status && json.status == 9) {
         $(".box").hide();
        return confirm(json.err, ["确定"]);
    }
    debug(json);
    data1 = json.categorys;
    data2 = json.recommends;
    data9 = json.knowledgeHotKeys;
    for (var htmls = "", i = 0; i < data1.length; i++) {
        htmls += '<div class="activeManu" data-category=' + data1[i].albumCategoryId + '><img src="' + data1[i].imageSrc + '" alt=""><span>' + data1[i].categoryName + '</span></div>';
    }
    $(".manuSlide").html(htmls);
    data = json.categoryKnowledge;
    if (typeof data !== "undefined") {
        for (var htmls = "", i = 0; i < data.length; i++) {
            htmls += '<div class="marginTop2"></div><figure class="knowledgeModel"><div class="knowledgeModelTitle" data-id=' + data[i].categoryId + '><span class="knowledgeTitle">' + data[i].categoryName + '</span><img src="img/Kmore.png" alt="" class="moreLink"><span class="moreText">更多</span></div><div class="knowledgeModelContent">';
            var knowledgeList = data[i].knowledgeList;
            for (z = 0; z < knowledgeList.length; z++) {
                htmls += '<div class="knowledgeModelDetail" data-id="' + knowledgeList[z].knowledgeId + '" data-url=' + knowledgeList[z].redirect + '><img class="unload" data-image=' + ImageUrl(knowledgeList[z].img, ".300x300") + ' alt="" id="knowledge' + (i + 1) + (z + 1) + '"><div class="gradient"></div><div class="mangaInformation"><p>' + slices(knowledgeList[z].title, 8) + '</p><p>' + slices(knowledgeList[z].subTitle, 10) + '</p></div>';
                if (knowledgeList[z].vip == true) {
                    htmls += '<div class="VIPImg"><img src="img/vip.png"></div>';
                }
                htmls += '</div>';
            }
            htmls += '</div></figure>';
        }
        $(".knowledgeModelBox").html(htmls);
    }
    if (typeof data2 !== "undefined") {
        try {
            for (var htmls = "", i = 0; i < data2.length; i++) {
                htmls += '<div class="swiper-slide" data-id=' + data2[i].id + ' data-url=' + data2[i].redirect + '><img class="unload" data-image=' + ImageUrl(data2[i].img, ".640x240") + ' alt="" id="bannerKnow' + i + '"></div>';
            }
            jsonString=htmls;
            $(".bannerWrapper").html(htmls);
        } catch (e) {
            $(".bannerArea").css({
                overflow: "hidden",
                height: 0
            });
        }
    }
    if(json.pushAlbum) data8=json.pushAlbum;
    try {
        htmls = $(".cartonsPostArea").html();
        htmls = htmls.replace("{{cartonTextBig}}", getCartonText.call(json.largePoster))
            .replace("{{largeCartonImage}}", ImageUrl(json.largePoster.img, ".290x360"))
            .replace("{{cartonTextMiddle}}", getCartonText1.call(json.seconedPosters[0]))
            .replace("{{middleCartonImage}}", ImageUrl(json.seconedPosters[0].img, ".340x180"))
            .replace("{{cartonTextSmall}}", getCartonText2.call(json.thirdPosters[0]))
            .replace("{{smallCartonImage}}", ImageUrl(json.thirdPosters[0].img, ".166x170"))
            .replace("{{lastCartonImage}}", ImageUrl(json.pushAlbum.snapshot, ".166x170"))
            .replace("{{idData}}", json.pushAlbum.id);
        $(".cartonsPostArea").html(htmls); //大中小卡通海报区域
    } catch (e) {
        $(".cartonsPostArea").css({
            "height": 0,
            "overflow": "hidden"
        });
    }
    var data3 = json.knowledgeInfos;
    if (typeof data3 !== "undefined") {
        for (var i = 0; i < data3.length; i++) { //上下自动滚动的文字区域
            $(".cartonsArticleContent .swiper-wrapper").append('<p class="swiper-slide cartonsSwipeText" data-url=' + data3[i].infoUrl + ' data-id=' + data3[i].infoId + '>' + data3[i].content + '</p>');
        }
        htmls = $(".cartonsPostArea").html();
        cartoonSwipe=$(".cartonsArticleContent .swiper-wrapper").html();
    }
    if (data9) {
        for (var htmls = "", i = 0; i < data9.length; i++) {
            htmls += '<span id="hotKeys'+i+'">'+data9[i]+'</span>';
        }
        $(".hotKeys").html(htmls);
    }
    if(data9 == null){
        $(".hotKeys").hide()
        $(".hotText").hide()
    }
    swiperInit();
    

    function getCartonText() { //获取海报区域的文字
        return '<div class="cartonsInformation" data-url="' + this.url + '" data-id=' + this.id + '><p>' + slices(this.postertitle, 8) + '</p><p>' + slices(this.postersubtitle, 10) + '</p></div>';
    }

    function getCartonText1() { //获取海报区域的文字
        return '<div class="cartonsInformation" data-url="' + this.url + '" data-id=' + this.id + '><p>' + slices(this.postertitle, 9) + '</p><p>' + slices(this.postersubtitle, 12) + '</p></div>';
    }

    function getCartonText2() { //获取海报区域的文字
        return '<div class="cartonsInformation" data-url="' + this.url + '" data-id=' + this.id + '><p>' + slices(this.postertitle, 5) + '</p><p>' + slices(this.postersubtitle, 17) + '</p></div>';
    }
    $(".callTopButton .callTopIcon").touchdown(function(){
        $(this).attr("src","img/topTouch.png");
    },function(){
        $(this).attr("src","img/top.png");
    })
    $(".activeManu").touchdown(function() {
        $(this).css({
            "background": "#f5f5f5"
        });
    }, function() {
        $(this).css({
            "background": "#ffffff"
        });
    });
    $(".ManuButton").touchdown(function() {
        $(this).css({
            "background": "url(img/index/manuButtona.png) no-repeat center",
            "backgroundSize":"32px"
        });
    }, function() {
        $(this).css({
            "background": "url(img/index/manuButton.png) no-repeat center",
            "backgroundSize":"32px"
        });
    });
    $(".cartButton").touchdown(function() {
        $(this).addClass("cartButtonGreen");
    }, function() {
        $(this).removeClass("cartButtonGreen");
    });
    $(".activeManu").unbind("click").click(function() {
        if(androidVersionNum==0||androidVersionNum>=440)activeManuFunc.apply(this);
    });

    $(".scrollContent").animate({
        opacity: 1
    }, 200);
    setTimeout(function() {
        $(".box").hide();
    }, 300);
    loadImage("scrollContent");
        ikanWebInterface.getLastPlayRecord("1");
    lastPlayed = false;
    $(".videoContent").unbind("click").click(function() {
        getplaymuic();
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var jsonString = '{"pageSize":12,"page":' + pageIndex + '}';
        ikanWebInterface.command(5125, jsonString,' ',14);
        ikanWebInterface.startIkanScheme('ikan://album/' + $(this).data("id"),' ',14);
    });
    if (!isIphone) {
        ikanWebInterface.updateSearchState("3",false);
    }
           
}
// $(".moreText").unbind("click").on("click", function() {
//     getplaymuic();
//     ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + $("#search").val() + '","page":0,"pageSize":12}}');
// });
var LastPlayUrl = false,
    lastPlayed = true,
    lastRunTime = 0;

function returnLastPlayRecord(LastPlay) {
   if(!isIphone)swiperInit();
    touchClick=false;
    lastRunTime++;
    if (LastPlay === "null") {
        if(data8){
            LastPlay={};
            LastPlay.albumCover=data8.snapshot;
            LastPlay.albumId=data8.id;
            $(".continueWatch").html("立即观看");
        }else{
            return;
        }
    }else{
        LastPlay = JSON.parse(LastPlay);
        $(".continueWatch").html("继续观看");
    }
    var imgurl = ImageUrl(LastPlay.albumCover, ".220x300");
    $("#lastWatchPost").removeClass("opacityAnimationLoad").data("image", imgurl);
    ikanWebInterface.asyncLoadImg(imgurl, "lastWatchPost");
    $(".videoContent").data("id", LastPlay.albumId);
}

// function commScheme() { //大小海报的公共点击函数
//     var _this = $(this).find(".cartonsInformation");
//     if (!_this.length) {
//         var thisId = typeof($(this).data("id")) == "undefined" ? "" : "/" + $(this).data("id");
//         ikanWebInterface.startIkanScheme('ikan://video/' + videoId + thisId);
//         return;
//     }
//     var schemeUrl = _this.data("url");
//     if (schemeUrl.indexOf("{") > -1) {
//         schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
//             return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
//         });
//         schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
//     }
//     console.log(jsonString)
//     ikanWebInterface.command(5125, jsonString,' ',14,locations);
//     ikanWebInterface.startIkanScheme(schemeUrl,' ',14,locations);
// }
var hotKeysJson={};
$(function() {
        ikanWebInterface.docReady('');
         $(document).on("click",".emptyHistory",function(){
                confirm("确认清空搜索历史记录？", ["确认", "取消"], function() {
                $(".searchVagaa").hide();
                hotKeysBox=[];
                localStorage.clear();
                }),
                function() {

                }
            })
        $(document).on("click",".hotKeys span",function(){
            var hotKeys=$(this).text();
            $("#search").val(hotKeys);
            if ($(this).val()!==" ") {
                var newHotKeys=[];
                for(var j=0;j<hotKeysBox.length;j++){
                    if (hotKeysBox[j]!==hotKeys) {
                        newHotKeys.push(hotKeysBox[j]);
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox=newHotKeys;
                setItem();
            }
            switch ($(".selectArea span").text()) {
                case '全部':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',14);
                    break;
                case '动漫':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',14);
                    break;
                case '玩具':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',14);
                     break;
                case '知识':
                    ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',14);
                    break;
                default:
                    break;
            }
            searchCancel();
        })
        $(document).on("click",".cartonsArticleContent .swiper-slide",function() {
            getplaymuic();
            if (swiper&&swiper.animating) return;
            var _this = $(this);
            var schemeUrl = _this.data("url");
            if (schemeUrl.indexOf("{") > -1) {
                schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                    return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
                });
                schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
            }
            var num = $(this).data("id");
             var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
            ikanWebInterface.command(5125, jsonString,' ',14,'KNOWNLEDGE_INFO_'+num);
            ikanWebInterface.startIkanScheme(schemeUrl,' ',14,'KNOWNLEDGE_INFO_'+num);
        });
        $(document).fix("click", ".bannerArea .swiper-slide", function() {
            var _this = $(this);
            var schemeUrl = _this.data("url");
            if (schemeUrl.indexOf("{") > -1) {
                schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                    return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
                });
                schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
            }
            var num = parseInt($(this).data("swiper-slide-index"))+1;
             var jsonString = '{"statisticsId":' + $(this).data("id") + '}';
            ikanWebInterface.command(5125, jsonString,' ',14,'KNOWNLEDGE_IMAGE_'+num);
            ikanWebInterface.startIkanScheme(schemeUrl,' ',14,'KNOWNLEDGE_IMAGE_'+num);
        }, {
            "commOnce": true
        });
        $(document).fix("click",".cartonsBigPost,.cartonsMiddlePost,.smallBanner", function() {
        if (swiper&&swiper.animating) return;
        if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        var _this = $(this).find(".cartonsInformation");
        var schemeUrl = _this.data("url");
        if (schemeUrl.indexOf("{") > -1) {
            schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
            });
            schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
        }
            if ($(this).hasClass("cartonsBigPost")) {
                var jsonString = '{"statisticsId":' + $(".cartonsBigPost .cartonsInformation").data("id") + '}';
                var locations = "KNOWNLEDGE_LARGE_POSTER";
                ikanWebInterface.command(5125,jsonString, " ",14,locations);
                ikanWebInterface.startIkanScheme(schemeUrl,' ',14,locations);
            }
            if ($(this).hasClass("cartonsMiddlePost")) {
                var jsonString = '{"statisticsId":' + $(".cartonsMiddlePost .cartonsInformation").data("id") + '}';
                var locations = "KNOWNLEDGE_POSTER_SECOND_1";
                ikanWebInterface.command(5125,jsonString, " ",14,locations);
                ikanWebInterface.startIkanScheme(schemeUrl,' ',14,locations);
            }
            if ($(this).hasClass("smallBanner")) {
                var jsonString = '{"statisticsId":' + $(".smallBanner .cartonsInformation").data("id") + '}';
                var locations = "KNOWNLEDGE_POSTER_THIRD_1";
                ikanWebInterface.command(5125,jsonString, " ",14,locations);
                ikanWebInterface.startIkanScheme(schemeUrl,' ',14,locations);
            }
    }, {
        "commOnce": true
    });
        // $(document).fix("click", ".cartonsBigPost", function() {
        //     if (swiper&&swiper.animating) return;
        //     if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        //     locations = "KNOWNLEDGE_LARGE_POSTER";
        //     jsonString = '{"statisticsId":' + $(".cartonsBigPost .cartonsInformation").data("id") + '}';
        //     commScheme.call(this);
        // }, {
        //     "commOnce": true
        // });
        // $(document).fix("click", ".cartonsMiddlePost", function() {
        //     if (swiper&&swiper.animating) return;
        //     if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        //     locations = "KNOWNLEDGE_POSTER_SECOND_1";
        //     jsonString = '{"statisticsId":' + $(".cartonsMiddlePost .cartonsInformation").data("id") + '}';
        //     commScheme.call(this);
        // }, {
        //     "commOnce": true
        // });
        // $(document).fix("click", ".smallBanner", function() {
        //     if (swiper&&swiper.animating) return;
        //     if (!clickUsed && !lazyLoad.parentFixed(event)) return;
        //     locations = "KNOWNLEDGE_POSTER_THIRD_1";
        //     jsonString = '{"statisticsId":' + $(".smallBanner .cartonsInformation").data("id") + '}';
        //     commScheme.call(this);
        // }, {
        //     "commOnce": true
        // });
        
        $(document).fix("click", ".knowledgeModelTitle", function() {
            if (swiper&&swiper.animating) return;
            var schemeContent = 'ikan://web/ikan_knowledgeList.html#{"command":5064,"params":{"page":0,"pageSize":12,"categoryId":' + $(this).data("id") + ',"title":"' + $(this).find("span").text() + '"}}';
            ikanWebInterface.startIkanScheme(schemeContent,' ',14);
        }, {
            "commOnce": true
        });
        $(document).fix("click", ".knowledgeModelDetail", function() {
                if (!clickUsed && !lazyLoad.parentFixed(event)) return;
                if (swiper&&swiper.animating) return;
                var _this = $(this);
                var schemeUrl = _this.data("url");
                if (schemeUrl.indexOf("{") > -1) {
                    schemeUrl = schemeUrl.replace(/(\{|\,)\w+:/ig, function(word) {
                        return word.slice(0, 1) + '"' + word.slice(1, -1) + '":';
                    });
                    schemeUrl = schemeUrl.replace(/\&quot/ig, "\"");
                }
                ikanWebInterface.startIkanScheme(schemeUrl,' ',14);
            }, {
                "commOnce": true
            });
            // init(jsonString);
            

    });
    // 搜索部分js逻辑
    var txt=$(this).attr("placeholder");
    function setItem(){
        var newHotKeysBox=hotKeysBox;
        newHotKeysBox=newHotKeysBox.join("&quot");
        localStorage.setItem("keys",newHotKeysBox);
    }
    var currentScroll=0;
    var searchFunc=function(){
        currentScroll=$("body")[0].scrollTop;
        $(".scrollContent").hide();
            var _this=this;
        setTimeout(function(){
            getplaymuic();
            if (!isIphone) {
                ikanWebInterface.updateSearchState("3",true);
            }
            if(!$(".bgShadow").hasClass("shadowSlide")) setTimeout(function(){$(".bgShadow")[0].scrollTop = 0},100);
            $(".bgShadow").addClass("shadowSlide");
            $(".callBox").hide();
            var localhotKeys= window.localStorage;
            if (localhotKeys.length==0) {
                $(".searchVagaa").hide();
                hotKeysBox=[];
            }else{
                $(".searchVagaa").show();
                localhotKeys=localhotKeys.getItem("keys");
                localhotKeys=localhotKeys.split("&quot").splice(0,10);
                hotKeysBox=localhotKeys;
                for (var htmls = "", i = 0; i < localhotKeys.length; i++) {
                    htmls += '<span id="hotKeys'+i+'">'+localhotKeys[i]+'</span>';
                }
                $(".vagaa").html(htmls);
                // $(".scrollContent").css("background","#efefef");
            } 
            $(".vagaa span").click(function(){
                var hotKeys=$(this).text();
                var newHotKeys=[];
                for(var j=0;j<hotKeysBox.length;j++){
                    if (hotKeysBox[j]!==hotKeys) {
                        newHotKeys.push(hotKeysBox[j]);
                    }
                }
                newHotKeys.unshift(hotKeys);
                hotKeysBox=newHotKeys;
                setItem();
                switch ($(".selectArea span").text()) {
                    case '全部':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',14);
                        break;
                    case '动漫':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',14);
                        break;
                    case '玩具':
                            ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',14);
                         break;
                    case '知识':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',14);
                        break;
                    default:
                        break;
                }
                // ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
                searchCancel();
            });
            // $(_this).attr("placeholder","");
            $(".alertArea").removeClass("block").hide();
            if (!$(".ManuButton").hasClass("ManuLeave")) {
                $(".ManuButton").addClass("ManuLeave");
                $(".label").css("margin-left", "10px");
                $(".cartButton").addClass("cart_cancel");
                $(".searchIcon").hide();
                $(".selectArea").css({
                    display: "-webkit-box"
                }).show();
                if ($(".manuSlide").hasClass("block")) {
                    $(".manuSlide").removeClass("block").hide();
                }
                $(".bgShadowBOX").hide();
            }
        },200);
            // $("#search").focus();
            $("body").on("touchmove", function(){$("#search").blur()});
        };
    var manuFunc=function() {
            getplaymuic();
            if (!$(".manuSlide").hasClass("block")) {
                eventPrevent = true;
                $(".activeManu").css({
                    "background": "#ffffff"
                });
                $(".bgShadowBOX").show();
                $(".manuSlide").addClass("block").show();
                return;
            }
            eventPrevent = false;
            $(".bgShadowBOX").hide();
            $(".manuSlide").removeClass("block").hide();
    };
    var downFunc=function() { 
        if ($(this).hasClass("cart_cancel")) {
            return;
        }
        if($(".manuSlide").hasClass("block")){
            $(".manuSlide").removeClass("block").hide();
            $(".bgShadowBOX").hide()
            eventPrevent = false;
        }
        ikanWebInterface.startIkanScheme('ikan://download/',' ',14);
    };
    var hotKeyFunc=function  (hotType) {
        if(hotKeysJson[hotType]&&hotKeysJson[hotType].length){//如果有搜索热词，就展示
            $(".hotText,.hotKeys").show();
            var hotJson=hotKeysJson[hotType];
            for (var htmls = "", i = 0; i < hotJson.length; i++) {
                htmls += '<span id="hotKeys'+i+'">'+hotJson[i]+'</span>';
            }
            $(".hotKeys").html(htmls);
        }
        else{
            $(".hotText,.hotKeys").hide();
        }
    }
    var alertDetailFunc=function(){
        getplaymuic();
        $(".alertDetail").removeClass("alertDetailSelect");
        $(this).addClass("alertDetailSelect");
        var type = $(".selectArea span").text($(".alertDetailSelect").text());
        switch (type.text()) {
            case '全部':
                $("#search").attr("placeholder","搜索动漫/玩具/知识");
                hotKeyFunc("recommendHotKeys");
                break;
            case '动漫':
                $("#search").attr("placeholder","搜索动漫");
                hotKeyFunc("albumHotKeys");
                break;
            case '玩具':
                $("#search").attr("placeholder","搜索玩具");
                hotKeyFunc("productHotKeys");
                 break;
            case '知识':
                $("#search").attr("placeholder","搜索知识");
                hotKeyFunc("knowledgeHotKeys");
                break;
            default:
                break;
        }
        alertAreaOut();
    };
    var activeManuFunc=function(){
        getplaymuic();
        $(this).css({
            "background": "#f5f5f5"
        });
        $(".manuSlide").removeClass("block").hide().children().css("background", "#fff");
        $(".bgShadowBOX").hide();
        eventPrevent = false;
        var schemeContent = 'ikan://web/ikan_knowledgeList.html#{"command":5064,"params":{"page":0,"pageSize":12,"categoryId":' + $(this).data("category") + ',"title":"' + $(this).find("span").html() + '"}}';
        ikanWebInterface.startIkanScheme(schemeContent,' ',14);
    };
    var selectAreaFunc=function(){
        getplaymuic();
        if (!$(".alertArea").hasClass("block")) {
            $(".alertArea").addClass("block").show();
            return;
        }
        $(".alertArea").removeClass("block").hide();
    };
    var bgShadowFunc=function(){
        getplaymuic();
            eventPrevent = false;
            $(".manuSlide").removeClass("block").hide();
            $(this).hide();
            $(".activeManu").css("background", "#fff");
            $(".ManuButton").css({
                backgroundImage: "img/index/manu1.png"
            });  
    };
    function headerClickFunc(){
        var headerOptions={
            "#search":searchFunc,
            ".ManuButton":manuFunc,
            ".alertDetail":alertDetailFunc,
            ".activeManu":activeManuFunc,
            ".selectArea":selectAreaFunc,
            ".callTopIcon":callTopFunc,
            ".cartButton":downFunc,
            ".bgShadowBOX":bgShadowFunc,
            ".deleteIcon":searchFunc
        };
        return headerOptions;
    }
    //判断输入框是否为空格
    var BlankSpace=true;
    function checkBlankSpace(str){
        while(str.lastIndexOf(" ")>=0){
            str = str.replace(" ","");
        }
        if(str.length == 0){
            BlankSpace=false;
        }else{
            BlankSpace=true;
        }
    }
    function searchRuning(){
        return $(".cartButton").hasClass("cart_cancel");
    }
    function searchCancel() { //搜索完成或取消
            $(".bgShadow")[0].scrollTop = 0;
            $("body")[0].scrollTop=currentScroll;
            eventPrevent = false;
            if (!isIphone) {
                ikanWebInterface.updateSearchState("3",false);
            }
            $(".alertDetail").removeClass("alertDetailSelect").eq(3).addClass("alertDetailSelect");
            $(".selectArea span").text("知识");
            $("#search").attr("placeholder","搜索知识");
            $(".bgShadow").removeClass("shadowSlide");
            $(".scrollContent").show();
            $(".alertArea").removeClass("block").hide();
            $(".ManuButton").removeClass("ManuLeave");
            $(".label").css("margin-left", "0px");
            $(".cartButton").removeClass("cart_cancel");
            $(".selectArea").hide();
            $(".searchIcon").show();
            $("#search").val("");
            $(".callBox").show();
            if (!$(".callTopIcon").hasClass("topUp")) {
                $(".callTopButton").hide();
            }else{
                $(".callTopButton").show();
            };      
            hotKeyFunc("knowledgeHotKeys");      
            alertAreaOut();
    }
    function alertAreaOut() {
            $(".alertArea").removeClass("block").hide();
            swiper.animating=false;
            onceClick = false;
    }
    function backTop() {
        if (isIphone) {
            return $(".bgShadow")[0].scrollTop = 0;
        }
        document.body.scrollTop = 0;
    }
    //搜索框点击事件动画
    !(function() {
        $("#search").click(function() {
            if(androidVersionNum==0||androidVersionNum>=440)searchFunc.apply(this);
           
        }).blur(function(){
            // $(this).attr("placeholder","搜索知识");
        });
        $(".ManuButton").on("click", function() {
           if(androidVersionNum==0||androidVersionNum>=440)manuFunc.apply(this);
        });
        $(".bgShadowBOX").click(function() {
            if(androidVersionNum==0||androidVersionNum>=440)bgShadowFunc.apply(this);
        });
        //取消按钮点击事件
        $(document).on("click", ".cart_cancel", function() { 
            getplaymuic();
            reloadPage = false;
            // $(".bgShadow")[0].scrollTop = 0;
            setTimeout(function(){
                searchCancel();
            },60)
        });
        //逻辑todo购物车
        $(".cartButton").fix("click", function() { 
            if(androidVersionNum==0||androidVersionNum>=440)
            downFunc.apply(this);
        });
        $(document).on("click", ".deleteIcon", function() { 
            getplaymuic();
            $("#search").val("");
            if(androidVersionNum==0||androidVersionNum>=440)searchFunc.apply(this);
        });
        if(isIphone){
            $("#search").on("search", function(event) {
               onSearch();     
            });
        }
        else{
            $("#search").on("keydown", function(event) {
                if(event.keyCode==13){
                    onSearch();     
                }
            });
        }
        function onSearch(){
                $("input").blur();
                var hotKeys=$("#search").val();
                 hotKeys=hotKeys.replace(/\"/ig,"").replace(/\\/ig,"").replace(/\//ig,"");
                $("#search").val(hotKeys);
                checkBlankSpace(hotKeys);
                if (hotKeys!==" "&&BlankSpace==true) {
                    var newHotKeys=[];
                    for(var j=0;j<hotKeysBox.length;j++){
                        if (hotKeysBox[j]!==hotKeys) {
                            newHotKeys.push(hotKeysBox[j]);
                        }
                    }
                    newHotKeys.unshift(hotKeys);
                    hotKeysBox=newHotKeys;
                    setItem();
                }
                switch ($(".selectArea span").text()) {
                    case '全部':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_recommendList.html#{"command":5115,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":8}}',' ',14);
                        break;
                    case '动漫':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_cartoonCategories.html#{"command":5076,"params":{"searchKey":"' +hotKeys + '","page":0,"pageSize":12}}',' ',14);
                        break;
                    case '玩具':
                            ikanWebInterface.startIkanScheme('ikan://web/ikan_toyList.html#{"command":5075,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',14);
                         break;
                    case '知识':
                        ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}',' ',14);
                        break;
                    default:
                        break;
                }
                // ikanWebInterface.startIkanScheme('http://172.16.218.42/Web_app/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
                // ikanWebInterface.startIkanScheme('ikan://web/ikan_knowledgeCategories.html#{"command":5077,"params":{"searchKey":"' + hotKeys + '","page":0,"pageSize":12}}');
                searchCancel();
        };
         //弹出菜单事件
        $(".selectArea").click(function() {
            if(androidVersionNum==0||androidVersionNum>=440)selectAreaFunc.apply(this);
        });
       //弹出菜单的点击事件 
        $(document).on("click", ".alertDetail", function() { 
             if(androidVersionNum==0||androidVersionNum>=440)alertDetailFunc.apply(this);
        });
    })()